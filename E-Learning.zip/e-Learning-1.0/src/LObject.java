/**
 * <p>Title: LObject</p>
 * <p>Description: Abstract class adding IObject functionality to a JComponent</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.awt.*;
import javax.swing.*;

import sk.lomo.elearning.core.interfaces.*;
import sk.lomo.elearning.core.ui.*;

/** Abstract class adding IObject functionality to a JComponent */

public abstract class LObject extends JComponent implements IObject {
  /** Object utils encapsulating basic IObject functionality */
  protected ObjectUtils objectHelper = new ObjectUtils(this);
  /** Sets the object selection behavior
   * @param selected true if object should be selected */
  public void setObjectSelected(boolean selected) {
    objectHelper.setSelected(selected);
  }

  /** @return true if object has selected behavior */
  public boolean isObjectSelected() {
    return objectHelper.isSelected();
  };
  /** Set object behavior into design mode
   * @param designMode selects design or view mode */
  public void setDesignMode(boolean designMode) {
    objectHelper.setDesignMode(designMode);
  }

  /** @return true if object is in design mode */
  public boolean isDesignMode() {
    return objectHelper.isDesignMode();
  };
  /** @return object icon on object library and menus */
  public Icon getRepositoryIcon() {
    return objectHelper.getRepositoryIcon();
  }

  /** @return object context menu items */
  public JMenuItem[] getMenuItems() {
    return new JMenuItem[0];
  }

  /** @return default object cursor */
  public Cursor getObjectCursor() {
    return objectHelper.getObjectCursor();
  }

  /** @return default size for drag & drop object placement */
  public Dimension getDefaultSize() {
    return new Dimension(22, 22);
  }

  /** Method to be called after object is placed on a slide */
  public void objectPlacement() {};
  /** @return true if object should be placed in object library */
  public abstract boolean isLibraryObject();

  /** @return category name in object library */
  public abstract String getDisplayCategory();

  /** @return object name in object library */
  public abstract String getDisplayName();

  /** @return border used for resizing and object creation */
  public ResizeBorder getResizeBorder() {
    return objectHelper.getResizeBorder();
  }

}
