/**
 * <p>Title: LSound</p>
 * <p>Description: Simple object for playing sampled and midi sound.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.io.*;
import javax.sound.sampled.*;
import javax.sound.midi.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.filechooser.FileFilter;

import sk.lomo.elearning.core.*;
import sk.lomo.elearning.Utils;
import sk.lomo.elearning.core.ui.dialogs.*;
import sk.lomo.elearning.core.interfaces.*;

//** File filter for sound files */
class SoundFilenameFilter extends FileFilter implements Serializable {
  public boolean accept(File pathname) {
    if (pathname.isDirectory()) {
      return true;
    }
    if (pathname.getName().toLowerCase().endsWith(".wav")) {
      return true;
    }
    if (pathname.getName().toLowerCase().endsWith(".wave")) {
      return true;
    }
    if (pathname.getName().toLowerCase().endsWith(".aiff")) {
      return true;
    }
    if (pathname.getName().toLowerCase().endsWith(".au")) {
      return true;
    }
    if (pathname.getName().toLowerCase().endsWith(".mid")) {
      return true;
    }
    if (pathname.getName().toLowerCase().endsWith(".midi")) {
      return true;
    }
    return false;
  }

  public String getDescription() {
    return "Sound files";
  }
}

/** Thread used for playing sound */
class SoundPlayThread extends Thread implements Serializable {
  /** sound data */
  private byte[] soundData;
  /** sound type */
  private byte soundType = LSound.TYPE_NONE;

  private Sequencer sm_sequencer = null;
  private Synthesizer sm_synthesizer = null;

  /** are we playing ? */
  private boolean isPlaying = false;

  /** cretes play thread on given soundata
   * @param sound sound data */
  public SoundPlayThread(byte[] sound, byte type) {
    soundData = sound;
    soundType = type;
  }

  public void stopPlaying() {
    isPlaying = false;
    if (soundType == LSound.TYPE_MIDI) {
      sm_sequencer.stop();
    }
  }

  public void start() {
    super.start();
    isPlaying = true;
    if (soundType == LSound.TYPE_MIDI) {
      Sequence sequence = null;
      try {
        sequence = MidiSystem.getSequence(new ByteArrayInputStream(soundData));
      } catch (InvalidMidiDataException ex) {
        ex.printStackTrace();
        return;
      } catch (IOException ex) {
        ex.printStackTrace();
        return;
      }

      try {
        sm_sequencer = MidiSystem.getSequencer();
      } catch (MidiUnavailableException e) {
        e.printStackTrace();
        return;
      }
      if (sm_sequencer == null) {
        Utils.sprintln("Can't get a Sequencer");
      }

      sm_sequencer.addMetaEventListener(new MetaEventListener() {
        public void meta(MetaMessage event) {
          if (event.getType() == 47) {
            sm_sequencer.close();
            if (sm_synthesizer != null) {
              sm_synthesizer.close();
              isPlaying = false;
            }
          }
        }
      });

      try {
        sm_sequencer.open();
      } catch (MidiUnavailableException e) {
        e.printStackTrace();
        return;
      }
      try {
        sm_sequencer.setSequence(sequence);
      } catch (InvalidMidiDataException e) {
        return;
      }
      if (! (sm_sequencer instanceof Synthesizer)) {
        try {
          sm_synthesizer = MidiSystem.getSynthesizer();
          sm_synthesizer.open();
          Receiver synthReceiver = sm_synthesizer.getReceiver();
          Transmitter seqTransmitter = sm_sequencer.getTransmitter();
          seqTransmitter.setReceiver(synthReceiver);
        } catch (MidiUnavailableException e) {
          e.printStackTrace();
        }
      }

      sm_sequencer.start();
    }
    ;
  }

  /** runs the thread */
  public void run() {
    if (soundType == LSound.TYPE_SAMPLED) {
      try {
        AudioInputStream stream = AudioSystem.getAudioInputStream(new
            ByteArrayInputStream(soundData));

        AudioFormat format = stream.getFormat();
//        if (format.getEncoding() != AudioFormat.Encoding.PCM_SIGNED) {
//          format = new AudioFormat(
//              AudioFormat.Encoding.PCM_SIGNED,
//              format.getSampleRate(),
//              format.getSampleSizeInBits() * 2,
//              format.getChannels(),
//              format.getFrameSize() * 2,
//              format.getFrameRate(),
//              true); // big endian
//          stream = AudioSystem.getAudioInputStream(format, stream);
//        }

        SourceDataLine.Info info = new DataLine.Info(
            SourceDataLine.class, stream.getFormat(),
            ( (int) stream.getFrameLength() * format.getFrameSize()));
        SourceDataLine line = (SourceDataLine) AudioSystem.getLine(info);
        line.open(stream.getFormat());
        line.start();

        int numRead = 0;
        byte[] buf = new byte[line.getBufferSize()];
        while ( ( (numRead = stream.read(buf, 0,
            buf.length)) >= 0) && isPlaying
            )

        {
          int offset = 0;
          while (offset < numRead) {
            offset += line.write(buf, offset, numRead - offset);
          }
        }
        line.drain();
        line.stop();
        isPlaying = false;
      } catch (Exception ex) {
        ex.printStackTrace();
      }
    } else if (soundType == LSound.TYPE_SAMPLED) {
      while (isPlaying) {}
      ;
    }
  }
}

/** Simple object for playing sampled and midi sound. */

public class LSound extends LObject implements IObject, IAction {
  /** Sound types */
  public static final byte TYPE_NONE = 0;
  public static final byte TYPE_SAMPLED = 1;
  public static final byte TYPE_MIDI = 2;
  /** context menu icons */
  private Icon iconSoundLoad = Library.getGraphics("LSoundMenuSoundLoad.gif");
  private Icon iconSoundRecord = Library.getGraphics(
      "LSoundMenuSoundRecord.gif");
  private Icon iconSoundPlay = Library.getGraphics("LSoundMenuSoundPlay.gif");
  private Icon iconSoundStop = Library.getGraphics("LSoundMenuSoundStop.gif");
  /** sound data */
  private byte[] soundData;
  /** sound type */
  private byte soundType = LSound.TYPE_NONE;
  /** play thread */
  private SoundPlayThread player;

  /** loads given sound data
   * @param filename filename to load sound from */
  protected void loadSound(String filename) {
    try {
      ByteArrayOutputStream baos = new ByteArrayOutputStream();
      File f = new File(filename);
      soundData = new byte[ (int) f.length()];
      new FileInputStream(f).read(soundData);
      if (filename.toLowerCase().endsWith("mid") ||
          filename.toLowerCase().endsWith("midi")
          ) {
        soundType = TYPE_MIDI;
      } else {
        soundType = TYPE_SAMPLED;
      }
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  protected void loadSound(byte[] data, byte type) {
    if (data != null) {
      soundData = data;
      soundType = type;
    }
  }

  /** plays sound */
  public void play() {
    if (player == null) {
      player = new SoundPlayThread(soundData, soundType);
      player.start();
    } else {
      player.stopPlaying();
      player = null;
    }
  }

  /** trigger action */
  public void action() {
    play();
  }

  /** @return true if object should be placed in object library */
  public boolean isLibraryObject() {
    return true;
  }

  /** @return category name in object library */
  public String getDisplayCategory() {
    return "Basic";
  }

  /** @return object name in object library */
  public String getDisplayName() {
    return "Sound";
  }

  /** @return object icon on object library and menus */
  public Icon getRepositoryIcon() {
    return objectHelper.getRepositoryIcon();
  }

  /** @return object context menu items */
  public JMenuItem[] getMenuItems() {
    JMenuItem[] items = new JMenuItem[2];
    items[0] = new JMenuItem("Load sound from file");
    items[0].setIcon(iconSoundLoad);
    items[0].addActionListener(new sk.lomo.elearning.core.event.ActionAdapter() {
      public void actionPerformed(ActionEvent e) {
        JFileChooser jfc = new JFileChooser();
        jfc.addChoosableFileFilter(new SoundFilenameFilter());
        if (jfc.showOpenDialog(null) == jfc.APPROVE_OPTION) {
          loadSound(jfc.getSelectedFile().getAbsolutePath());
          if (player!=null) play();
          player=null;
        }
      }
    });

//    items[1] = new JMenuItem("Record sound");
//    items[1].setIcon(iconSoundRecord);
//    items[1].addActionListener(new sk.lomo.elearning.core.event.ActionAdapter() {
//      public void actionPerformed(ActionEvent e) {
//        SoundRecordDialog dlg = new SoundRecordDialog();
//        Dimension dlgSize = dlg.getPreferredSize();
//        Dimension frmSize = Toolkit.getDefaultToolkit().getScreenSize();
//        dlg.setLocation( (frmSize.width - dlgSize.width) / 2,
//            (frmSize.height - dlgSize.height) / 2);
//        dlg.setModal(true);
//        dlg.pack();
//        dlg.show();
//        loadSound(dlg.getRecordedSound(), TYPE_SAMPLED);
//      }
//    });

    if (player != null) {
      items[1] = new JMenuItem("Stop playing");
      items[1].setIcon(iconSoundStop);
    } else {
      items[1] = new JMenuItem("Start playing");
      items[1].setIcon(iconSoundPlay);
    }
    items[1].addActionListener(new sk.lomo.elearning.core.event.ActionAdapter() {
      public void actionPerformed(ActionEvent e) {
        play();
      }
    });
    if ((soundData!=null) && (soundData.length == 0)) {
      items[1].setEnabled(false);
    }
    return items;
  }

  /** Method to be called after object is placed on a slide */
  public void objectPlacement() {};

  /** Paints the object
   * @param g Graphics to paint to */
  public void paint(Graphics g) {
    super.paint(g);
    if (isDesignMode()) {
      objectHelper.getRepositoryIcon().paintIcon(this, g, 0, 0);
      if (isObjectSelected()) {
        objectHelper.getResizeBorder().paintBorder(this, g, 0, 0, getWidth(),
            getHeight());
      }
    }
  }

  /** @return action specific name */
  public String getActionName() {
    return "Play sound";
  }

  public void setDesignMode(boolean designMode) {
    super.setDesignMode(designMode);
    if (player != null) {
      player.stopPlaying();
      player = null;
    }
  }
}
