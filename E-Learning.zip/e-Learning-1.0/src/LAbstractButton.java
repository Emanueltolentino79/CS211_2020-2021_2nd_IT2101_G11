/**
 * <p>Title: LAbstractButton</p>
 * <p>Description: Class adding IVisible functionality to a JButton.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import sk.lomo.elearning.core.*;
import sk.lomo.elearning.core.interfaces.*;
import sk.lomo.elearning.core.ui.*;

/** Class adding IVisible functionality to a JButton */

public abstract class LAbstractButton extends JButton implements IVisible,
    ITextObject {
  protected ObjectUtils objectHelper = new ObjectUtils(this);
  protected Icon iconText = Library.getGraphics("LAbstractButtonMenuText.gif");
  private boolean initiated = false;

  public LAbstractButton() {
    setRequestFocusEnabled(false);
    setModel(new LButtonModel(this));
  }

  /** Sets the object selection behavior
   * @param selected true if object should be selected */
  public void setObjectSelected(boolean selected) {
    objectHelper.setSelected(selected);
  }

  /** @return true if object has selected behavior */
  public boolean isObjectSelected() {
    return objectHelper.isSelected();
  };
  /** Set object behavior into design mode
   * @param designMode selects design or view mode */
  public void setDesignMode(boolean designMode) {
    objectHelper.setDesignMode(designMode);
  }

  /** @return true if object is in design mode */
  public boolean isDesignMode() {
    return objectHelper.isDesignMode();
  };
  /** @return object icon on object library and menus */
  public Icon getRepositoryIcon() {
    return objectHelper.getRepositoryIcon();
  }

  /** @return default object cursor */
  public Cursor getObjectCursor() {
    return objectHelper.getObjectCursor();
  }

  /** @return default size for drag & drop object placement */
  public Dimension getDefaultSize() {
    return new Dimension(120, 24);
  }

  /** Method to be called after object is placed on a slide */
  public void objectPlacement() {
    initiated = true;
    setSize(getPreferredSize());
  };
  /** @return true if object should be placed in object library */
  public abstract boolean isLibraryObject();

  /** @return category name in object library */
  public abstract String getDisplayCategory();

  /** @return object name in object library */
  public abstract String getDisplayName();

  /** @return object border used for resizing and object selection */
  public ResizeBorder getResizeBorder() {
    return objectHelper.getResizeBorder();
  }

  /** @return object context menu items */
  public JMenuItem[] getMenuItems() {
    JMenuItem[] items = new JMenuItem[1];
    items[0] = new JMenuItem("Button text");
    items[0].setIcon(iconText);
    items[0].addActionListener(new sk.lomo.elearning.core.event.ActionAdapter() {
      public void actionPerformed(ActionEvent e) {
        String newText = JOptionPane.showInputDialog("Button text", getText());
        if (newText != null) {
          setText(newText);
        }
      }
    });
    return items;
  }

  /** Paints the object
   * @param g Graphics to paint to */
  public void paint(Graphics g) {
    super.paint(g);
    if (isDesignMode() && isObjectSelected()) {
      objectHelper.getResizeBorder().paintBorder(this, g, 0, 0, getWidth(),
          getHeight());
    }
  }
  /** overriden for set preferred size */
  public void setText(String text) {
    super.setText(text);
    setSize(getPreferredSize());
  }

  /** overriden for set preferred size */
  public void setFont(Font font) {
    super.setFont(font);
    if (initiated) {
      try {
        setSize(getPreferredSize());
      } catch (Exception ignored) {}
      ;
    }
  }

}
