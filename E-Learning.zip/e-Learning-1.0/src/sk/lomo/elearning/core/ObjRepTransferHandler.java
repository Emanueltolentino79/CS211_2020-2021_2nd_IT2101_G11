package sk.lomo.elearning.core;

/**
 * <p>Title: ObjectRepositoryTransferHandler</p>
 * <p>Description: TransferHandler descendant used by object repository
 * to drag objects from repository onto slide.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import sk.lomo.elearning.core.interfaces.*;
import sk.lomo.elearning.core.ui.*;
import java.awt.datatransfer.*;
import javax.swing.*;
import java.io.*;
import java.util.*;
import java.awt.Point;

/** TransferHandler descendant used by object repository
 * to drag objects from repository onto slide. */

public class ObjRepTransferHandler extends TransferHandler implements
    Transferable, Serializable {
  private String objectClassNameData;
  private boolean isRunTimeObject = false;

  private static final DataFlavor flavors[] = {
      ObjTransferHandler.ObjClassDataFlavor, ObjTransferHandler.ObjRTDataFlavor};

  public int getSourceActions(JComponent c) {
    return TransferHandler.COPY;
  }

  public boolean canImport(JComponent comp, DataFlavor
      flavor[]) {
    return false;
  }

  public Transferable createTransferable(JComponent comp) {
    if (comp instanceof JList) {
      if ( ( ( (JList) comp).getSelectedValue())instanceof ObjectCell) {
        ObjectCell cell = (ObjectCell) ( (JList) comp).getSelectedValue();
        if (cell.isRunTime()) {
          isRunTimeObject = true;
          objectClassNameData = cell.getName();
        } else {
          objectClassNameData = cell.getClassName();
          isRunTimeObject = false;
        }
        return this;
      }
    }
    return null;
  }

  public boolean importData(JComponent comp,
      Transferable t) {
    return false;
  }

  // Transferable
  public Object getTransferData(DataFlavor flavor) {
    if (isDataFlavorSupported(flavor)) {
      if (flavor.equals(ObjTransferHandler.ObjClassDataFlavor)) {
        return objectClassNameData;
      }
      if (flavor.equals(ObjTransferHandler.ObjRTDataFlavor)) {
        return objectClassNameData;
      }
    }
    return null;
  }

  public DataFlavor[] getTransferDataFlavors() {
    return flavors;
  }

  public boolean isDataFlavorSupported(DataFlavor flavor) {
    if (flavor.equals(ObjTransferHandler.ObjClassDataFlavor) &&
        (isRunTimeObject == false)) {
      return true;
    }
    if (flavor.equals(ObjTransferHandler.ObjRTDataFlavor) && (isRunTimeObject)) {
      return true;
    }
    return false;
  }
}
