package sk.lomo.elearning.core.commands;

/**
 * <p>Title: GoToSlideCommand</p>
 * <p>Description: Selects specific slide.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import javax.swing.undo.AbstractUndoableEdit;
import sk.lomo.elearning.core.Lesson;
import sk.lomo.elearning.core.ui.Slide;

/** Selects specific slide. */
public class GoToSlideCommand extends AbstractUndoableEdit {
  Lesson lesson;
  int toSlide, fromSlide;

  public GoToSlideCommand(Lesson l, int to) {
    lesson = l;
    fromSlide = l.getCurrentSlideNumber();
    toSlide = to;
  }

  /** Executes command */
  public void redo() {
    super.redo();
    lesson.setCurrentSlide0(toSlide);
  }

  /** Undoes command */
  public void undo() {
    super.undo();
    lesson.setCurrentSlide0(fromSlide);
  }

  /** @return command description */
  public String getPresentationName() {
    return "Go to slide";
  }
  /** We can undo anytime :-) */
  public boolean canUndo() {  return true;  }

  /** We can redo anytime :-) */
  public boolean canRedo() {  return true;  }

}
