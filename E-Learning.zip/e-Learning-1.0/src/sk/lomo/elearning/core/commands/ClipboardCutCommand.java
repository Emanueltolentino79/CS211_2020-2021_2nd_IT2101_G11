package sk.lomo.elearning.core.commands;

/**
 * <p>Title: Clipboard cut command </p>
 * <p>Description: Cuts objects into clipboard.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */
import java.awt.Component;
import java.util.Iterator;
import sk.lomo.elearning.core.ui.Slide;
import sk.lomo.elearning.core.interfaces.*;
import sk.lomo.elearning.core.*;
import java.awt.event.ActionEvent;
import javax.swing.undo.*;
import javax.swing.JComponent;
import java.util.Vector;
import java.util.HashMap;

/** Cuts objects into clipboard. */

public class ClipboardCutCommand extends AbstractUndoableEdit {
  /** objects to cut */
  private Component[] objects, objectsAll;
  private JVector objectsJV;
  /** transfer handler */
  private ObjTransferHandler transferHandler;
  /** slide */
  private Slide slide;
  /** trigger -> triggerActions that were removed */
  private HashMap oldTriggerActions = new HashMap();

  /** Constructs command
   * @param s slide to paste to
   *  @param t object transfer handlet to paste with
   */
  public ClipboardCutCommand(Slide s, ObjTransferHandler t) {
    slide = s;
    transferHandler = t;
    Vector v = slide.getSelectedObjects();
    objects = new Component[v.size()];
    Iterator i = v.iterator();
    int j=0;
    while (i.hasNext()) objects[j++] = (Component) i.next();
    objectsJV = s.getSelectedObjectsAsJVector();
    objectsAll = s.getComponents();

  }
  /** Executes command */
  public void redo() {
    super.redo();
    transferHandler.getCopyAction().actionPerformed(new ActionEvent(
        objectsJV, 0, "copy"));
    // first save all triggeractions of objects to be removed
    for (int i=0; i<slide.getLesson().getSlidesCount(); i++) {
      Slide s = slide.getLesson().getSlide(i);
      for (int j=0; j<s.getComponentCount(); j++) {
        if (s.getComponent(j)instanceof ITrigger) {
          int count = 0;
          for (int k = 0; k < objects.length; k++) {
            TriggerAction[] actions = ( (ITrigger) s.getComponent(j)).
                getTriggerActions( (JComponent) objects[k]);
            count = count + actions.length;
          }
          TriggerAction[] actions = new TriggerAction[count];
          count = 0;
          for (int k = 0; k < objects.length; k++) {
            TriggerAction[] a = ( (ITrigger) s.getComponent(j)).
                getTriggerActions( (JComponent) objects[k]);
            for (int l = 0; l < a.length; l++)
              actions[count++] = a[l];
          oldTriggerActions.put(s.getComponent(j), actions);
        }

        }
      }
    }
    for (int i=0; i<objects.length; i++) {
      slide.remove(objects[i]);
    }
    transferHandler.getCopyAction().actionPerformed(new ActionEvent(
        objects, 0, "copy"));
    slide.repaint();
  }
  /** Undoes command */
  public void undo() {
    super.undo();
    slide.removeAll();
    for (int i=0; i<objectsAll.length; i++)
      slide.add(objectsAll[i], slide.getComponentCount());

    Iterator i = oldTriggerActions.keySet().iterator();
    while (i.hasNext()) {
      ITrigger t = (ITrigger) i.next();
      TriggerAction[] ta = (TriggerAction[]) oldTriggerActions.get(t);
      for (int j=0; j<ta.length; j++) {
        t.putAction(ta[j]);
      }
    }
    slide.repaint();

  }
  /** @return command description */
  public String getPresentationName() {
    return "Cut objects";
  }
  /** We can undo anytime :-) */
  public boolean canUndo() {  return true;  }

  /** We can redo anytime :-) */
  public boolean canRedo() {  return true;  }
}
