package sk.lomo.elearning.core.commands;

/**
 * <p>Title: ChangeFontCommand </p>
 * <p>Description: Changes font parameters on given objects.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.util.*;

import java.awt.*;
import javax.swing.*;
import javax.swing.undo.*;

import sk.lomo.elearning.core.interfaces.*;

/** Changes font parameters on given objects. */

public class ChangeFontCommand  extends AbstractUndoableEdit {
  private static final int ACTION_NAME = 0;
  private static final int ACTION_SIZE = 1;
  private static final int ACTION_BOLD = 2;

  private int action = ACTION_NAME;
  private Vector objects;
  private HashMap oldFontParams = new HashMap();
  private int newFontSize;
  private String newFontName;
  private boolean newFontBold;
  /** Constructs command
   * @param objects objects to change font on
   * @param fontName new font name   */
  public ChangeFontCommand(Vector objects, String fontName) {
    this.objects = objects;
    newFontName = fontName;
    action = ACTION_NAME;
  }
  /** Constructs command
   * @param objects objects to change font on
   * @param newSize new font size */
  public ChangeFontCommand(Vector objects, int newSize) {
    this.objects = objects;
    newFontSize = newSize;
    action = ACTION_SIZE;
  }
  /** Constructs command
   * @param objects objects to change font on
   * @param bold true to set fonts to bold style */
  public ChangeFontCommand(Vector objects, boolean bold) {
    this.objects = objects;
    newFontBold = bold;
    action = ACTION_BOLD;
  }
  /** Executes command */
  public void redo() {
    super.redo();
    Iterator i = objects.iterator();
    oldFontParams.clear();
    while (i.hasNext()) {
      JComponent o = (JComponent) i.next();
      if (o instanceof ITextObject) {
        Font oldFont;
        Font newFont;
        switch (action) {
          case ACTION_NAME:
            oldFont= ((ITextObject) o).getFont();
            oldFontParams.put(o, oldFont);
            newFont = new Font(
                newFontName, oldFont.getStyle(), oldFont.getSize());
            ((ITextObject) o).setFont(newFont);
            break;
          case ACTION_SIZE:
            oldFont= ((ITextObject) o).getFont();
            oldFontParams.put(o, oldFont);
            ((ITextObject) o).setFont(oldFont.deriveFont((float)newFontSize));
            break;
          case ACTION_BOLD:
            oldFont= ((ITextObject) o).getFont();
            oldFontParams.put(o, oldFont);
            int style = oldFont.getStyle();
            if (newFontBold) style=style | Font.BOLD;
              else style=style & ~Font.BOLD;
            ((ITextObject) o).setFont(oldFont.deriveFont(style));
            break;
        }
      }
    }
  }

  /** Undoes command */
  public void undo() {
    super.undo();
    Iterator i = objects.iterator();
    while (i.hasNext()) {
      JComponent o = (JComponent) i.next();
      if (o instanceof ITextObject) {
        Font oldFont;
        Font newFont;
        switch (action) {
          case ACTION_NAME:
            oldFont = (Font) oldFontParams.get(o);
            ((ITextObject) o).setFont(oldFont);
            break;
          case ACTION_SIZE:
            oldFont = (Font) oldFontParams.get(o);
            ((ITextObject) o).setFont(oldFont);
            break;
          case ACTION_BOLD:
            oldFont = (Font) oldFontParams.get(o);
            ((ITextObject) o).setFont(oldFont);
            break;
        }
      }
    }
  }

  /** @return command description */
  public String getPresentationName() {
    switch (action) {
      case ACTION_NAME:
        return "Change font name";
      case ACTION_SIZE:
        return "Change font size";
      case ACTION_BOLD:
        return "Change font style";
    }
    return "Change font";
  }

  /** We can undo anytime :-) */
  public boolean canUndo() {  return true;  }

  /** We can redo anytime :-) */
  public boolean canRedo() {  return true;  }
}
