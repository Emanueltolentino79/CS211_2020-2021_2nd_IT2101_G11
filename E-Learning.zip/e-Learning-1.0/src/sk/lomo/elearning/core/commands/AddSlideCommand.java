package sk.lomo.elearning.core.commands;

/**
 * <p>Title: AddSlideCommand</p>
 * <p>Description: Adds given slide to a lesson.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import javax.swing.undo.AbstractUndoableEdit;
import sk.lomo.elearning.core.Lesson;
import sk.lomo.elearning.core.ui.Slide;

/** Adds given slide to a lesson. */

public class AddSlideCommand extends AbstractUndoableEdit {
  private Lesson lesson;
  private Slide slide;
  private int position;
  /** Constructs command
   * @param l lesson to add slide to
   * @param s slide to add
   * @param p position to insert slide to
   */

  public AddSlideCommand(Lesson l, Slide s, int p) {
    lesson = l;
    slide = s;
    position = p;
  }

  /** Executes command */
  public void redo() {
    super.redo();
    lesson.addSlide(slide, position);
  }

  /** Undoes command */
  public void undo() {
    super.undo();
    int n = lesson.getCurrentSlideNumber();
    if (n > 0) {
      n--;
    }
    lesson.removeSlide(slide);
    lesson.setCurrentSlide(n);
  }

  /** @return command description */
  public String getPresentationName() {
    return "Add slide";
  }

  /** We can undo anytime :-) */
  public boolean canUndo() {
    return true;
  }

  /** We can redo anytime :-) */
  public boolean canRedo() {
    return true;
  }

}
