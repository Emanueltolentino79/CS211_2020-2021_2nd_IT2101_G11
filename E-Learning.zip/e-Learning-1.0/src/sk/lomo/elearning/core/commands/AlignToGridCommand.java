package sk.lomo.elearning.core.commands;

/**
 * <p>Title: AlignToGridCommand </p>
 * <p>Description: Aligns objects to grid on slide.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.util.*;

import java.awt.*;
import javax.swing.*;
import javax.swing.undo.*;

import sk.lomo.elearning.core.interfaces.*;
import sk.lomo.elearning.core.ui.Slide;

/** Aligns objects to grid on slide. */

public class AlignToGridCommand extends AbstractUndoableEdit {
  private Vector objects;
  private Slide slide;
  private HashMap oldLocations = new HashMap();

  /** Constructs command
   * @param s slide to work on
   * @param o vector of objects to align
   */
  public AlignToGridCommand(Slide s, Vector o) {
    objects = o;
    slide = s;
  }
  /** Executes command */
  public void redo() {
    super.redo();
    Iterator i = objects.iterator();
    oldLocations.clear();
    while (i.hasNext()) {
      JComponent c = (JComponent) i.next();
      oldLocations.put(c,c.getLocation());
      if (!(((((int)c.getLocation().getX()) % slide.getGridSize())==0) &&
       ((((int)c.getLocation().getY()) % slide.getGridSize())==0))) {
      double dx = ((c.getLocation().getX()) / slide.getGridSize()) % 1;
      double dy = ((c.getLocation().getY()) / slide.getGridSize()) % 1;
      int nx;
      int ny;
      if (dx>=0.5) nx = (((int)c.getLocation().getX()) / slide.getGridSize() + 1)*slide.getGridSize();
      else nx = (((int)c.getLocation().getX()) / slide.getGridSize())*slide.getGridSize();
      if (dy>=0.5) ny = (((int)c.getLocation().getY()) / slide.getGridSize() + 1)*slide.getGridSize();
      else ny = (((int)c.getLocation().getY()) / slide.getGridSize())*slide.getGridSize();
      c.setLocation(nx,ny);
      }
    }
  }

  /** Undoes command */
  public void undo() {
    super.undo();
    Iterator i = objects.iterator();
    while (i.hasNext()) {
      JComponent c = (JComponent) i.next();
      c.setLocation((Point)oldLocations.get(c));
    }
  }

  /** @return command description */
  public String getPresentationName() {
    return "Align objects to grid";
  }

  /** We can undo anytime :-) */
  public boolean canUndo() {  return true;  }

  /** We can redo anytime :-) */
  public boolean canRedo() {  return true;  }
}
