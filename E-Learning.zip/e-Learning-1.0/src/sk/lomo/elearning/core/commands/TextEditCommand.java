package sk.lomo.elearning.core.commands;

/**
 * <p>Title: TextEditCommand</p>
 * <p>Description: Removes slide from lesson.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import javax.swing.undo.AbstractUndoableEdit;
import sk.lomo.elearning.core.interfaces.*;
import java.awt.Font;


public class TextEditCommand extends AbstractUndoableEdit {
  private Font of, nf;
  private ITextObject o;
  private String ot, nt;

  /** Constructs command
   * @param object object to undo/redo
   * @param oldText text before editing
   * @param newText text after editing
   * @param oldFont font before editing
   * @param newFont font after editing  */
  public TextEditCommand(ITextObject object, String oldText, String newText,
      Font oldFont, Font newFont) {
    of = oldFont;
    nf = newFont;
    ot = oldText;
    nt = newText;
    o = object;
  }

  /** Executes command */
  public void redo() {
    super.redo();
    o.setFont(nf);
    o.setText(nt);
  }
  /** Undoes command */
  public void undo() {
    super.undo();
    o.setFont(of);
    o.setText(ot);
  }
  /** @return command description */
  public String getPresentationName() {
    return "Edit text";
  }
  /** We can undo anytime :-) */
  public boolean canUndo() {  return true;  }

  /** We can redo anytime :-) */
  public boolean canRedo() {  return true;  }
}