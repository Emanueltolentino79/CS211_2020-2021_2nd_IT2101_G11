package sk.lomo.elearning.core.commands;

/**
 * <p>Title: ChangeObjectColorCommand </p>
 * <p>Description: Changes font size on given objects on slide.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import javax.swing.undo.AbstractUndoableEdit;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.text.*;
import java.beans.*;
import sk.lomo.elearning.core.interfaces.*;
import sk.lomo.elearning.core.ui.Slide;

/** Changes font size on given objects on slide. */

public class ChangeObjectColorCommand extends AbstractUndoableEdit {
  /** defines FOREGROUND color */
  public static final int COLOR_FOREGROUND = 0;
  /** defines BACKGROUND color */
  public static final int COLOR_BACKGROUND = 1;
  private int type = COLOR_FOREGROUND;
  private Vector objects;
  private Color newColor;
  private HashMap oldColors = new HashMap();
  /** Constructs command
 * @param objects objects to change color on
 * @param colorType specifies color (Foreground or Background) to change
 * @param newColor color to set
 */
  public ChangeObjectColorCommand(Vector objects, int colorType, Color newColor) {
    type = colorType;
    this.objects = objects;
    this.newColor = newColor;
  }

  /** Executes command */
  public void redo() {
    super.redo();
    Iterator i = objects.iterator();
    oldColors.clear();
    while (i.hasNext()) {
      JComponent o = (JComponent) i.next();
      if ((o instanceof IVisible) || (o instanceof Slide)){
        if (type==COLOR_BACKGROUND) {
          oldColors.put(o,o.getBackground());
          o.setBackground(newColor);
        } else if (type==COLOR_FOREGROUND) {
          oldColors.put(o,o.getForeground());
            o.setForeground(newColor);
          }
      }
    }
  }

  /** Undoes command */
  public void undo() {
    super.undo();
    Iterator i = objects.iterator();
    while (i.hasNext()) {
      JComponent o = (JComponent) i.next();
      if ((o instanceof IVisible) || (o instanceof Slide)){
        if (type==COLOR_BACKGROUND) {
          o.setBackground((Color)oldColors.get(o));
        } else if (type==COLOR_FOREGROUND) {
            o.setForeground((Color)oldColors.get(o));
          }
      }
    }
  }

  /** @return command description */
  public String getPresentationName() {
    switch (type) {
      case COLOR_BACKGROUND:
        return "Change background color";
      case COLOR_FOREGROUND:
        return "Change foreground color";
    }
    return "Change color";
  }
  /** We can undo anytime :-) */
  public boolean canUndo() {  return true;  }

  /** We can redo anytime :-) */
  public boolean canRedo() {  return true;  }



}
