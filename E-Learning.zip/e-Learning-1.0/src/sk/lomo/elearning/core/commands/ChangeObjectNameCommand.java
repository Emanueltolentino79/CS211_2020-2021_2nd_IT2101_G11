package sk.lomo.elearning.core.commands;

/**
 * <p>Title: ChangeObjectNameCommand </p>
 * <p>Description: Changes object name or slide name.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import javax.swing.*;
import javax.swing.undo.*;

import sk.lomo.elearning.core.ui.*;

/** Changes object name or slide name. */

public class ChangeObjectNameCommand extends AbstractUndoableEdit {
  private JComponent object;
  private String newName;
  private String oldName;
  /** Creates command
   * @param object object to change name of
   * @param newName name to set
   */

  public ChangeObjectNameCommand(JComponent object, String newName ) {
    this.object = object;
    this.newName = newName;
  }

  /** Executes command */
  public void redo() {
    super.redo();
    oldName = object.getName();
    object.setName(newName);
  }

  /** Undoes command */
  public void undo() {
    super.undo();
    object.setName(oldName);
  }

  /** @return command description */
  public String getPresentationName() {
    if (object instanceof Slide) return "Change slide name";
    return "Change object name";
  }
  /** We can undo anytime :-) */
  public boolean canUndo() {  return true;  }

  /** We can redo anytime :-) */
  public boolean canRedo() {  return true;  }

}
