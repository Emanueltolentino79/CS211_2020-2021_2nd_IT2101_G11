package sk.lomo.elearning.core.commands;

/**
 * <p>Title: Move slide command </p>
 * <p>Description: Moves slides inside lesson.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import javax.swing.undo.*;

import sk.lomo.elearning.core.*;

/** Moves slides inside lesson. */
public class MoveSlideCommand extends AbstractUndoableEdit {
  private Lesson lesson;
  private int from, to;

  /** Constructs command
   * @param l lesson to move slides in
   * @param from move from number
   * @param to move to number
   */
  public MoveSlideCommand(Lesson l, int from, int to) {
    lesson = l;
    this.from = from;
    this.to = to;
  }

  /** Executes command */
  public void redo() {
    super.redo();
    lesson.moveSlide(from, to);
  }

  /** Undoes command */
  public void undo() {
    super.undo();
    lesson.moveSlide(to, from);
  }

  /** @return command description */
  public String getPresentationName() {
    return "Move slide";
  }
  /** We can undo anytime :-) */
  public boolean canUndo() {  return true;  }

  /** We can redo anytime :-) */
  public boolean canRedo() {  return true;  }
}
