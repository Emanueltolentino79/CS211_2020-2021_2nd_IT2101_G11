package sk.lomo.elearning.core.commands;

/**
 * <p>Title: Object move command</p>
 * <p>Description: Command for object moving in slide.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.util.*;
import java.awt.*;
import javax.swing.undo.*;

/** Command for object moving in slide. */
public class ObjectMoveCommand extends AbstractUndoableEdit {
  /** Original points and new points in between we are moving objects.*/
  private Point[] originalPoints, newPoints;
  /** Array of components we are moving. */
  private Component[] components;

  /** Creates command with vector of components, original points and new points
   * @param c objects to move
   * @param originalPoints original objects location points
   * @param newPoints new objects location points */
  public ObjectMoveCommand(Vector c, Point[] originalPoints, Point[] newPoints) {
    components = new Component[c.size()];
    Iterator i = c.iterator();
    int j=0;
    while (i.hasNext()) components[j++] = (Component) i.next();
    this.originalPoints = originalPoints;
    this.newPoints = newPoints;
  }
  /** Executes command */
  public void redo() {
    super.redo();
    for (int i=0; i<components.length;i++) {
      components[i].setLocation(newPoints[i]);
    }
  }
  /** Undoes command */
  public void undo() {
    super.undo();
    for (int i=0; i<components.length;i++) {
      components[i].setLocation(originalPoints[i]);
    }
  }
  /** @return command description */
  public String getPresentationName() {
    String oname = "";
//    if (component instanceof IObject)
//      oname = ((IObject)component).getDisplayName();
    return "Move object "+oname;
  }
  /** We can undo anytime :-) */
  public boolean canUndo() {  return true;  }

  /** We can redo anytime :-) */
  public boolean canRedo() {  return true;  }
}
