package sk.lomo.elearning.core.commands;

/**
 * <p>Title: Move slide command </p>
 * <p>Description: Moves slides inside lesson.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.util.*;
import sk.lomo.elearning.core.ui.Slide;
import java.awt.Component;
import javax.swing.undo.AbstractUndoableEdit;

/** Moves slides inside lesson. */
public class ZIndexCommand extends AbstractUndoableEdit {
  /** Constant for recognizing command */
  public static final int ACTION_TO_FRONT = 0;
  /** Constant for recognizing command */
  public static final int ACTION_TO_BACK = 1;
  /** Slide to work on */
  private Slide slide;
  /** Objects to change zindex on */
  private Vector objects;
  /** command */
  private int action;
  /** old objects */
  Component[] oldObjects;

  public ZIndexCommand(Slide s, Vector o, int a) {
    slide = s;
    objects = o;
    action = a;
  }
  /** Executes command */
  public void redo() {
    super.redo();
    oldObjects = (Component[]) slide.getComponents();
    switch (action) {
      case ACTION_TO_FRONT:
        for (int i=0; i<objects.size(); i++)
          slide.bringToFront((Component) objects.get(i));
        break;
      case ACTION_TO_BACK:
        for (int i=objects.size()-1; i==0; i--)
          slide.sendToBack((Component) objects.get(i));
        break;
    }
  }
  /** Undoes command */
  public void undo() {
    super.undo();
    slide.removeAll();
    for (int i=0; i<oldObjects.length; i++ ) {
      slide.add((Component) oldObjects[i], i);
    }
  }
  /** @return command description */
  public String getPresentationName() {
    switch (action) {
      case ACTION_TO_FRONT:
        return "Bring objects to front";
      case ACTION_TO_BACK:
        return "Send objects to back";
      default:
        return "";
    }
  }
  /** We can undo anytime :-) */
  public boolean canUndo() {  return true;  }

  /** We can redo anytime :-) */
  public boolean canRedo() {  return true;  }

}
