package sk.lomo.elearning.core.commands;

/**
 * <p>Title: SlideAddObjectCommand</p>
 * <p>Description: Command for adding objects to slide.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.awt.Component;
import sk.lomo.elearning.core.ui.Slide;
import sk.lomo.elearning.core.interfaces.IObject;
import javax.swing.undo.*;

/** Command for adding objects to slide. */
public class SlideAddObjectCommand extends AbstractUndoableEdit {
  /** slide to which we add object */
  private Slide slide;
  /** object we add */
  private Component component;
  /** z-index of object we add */
  private int index;

  /** Constructs command
   * @param s slide to which we add object
   * @param c object to add
   * @param i index position of object to add
   */
  public SlideAddObjectCommand(Slide s, Component c, int i) {
    this.slide=s;
    this.component=c;
    this.index=i;
  }
  /** Executes command */
  public void redo() {
    super.redo();
    slide.add(component, index);
  }
  /** Undoes command */
  public void undo() {
    super.undo();
    slide.remove(component);
  }
  /** @return command description */
  public String getPresentationName() {
    String oname = "";
    if (component instanceof IObject)
      oname = ((IObject)component).getDisplayName();
    return "Add object "+oname;
  }

  /** We can undo anytime :-) */
  public boolean canUndo() {  return true;  }

  /** We can redo anytime :-) */
  public boolean canRedo() {  return true;  }
}
