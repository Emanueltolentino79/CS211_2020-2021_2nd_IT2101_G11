package sk.lomo.elearning.core.commands;

/**
 * <p>Title: ClipboardPasteCommand</p>
 * <p>Description: Paste objects from clipboard onto slide.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.awt.Component;
import java.util.Iterator;
import sk.lomo.elearning.core.ui.Slide;
import java.util.Vector;
import sk.lomo.elearning.core.ObjTransferHandler;
import java.awt.event.ActionEvent;
import javax.swing.undo.*;

/** Paste objects from clipboard onto slide. */
public class ClipboardPasteCommand extends AbstractUndoableEdit {
  /** objects to cut */
  private Vector objects;
  /** transfer handler */
  private ObjTransferHandler transferHandler;
  /** slide */
  private Slide slide;

  /** Constructs command
   * @param s slide to paste to
   *  @param t object transfer handlet to paste with
   */
  public ClipboardPasteCommand(Slide s, ObjTransferHandler t) {
    slide = s;
    transferHandler = t;
  }
  /** Executes command */
  public void redo() {
    super.redo();
    try {
      slide.clearSelection();
      if (transferHandler.getPasteAction()!=null) {
        transferHandler.getPasteAction().actionPerformed(new ActionEvent(
            slide, 0, "paste"));
        objects = slide.getSelectedObjects();
      }
    } catch (Exception e) { e.printStackTrace();};
    slide.repaint();
  }
  /** Undoes command */
  public void undo() {
    super.undo();
    Iterator i = objects.iterator();
    while (i.hasNext()) {
      slide.remove((Component) i.next());
    }
    slide.repaint();
  }
  /** @return command description */
  public String getPresentationName() {
    return "Paste objects";
  }
  /** We can undo anytime :-) */
  public boolean canUndo() {  return true;  }

  /** We can redo anytime :-) */
  public boolean canRedo() {  return true;  }
}
