package sk.lomo.elearning.core.commands;

/**
 * <p>Title: EventableUndoManager</p>
 * <p>Description: <code>UndoManager</code> descendant modified for sending events when
 * some useful events occur.</p>
 * <p>Author: Julius Loman</p>
 * @version 1.0
 */

import javax.swing.event.*;
import javax.swing.undo.*;

import sk.lomo.elearning.core.event.*;

/** UndoManager descendant modified for sending events when some useful events occur. */
public class EventableUndoManager extends UndoManager {
  /** Action listeners */
  private EventListenerList events = new EventListenerList();

  public void addUndoRedoListener(UndoRedoListener l) {
    events.add(UndoRedoListener.class, l);
  }

  public void removeUndoRedoListener(UndoRedoListener l) {
    events.remove(UndoRedoListener.class, l);
  }

  protected void fireUndoPerformed() {
    for (int i=0;i<events.getListenerCount();i++) {
      ((UndoRedoListener)events.getListeners(UndoRedoListener.class)[i]).undoPerformed(this);
    }
  }

  protected void fireRedoPerformed() {
    for (int i=0;i<events.getListenerCount();i++) {
      ((UndoRedoListener)events.getListeners(UndoRedoListener.class)[i]).redoPerformed(this);
    }
  }

  protected void fireUndoableEditAdded() {
    for (int i=0;i<events.getListenerCount();i++) {
      ((UndoRedoListener)events.getListeners(UndoRedoListener.class)[i]).undoableEditAdded(this);
    }
  }

  protected void fireEditsDiscarded() {
    for (int i=0;i<events.getListenerCount();i++) {
      ((UndoRedoListener)events.getListeners(UndoRedoListener.class)[i]).editsDiscarded(this);
    }
  }

  public boolean addEdit(UndoableEdit edit) {
    boolean retval = super.addEdit(edit);
    fireUndoableEditAdded();
    return retval;
  }

  public void undo() {
    super.undo();
    fireUndoPerformed();
  }

  public void redo() {
    super.redo();
    fireRedoPerformed();
  }

  public void discardAllEdits() {
    super.discardAllEdits();
    fireEditsDiscarded();
  }
}
