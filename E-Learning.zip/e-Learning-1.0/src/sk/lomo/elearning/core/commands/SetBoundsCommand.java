package sk.lomo.elearning.core.commands;

/**
 * <p>Title: SetBoundsCommand</p>
 * <p>Description: Command for setting object bouds (size)</p>
 * <p>Author: Julius Loman</p>
 * @version 1.0
 */

import java.awt.*;
import javax.swing.*;
import javax.swing.undo.*;

/** Command for setting object bouds (size) */
public class SetBoundsCommand extends AbstractUndoableEdit {
  JComponent object;
  Rectangle newBounds, oldBounds;

  public SetBoundsCommand(JComponent c) {
    object = c;
  }

  /** Sets old object bounds
   * @param ob old bounds
   */
  public void setOldBounds(Rectangle ob) {
    oldBounds = ob;
  }

  /** Sets new object bounds
   * @param nb new bounds
   */
  public void setNewBounds(Rectangle nb) {
    newBounds = nb;
  }

  /** Executes command */
  public void redo() {
    super.redo();
    object.setBounds(newBounds);
  }

  /** Undoes command */
  public void undo() {
    super.undo();
    object.setBounds(oldBounds);
  }

  /** @return command description */
  public String getPresentationName() {
    return "Resize object";
  }
  /** We can undo anytime :-) */
  public boolean canUndo() {  return true;  }

  /** We can redo anytime :-) */
  public boolean canRedo() {  return true;  }

}
