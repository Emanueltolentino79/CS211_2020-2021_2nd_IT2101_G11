package sk.lomo.elearning.core.commands;
/**
 * <p>Title: Delete slide command </p>
 * <p>Description: Removes slide from lesson.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import javax.swing.undo.AbstractUndoableEdit;
import sk.lomo.elearning.core.Lesson;
import sk.lomo.elearning.core.ui.Slide;

/** Removes slide from lesson. */
public class RemoveSlideCommand extends AbstractUndoableEdit {
  private Lesson lesson;
  private Slide slide;
  private int position;
  /** Constructs command
   * @param l lesson to remove slide from
   * @param s slide to remove
   */
  public RemoveSlideCommand(Lesson l, Slide s) {
    lesson = l;
    slide = s;
  }
  /** Executes command */
  public void redo() {
    super.redo();
    position = lesson.getSlidePosition(slide);
    int n =lesson.getSlidePosition(slide);
    if (n>0) n--;
    lesson.removeSlide(slide);
    lesson.setCurrentSlide(n);
  }
  /** Undoes command */
  public void undo() {
    super.undo();
    lesson.addSlide(slide, position);
  }
  /** @return command description */
  public String getPresentationName() {
    return "Remove slide";
  }
  /** We can undo anytime :-) */
  public boolean canUndo() {  return true;  }

  /** We can redo anytime :-) */
  public boolean canRedo() {  return true;  }
}
