package sk.lomo.elearning.core.commands;

/**
 * <p>Title: ClipboardSlideCutCommand </p>
 * <p>Description: Cut slide into clipboard.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */
import java.awt.Component;
import java.util.Iterator;
import sk.lomo.elearning.core.*;
import sk.lomo.elearning.core.ui.Slide;
import sk.lomo.elearning.core.JVector;
import sk.lomo.elearning.core.ObjTransferHandler;
import java.awt.event.ActionEvent;
import javax.swing.undo.*;
import java.io.*;

/** Cut slide into clipboard. */

public class SlideDuplicateCommand extends AbstractUndoableEdit {
  private Lesson lesson;
  private Slide slide;
  private Slide copiedSlide;
  private int position;
  private ObjTransferHandler th = new ObjTransferHandler(null);
  /** Constructs command
   * @param s slide to cut
   * @param l lesson to cut from
   */
  public SlideDuplicateCommand(Lesson l, Slide s) {
    lesson = l;
    slide = s;
    position = l.getSlidePosition(s);
  }
  /** Constructs command
   * @param s slide number to cut
   * @param l lesson to cut from
   */
  public SlideDuplicateCommand(Lesson l, int s) {
    lesson = l;
    slide = l.getSlide(s);
    position = s;
  }
  /** Executes command */
  public void redo() {
    byte objectData[];

    super.redo();
    try {
      ByteArrayOutputStream baos = new ByteArrayOutputStream();
      ObjectOutputStream oos = new ObjectOutputStream(baos);

      oos.writeObject(slide);
      oos.close();

      objectData = baos.toByteArray();
      ObjectInputStream ois = new LObjectInputStream(new ByteArrayInputStream(objectData));
      Object o = ois.readObject();
      copiedSlide = (Slide) o;

      lesson.addSlide(copiedSlide, position+1);
      lesson.goToSlide(position+1);

    } catch (IOException e) {
      sk.lomo.elearning.Utils.sprintln("Exception while duplicating slide: "+e.getLocalizedMessage());
    } catch (ClassNotFoundException ex) {
      sk.lomo.elearning.Utils.sprintln("Exception while duplicating slide: "+ex.getLocalizedMessage());
    };
  }
  /** Undoes command */
  public void undo() {
    super.undo();
    lesson.removeSlide(copiedSlide);
  }
  /** @return command description */
  public String getPresentationName() {
    return "Duplicate slide";
  }
  /** We can undo anytime :-) */
  public boolean canUndo() {  return true;  }

  /** We can redo anytime :-) */
  public boolean canRedo() {  return true;  }

}
