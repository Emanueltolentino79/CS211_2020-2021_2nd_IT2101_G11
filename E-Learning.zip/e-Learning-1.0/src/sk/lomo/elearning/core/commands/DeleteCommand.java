package sk.lomo.elearning.core.commands;

/**
 * <p>Title: Delete objects command </p>
 * <p>Description: Removes objects from slide.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.util.*;

import java.awt.*;
import javax.swing.*;
import javax.swing.undo.*;

import sk.lomo.elearning.core.*;
import sk.lomo.elearning.core.ui.*;
import sk.lomo.elearning.core.interfaces.*;

/** Removes objects from slide. */
public class DeleteCommand extends AbstractUndoableEdit {
  /** slide to delete objects from */
  private Slide slide;
  /** objects to delete */
  private Component[] objects, objectsAll;
  /** trigger -> triggerActions that were removed */
  private HashMap oldTriggerActions = new HashMap();

  public DeleteCommand(Slide s) {
    this.slide = s;
    Vector v = slide.getSelectedObjects();
    objects = new Component[v.size()];
    Iterator i = v.iterator();
    int j=0;
    while (i.hasNext()) objects[j++] = (Component) i.next();

    objectsAll = s.getComponents();
  }
  /** Executes command */
  public void redo() {
    super.redo();
    // first save all triggeractions of objects to be removed
    for (int i=0; i<slide.getLesson().getSlidesCount(); i++) {
      Slide s = slide.getLesson().getSlide(i);
      for (int j=0; j<s.getComponentCount(); j++) {
        if (s.getComponent(j)instanceof ITrigger) {
          int count = 0;
          for (int k = 0; k < objects.length; k++) {
            TriggerAction[] actions = ( (ITrigger) s.getComponent(j)).
                getTriggerActions( (JComponent) objects[k]);
            count = count + actions.length;
          }
          TriggerAction[] actions = new TriggerAction[count];
          count = 0;
          for (int k = 0; k < objects.length; k++) {
            TriggerAction[] a = ( (ITrigger) s.getComponent(j)).
                getTriggerActions( (JComponent) objects[k]);
            for (int l = 0; l < a.length; l++)
              actions[count++] = a[l];
          oldTriggerActions.put(s.getComponent(j), actions);
        }

        }
      }
    }
    for (int i=0; i<objects.length; i++) {
      slide.remove(objects[i]);
    }
    slide.repaint();
  }
  /** Undoes command */
  public void undo() {
    super.undo();
    slide.removeAll();
    for (int i=0; i<objectsAll.length; i++)
      slide.add(objectsAll[i], slide.getComponentCount());

    Iterator i = oldTriggerActions.keySet().iterator();
    while (i.hasNext()) {
      ITrigger t = (ITrigger) i.next();
      TriggerAction[] ta = (TriggerAction[]) oldTriggerActions.get(t);
      for (int j=0; j<ta.length; j++) {
        t.putAction(ta[j]);
      }
    }
    slide.repaint();
  }
  /** @return command description */
  public String getPresentationName() {
    return "Delete objects";
  }
  /** We can undo anytime :-) */
  public boolean canUndo() {  return true;  }

  /** We can redo anytime :-) */
  public boolean canRedo() {  return true;  }

}
