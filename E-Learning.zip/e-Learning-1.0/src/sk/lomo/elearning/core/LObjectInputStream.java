package sk.lomo.elearning.core;

import java.io.ObjectInputStream;
import java.io.InputStream;
import java.io.IOException;
import java.io.StreamCorruptedException;
import java.io.ObjectStreamClass;
import java.lang.reflect.Proxy;

/** Load classes with the specified classloader. */
public class LObjectInputStream extends ObjectInputStream {
  private ClassLoader m_classLoader;
  /**
   * Creates an instance of this ObjectInputStream that will load classes with the specified classloader
   * @param stream input stream to read from
   * @throws StreamCorruptedException
   * @throws IOException
   */
  public LObjectInputStream(InputStream stream) throws IOException, StreamCorruptedException {
    super(stream);
    m_classLoader = new FileObjectClassLoader(Library.directory);
  }
  /** Resolve class, finds and loads class specified in osc.
   * @param osc class in object stream
   * @throws IOException
   * @throws ClassNotFoundException
   * @return loaded class
   * */
  protected Class resolveClass(ObjectStreamClass osc) throws IOException,
      ClassNotFoundException {
    String name = osc.getName();
    return loadClass(name);
  }
  /** Resolve proxy class, finds and loads class specified in osc.
   * @throws IOException
   * @throws ClassNotFoundException
   * @param interfaces interfaces to resolve
   * @return loaded class
   * */
  protected Class resolveProxyClass(String[] interfaces) throws IOException,
      ClassNotFoundException {
    Class[] classes = new Class[interfaces.length];
    for (int i = 0; i < interfaces.length; ++i) {
      classes[i] = loadClass(interfaces[i]);
    }
    if (m_classLoader != null) {
      return Proxy.getProxyClass(m_classLoader, classes);
    } else {
      return Proxy.getProxyClass(Thread.currentThread().getContextClassLoader(),
          classes);
    }
  }
  /** Loads class with given name
   * @param name class name to load
   * @throws ClassNotFoundException
   * @return loaded class
   * */
  private Class loadClass(String name) throws ClassNotFoundException {
    if (m_classLoader != null) {
      return m_classLoader.loadClass(name);
    }
    return null;
  }
}