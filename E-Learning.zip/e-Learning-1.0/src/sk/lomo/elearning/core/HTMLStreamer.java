package sk.lomo.elearning.core;

/**
 * <p>Title: HTML Streamer</p>
 * <p>Description: Class for generating HTML page from template</p>
 * <p>Author: Julius Loman</p>
 * @version 1.0
 */

import java.io.*;
import java.util.*;

/**
 * reads files of any type and replaces on string tag with another
 */

public class HTMLStreamer {

  private Hashtable h = null;
  private ByteArrayOutputStream _result = null;
  private String SearchString = "%%";
  private boolean SubAll = false;

  public HTMLStreamer() throws IOException {
  }

  /**
   *
   * @param suball true if all %%%% should be removed
   * @param searchstring instead of %%
   * @throws IOException in the case of can't read the stream
   */
  public HTMLStreamer(boolean suball, String searchstring) throws IOException {
    SubAll = suball;
    SearchString = searchstring;
  }

  /**
   * Changes files
   * @param filename name of the file
   * @param out Output
   * @throws IOException in the case of can't read the stream
   */
  public HTMLStreamer(String filename, PrintWriter out) throws IOException {
//    ConvertSubst(new String[] {}
//        , new String[] {});
    HTMLStream(filename, out);
  }

  public String result() {
    try {
      _result.flush();
      return (_result.toString());
    } catch (Exception ex) {
      return null;
    }
  }

  public HTMLStreamer(String filename, PrintWriter out,
      String[] SubstParam, String[] SubstEntry) throws IOException {
    ConvertSubst(SubstParam, SubstEntry);
    HTMLStream(filename, out);
  }

  public HTMLStreamer(String filename, boolean suball) throws IOException {
    SubAll = suball;
    //ByteArrayOutputStream os = new ByteArrayOutputStream ();
    _result = new ByteArrayOutputStream();
    PrintWriter out = new PrintWriter(_result);
    ConvertSubst(new String[] {}
        , new String[] {});
    HTMLStream(filename, out);
    out.flush();
    //os.flush();
    //_result = os.toString();
  }

  public HTMLStreamer(String filename) throws IOException {
    //ByteArrayOutputStream os = new ByteArrayOutputStream ();
    _result = new ByteArrayOutputStream();
    PrintWriter out = new PrintWriter(_result);
    ConvertSubst(new String[] {}
        , new String[] {});
    HTMLStream(filename, out);
    out.flush();
    //os.flush();
    //_result = os.toString();
  }

  /**
   * Reads a file, and replaces %%parameter%% (SubstParam) with the spezified values
   * in SubstEntry
   * @param filename filename which should be changed
   * @param SubstParam Stringarray with all parameternames
   * @param SubstEntry Stringarray with all parametervalues
   * @throws IOException in the case that the stream can't be read
   */
  public HTMLStreamer(String filename,
      String[] SubstParam, String[] SubstEntry) throws IOException {
    //ByteArrayOutputStream os = new ByteArrayOutputStream ();
    _result = new ByteArrayOutputStream();
    PrintWriter out = new PrintWriter(_result);
    ConvertSubst(SubstParam, SubstEntry);
    HTMLStream(filename, out);
    out.flush();
    //os.flush();
    //_result = os.toString();
  }

  public HTMLStreamer(String filename,
      String[] SubstParam, String[] SubstEntry,
      boolean suball) throws IOException {
    SubAll = suball;
    //ByteArrayOutputStream os = new ByteArrayOutputStream ();
    _result = new ByteArrayOutputStream();
    PrintWriter out = new PrintWriter(_result);
    ConvertSubst(SubstParam, SubstEntry);
    HTMLStream(filename, out);
    out.flush();
    //os.flush();
    //_result = os.toString();
  }

  //Added by L.g.
  /**
   * Sets the parameter/value pair for the next replacement
   * call replace after this method
   * @param SubstParam Stringarray with all parameternames
   * @param SubstEntry Stringarray with all parametervalues
   * @throws IOException in the case that the stream can't be read
   */
  public void setParam(String[] SubstParam,
      String[] SubstEntry) throws IOException {
    ConvertSubst(SubstParam, SubstEntry);
  }

  /**
   * Starts with the replacement.
   * The parameter/value pair must be set before with setParam method
   * @param replacestring String with the parameter which should be replaced
   * @param out           PrintWriter where result is being stored
   * @throws IOException in the case that the stream can't be read
   */
  public void replace(String replacestring, PrintWriter out) throws IOException {
    /*BufferedReader reader =
     new BufferedReader ( new StringReader ( replacestring ) );
         ReadLines( reader, out );
         reader.close();*/
    StringBuffer sb = new StringBuffer(replacestring);
    SubstLineBuffer(sb);
    out.print(sb.toString());
  }

  /**
   * Starts with the replacement.
   * The parameter/value pair must be set before with setParam method
   * @param replacestring String with the parameter which should be replaced
   * @param out           PrintWriter where result is being stored
   * @throws IOException in the case that the stream can't be read
   */
  public void replace(StringBuffer replacestring) throws IOException {
    SubstLineBuffer(replacestring);
  }

  /**
   * Substitute a line
   * @param Line
   * @return the corrected lines
   */
  private void SubstLineBuffer(StringBuffer Line) {
    //int Start = Line.indexOf( SearchString );

    int Start = Line.toString().indexOf(SearchString);
    //int Start = Line.indexOf( SearchString );

    int searchlen = SearchString.length();
    while (Start != -1) {
      int End = Line.toString().indexOf(SearchString, Start + searchlen); //2
      if (End != -1) {
        // now get the substition name
        String Param = Line.substring(Start + searchlen, End); //2
        // is the subst-name in the hash table?
        String SubstEntry = (String) h.get(Param);
        if (SubstEntry != null) {
          // if yes substitute fields
          //Line = Line.substring( 0, Start ) + SubstEntry + Line.substring( End + SearchString.length()  );
          Line = Line.replace(Start, End + searchlen, SubstEntry);
          Start = Line.toString().indexOf(SearchString,
              End - (Param.length() + 2 * searchlen) + SubstEntry.length());
        } else {
          // if not delete fields
          if (SubAll) {
            //Line = Line.substring( 0, Start ) + Line.substring( End + SearchString.length() );
            Line = Line.replace(Start, End + searchlen, "");
            Start = Line.toString().indexOf(SearchString);
          } else {

            Start = Line.toString().indexOf(SearchString, End + searchlen);
          }
        }
      } else {
        // something went wrong - no end found!
        Start = -1;
      }
    }
  }

  /**
   * Sets all existing Parameters with this replace string
   * (not used yet)
   * @param replacestring String with the parameter which should be replaced
   * @param replace value
   * @param out PrintWriter where result is being stored
   * @throws IOException in the case that the stream can't be read
   */
  public void removeParameter(String replacestring, String replace,
      PrintWriter out) throws IOException {
    ConvertSubst(new String[] {}
        , new String[] {
        replace});
    replace(replacestring, out);
    out.flush();
  }

  /**
   * Set the Parameters
   * @param SubstParam Stringarray with all parameternames
   * @param SubstEntry  Stringarray with all parametervalues
   */
  private void ConvertSubst(String[] SubstParam, String[] SubstEntry) {
    h = new Hashtable();
    if (SubstParam != null) {
      for (int i = 0; i < SubstParam.length; i++) {
        h.put(SubstParam[i],
            (SubstEntry[i] == null ? new String("") : SubstEntry[i]));
      }
    }
  }

  /**
   * Parses every line and call SubstLine
   * @param reader
   * @param out
   */
  private void ReadLines(BufferedReader reader,
      PrintWriter out) throws IOException {
    StringBuffer s1 = new StringBuffer(10000);
    String line;
    //while ((s1= new StringBuffer(reader.readLine())) != null)
    while ( (line = reader.readLine()) != null) {
      s1 = new StringBuffer(line);
      SubstLineBuffer(s1);
      out.println(s1.toString());
    }
  }

  /**
   * Substitute a line - Don't use this anymore
   * @param Line
   * @return the corrected lines
   * @deprectated
   */
  /*private StringBuffer SubstLine ( StringBuffer Line ) {
    //int Start = Line.indexOf( SearchString );
    int Start = Line.indexOf( SearchString );
    int searchlen = SearchString.length();
    while (Start != -1)
    {
     int End = Line.indexOf( SearchString, Start + searchlen );   //2
     if (End != -1)
     {
      // now get the substition name
      String Param = Line.substring(Start+searchlen, End);  //2
      // is the subst-name in the hash table?
      String SubstEntry = (String) h.get( Param );
      if (SubstEntry != null)
      {
        // if yes substitute fields
        //Line = Line.substring( 0, Start ) + SubstEntry + Line.substring( End + SearchString.length()  );
        Line = Line.replace( Start, End + searchlen, SubstEntry );
       Start = Line.indexOf( SearchString , End - (Param.length() + 2*searchlen ) + SubstEntry.length() );
      }
      else
      {
        // if not delete fields
        if (SubAll) {
        //Line = Line.substring( 0, Start ) + Line.substring( End + SearchString.length() );
        Line = Line.replace( Start,  End + searchlen, "" );
        Start = Line.indexOf ( SearchString );
        } else
         Start = Line.indexOf ( SearchString , End + searchlen );
      }
     }
     else
     {
      // something went wrong - no end found!
      Start = -1;
     }
    }
    return ( Line );
    }*/

  private void HTMLStream(String filename, PrintWriter out) throws IOException {
    FileInputStream in = new FileInputStream(filename);
    BufferedReader reader = new BufferedReader(new InputStreamReader(in));
    ReadLines(reader, out);
    reader.close();
    in.close();
  }
}
