package sk.lomo.elearning.core;

/**
 * <p>Title: Hyperlink object</p>
 * <p>Description: Hyperlink navigation between slides and to URLs</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.net.*;
import sk.lomo.elearning.core.ui.WebBrowser;

class BrowserThread extends Thread {
  /** browser to show */
  WebBrowser browser;

  public BrowserThread(URL url) {
    browser = new WebBrowser(url);
  }

  public void start() {
    browser.show();
    super.start();
  }

  /** runs the thread */
  public void run() {

  }
}

/** Hyperlink navigation between slides and to URL */

public class Hyperlink implements java.io.Serializable {
  /** No hyperlink navigation */
  public static final int HYPERLINK_NONE = 0;
  /** Hyperlink navigation to URL */
  public static final int HYPERLINK_URL = 1;
  /** Hyperlink navigation to slide */
  public static final int HYPERLINK_SLIDE = 2;
  /** Hyperlink navigation to next slide */
  public static final int HYPERLINK_NEXTSLIDE = 3;
  /** Hyperlink navigation to previous slide */
  public static final int HYPERLINK_PREVSLIDE = 4;
  /** Hyperlink navigation to first slide */
  public static final int HYPERLINK_FIRSTSLIDE = 5;

  /** Hyperlink navigation  */
  private int type = HYPERLINK_NONE;
  /** Hyperlink navigation destination slide */
  private int slideDest = 0;
  /** Hyperlink navigation URL destination */
  private URL urlDest;

  /** Creates a hyperlink with given destination type
   * @param type destination type*/
  public Hyperlink(int type) {
    this.type = type;
  }

  /** @return hyperlink navigation type */
  public int getHyperlinkType() {
    return this.type;
  }

  /** Sets hyperlink navigation type
   * @param hyperlinkType hyperlink navigation type */
  public void setHyperlinkType(int hyperlinkType) {
    this.type = hyperlinkType;
  }

  /** Sets no hyperlink navigation */
  public void clearHyperlink() {
    type = HYPERLINK_NONE;
  }

  /** @return slide destination */
  public int getHyperlinkSlideDest() {
    return slideDest;
  }

  /** @return URL destination */
  public URL getHyperlinkURLDest() {
    return urlDest;
  }

  /** Sets slide destination
   * @param slideNumber destination slide number */
  public void setSlideDest(int slideNumber) {
    this.slideDest = slideNumber;
  }

  /** Sets URL destination
   * @param url destination url */
  public void setURLDest(URL url) {
    this.urlDest = url;
  }

  /** Follows hyperlink
   * @param l lesson to operate in */
  public void followHyperlink(Lesson l) {
    if (getHyperlinkType() == HYPERLINK_NEXTSLIDE) {
      l.goToNextSlide();
    }
    if (getHyperlinkType() == HYPERLINK_PREVSLIDE) {
      l.goToPrevSlide();
    }
    if (getHyperlinkType() == HYPERLINK_SLIDE) {
      l.goToSlide(getHyperlinkSlideDest());
    }
    if (getHyperlinkType() == HYPERLINK_FIRSTSLIDE) {
      l.goToSlide(0);
    }
    if ( (getHyperlinkType() == HYPERLINK_URL) && (getHyperlinkURLDest() != null)) {
      if (l.getAppletContext() != null) {
        sk.lomo.elearning.Utils.sprintln("Following URL hyperlink " +
            getHyperlinkURLDest());
        l.getAppletContext().showDocument(getHyperlinkURLDest(), "_new");
      } else {
        new BrowserThread(getHyperlinkURLDest()).start();
      }
    }

  }
}
