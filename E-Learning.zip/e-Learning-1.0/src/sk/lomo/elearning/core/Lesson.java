package sk.lomo.elearning.core;

/**
 * <p>Title: Lesson object</p>
 * <p>Description: Lesson is the main object representing document, encapsulating it's pages - slides.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.applet.*;
import java.io.*;
import java.util.*;

import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.swing.event.*;

import sk.lomo.elearning.core.commands.*;
import sk.lomo.elearning.core.event.*;
import sk.lomo.elearning.core.interfaces.*;
import sk.lomo.elearning.core.ui.*;
import sk.lomo.elearning.Utils;

/** Lesson is the main object representing document, encapsulating it's pages - slides. */

public class Lesson implements IBase, Serializable {
  /** Lesson's slides */
  private Vector slides = new Vector();
  /** Current slide */
  private Slide currentSlide = null;
  /** Default slide for new slide (*/
  private byte[] defaultSlide;
  /** Lesson name */
  private String title = "";
  /** Slide change notifiers */
  private transient EventListenerList slideChangeEventList = new
      EventListenerList();
  /** Lesson (Slides) size */
  private Dimension size;
  /** Design mode */
  private boolean designMode;
  /** Lesson comment */
  private String description;
  /** Command manager for undo/redo */
  public transient EventableUndoManager commandManager = new
      EventableUndoManager();
//  /** Library for object creatin (drag & drop) */
//  public transient Library library;
  /** default values for object creation */
  private Color defaultFgColor;
  private Color defaultBgColor;
  private Font defaultFont;
  /** true if design grid should be painted */
  private boolean showGrid = true;
  /** true if navigation is enabled in view mode */
  private boolean enableNavigation;
  /** AppletContext when running as applet */
  private transient AppletContext appletContext;
  /** Create lesson */
  public Lesson() {
  }

  /** Adds a slide change listener
   * @param event slide change event */
  public void addSlideChangeListener(SlideChangeListener event) {
    if (slideChangeEventList == null) {
      slideChangeEventList = new EventListenerList();
    }
    slideChangeEventList.add(SlideChangeListener.class, event);
  }

  /** Removes a slide change listener
   * @param event slide change event */
  public void removeSlideChangeListener(SlideChangeListener event) {
    if (slideChangeEventList == null) {
      slideChangeEventList = new EventListenerList();
    }
    slideChangeEventList.remove(SlideChangeListener.class, event);
  }

  /** Fires a slide change
   * @param from Slide to leave
   * @param to Slide to display */
  public void fireSlideChange(Slide from, Slide to) {
    for (int i = 0; i < slideChangeEventList.getListenerCount(); i++) {
      ( (SlideChangeListener) slideChangeEventList.getListeners(
          SlideChangeListener.class)[i]).slideChanged(from, to);
    }

    if (!designMode) {
      if ( (to != null) && (from != to)) {
        to.fireSlideChangeTriggerActions();
      }
    }
    currentSlide = to;
  }

  /** Fires a slide change */
  public void fireSlideChange() {
    for (int i = 0; i < slideChangeEventList.getListenerCount(); i++) {
      ( (SlideChangeListener) slideChangeEventList.getListeners(
          SlideChangeListener.class)[i]).slideChanged(getCurrentSlide(), getCurrentSlide());
    }
  }


  /** Fires a slide object selection change
   * @param onSlide Slide to change selection on */
  public void fireSlideSelectionChange(Slide onSlide) {
    if (slideChangeEventList!=null)
    for (int i = 0; i < slideChangeEventList.getListenerCount(); i++) {
      ( (SlideChangeListener) slideChangeEventList.getListeners(
          SlideChangeListener.class)[i]).slideSelectionChanged(onSlide);
    }
  }

  /** Adds and existing slide to presentation at given position
   * @param position slide position
   * @param s slide to add */
  public void addSlide(Slide s, int position) {
    Slide from = currentSlide;
    s.setLesson(this);
    if (slides.size() <= 0) {
      slides.add(s);
      setCurrentSlide0(0);
    } else {
//        if (position+1>=slides.size()) position = slides.size()-1;
      slides.add(position, s);
      setCurrentSlide0(position);
    }
    fireSlideChange(from, currentSlide);

    for (int l = 0; l < getSlidesCount(); l++) {
      Slide sl = getSlide(l);
      for (int o = 0; o < sl.getComponentCount(); o++) {
        if (sl.getComponent(o)instanceof IHyperlink) {
          Hyperlink hl = ( (IHyperlink) sl.getComponent(o)).getHyperlink();
          if (hl.getHyperlinkType() == hl.HYPERLINK_SLIDE) {
            int destination = hl.getHyperlinkSlideDest();
            if (position <= destination) {
              hl.setSlideDest(destination + 1);
            }
          }
        }
      }
    }
  }

  /** Moves slide to new position
   * @param oldNumber slide number to change
   * @param newNumber new slide number */
  public void moveSlide(int oldNumber, int newNumber) {
    Slide oldObj;
    oldObj = getSlide(oldNumber);
    removeSlide(oldNumber);
    addSlide(oldObj, newNumber);
  }

  /** removes action object from any TriggerActions on all slides
   * @param obj object to remove */
  public void removeActionObject(JComponent obj) {
    for (int l = 0; l < getSlidesCount(); l++) {
      getSlide(l).removeActionObject(obj);
    }
  }

  /** Removes slide from lesson
   * @param position slide number to remove*/
  public void removeSlide(int position) {
    if (position == getCurrentSlideNumber()) {
      if (getSlidesCount() > 1) {
        if (position == 0) {
          setCurrentSlide0(position+1);
          fireSlideChange(getCurrentSlide(), getSlide(position + 1));
        } else {
          setCurrentSlide0(position - 1);
          fireSlideChange(getCurrentSlide(), getSlide(position - 1));
        }
      } else {
        setCurrentSlide0(-1);
        fireSlideChange(getCurrentSlide(), null);
      }
    }
    slides.remove(position);
    fireSlideChange();
    for (int l = 0; l < getSlidesCount(); l++) {
      Slide sl = getSlide(l);
      for (int o = 0; o < sl.getComponentCount(); o++) {
        if (sl.getComponent(o)instanceof IHyperlink) {
          Hyperlink hl = ( (IHyperlink) sl.getComponent(o)).getHyperlink();
          if (hl.getHyperlinkType() == hl.HYPERLINK_SLIDE) {
            int destination = hl.getHyperlinkSlideDest();
            if (position < destination) {
              hl.setSlideDest(destination - 1);
            } else if (position == destination) {
              hl.setHyperlinkType(hl.HYPERLINK_NONE);
            }
          }
        }
      }
    }
  }

  /** Removes slide from lesson
   * @param s slide to remove*/
  public void removeSlide(Slide s) {
    removeSlide(getSlidePosition(s));
  }

  /**
   * @param s slide
   * @return slide position */
  public int getSlidePosition(Slide s) {
    return slides.indexOf(s);
  }

  /** Go to slide method.. Normally you shouldn't call this directly
   * it's only for internal use in lesson and undo/redo.
   * @param position slide number to switch to
   * @return Slide that was set to be current*/
  public Slide setCurrentSlide0(int position) {
    if ( (position < 0) || (position >= getSlidesCount())) {
      currentSlide = null;
      return null;
    }
    try {
      Slide from = currentSlide;
      if (currentSlide!=null)
        currentSlide.refreshThumbnail();
      currentSlide = (Slide) slides.get(position);
      fireSlideChange(from, currentSlide);
      return currentSlide;
    } catch (Exception e) {
      Utils.sprintln("Exception while setting slide: "+e.getLocalizedMessage());
    }
    fireSlideChange(null, currentSlide);
    return null;
  }

  /** Go to slide
   * @param position slide number to switch to */
  public void setCurrentSlide(int position) {
    setCurrentSlide0(position);
  }

  /** @param position slide number to remove
   * @return slide at given posititon */
  public Slide getSlide(int position) {
    return (Slide) slides.get(position);
  }

  /** Move to previous slide */
  public void goToPrevSlide() {
    int n = getCurrentSlideNumber();
    if (n > 0) {
      GoToSlideCommand gtsc = new GoToSlideCommand(this, n - 1);
      if (isDesignMode()) commandManager.addEdit(gtsc);
      gtsc.redo();
//      setCurrentSlide(n-1);
    }
  }

  /** Move to next slide */
  public void goToNextSlide() {
    int n = getCurrentSlideNumber();
    if (n < getSlidesCount() - 1) {
      GoToSlideCommand gtsc = new GoToSlideCommand(this, n + 1);
      if (isDesignMode()) commandManager.addEdit(gtsc);
      gtsc.redo();
//      setCurrentSlide(n+1);
    }
  }

  /** Go to slide (like setCurrentSlide, but adds a undoable action)
   * @param n slide to go to */
  public void goToSlide(int n) {
    if (n < getSlidesCount() && (n >= 0)) {
      GoToSlideCommand gtsc = new GoToSlideCommand(this, n);
      if (isDesignMode()) commandManager.addEdit(gtsc);
      gtsc.redo();
    }
  }

  /** @return current slide */
  public Slide getCurrentSlide() {
    return currentSlide;
  }

  /** @return current slide number */
  public int getCurrentSlideNumber() {
    return slides.indexOf(currentSlide);
  }

  /** @return number of slides in lesson */
  public int getSlidesCount() {
    return slides.size();
  }

  /** Paints slide into given graphics
   * @param g graphics to paint to */
  public void paintCurrentSlide(Graphics g) {
    ( (Slide) currentSlide).paint(g);
  }

  /** Paints given slide into given graphics
   * @param slideNumber number of slide to paint
   * @param g Graphics to paint to */
  public void paintSlide(int slideNumber, Graphics g) {
    ( (Slide) slides.get(slideNumber)).paint(g);
  }

  /** @return lesson title */
  public String getTitle() {
    return title;
  };
  /** Sets lesson title
   * @param title new lesson title */
  public void setTitle(String title) {
    this.title = title;
  };
  /** Set lesson design mode or view mode
   * @param designMode true to switch to design mode */
  public void setDesignMode(boolean designMode) {
    this.designMode = designMode;
    Iterator i = slides.iterator();
    while (i.hasNext()) {
      ( (IBase) i.next()).setDesignMode(designMode);
    }
    if ((getCurrentSlide()!=null) && designMode==false) {
      getCurrentSlide().fireSlideChangeTriggerActions();
      getCurrentSlide().clearSelection();
    }
  }

  /** @return true if lesson is in design mode */
  public boolean isDesignMode() {
    return designMode;
  }

  /** Sets lesson size
   * @param size new size */
  public void setSize(Dimension size) {
    this.size = size;
    Iterator i = slides.iterator();
    while (i.hasNext()) {
      ( (Slide) i.next()).setSize(size);
    }
    fireSlideChange();
  }

  /** @return lesson size */
  public Dimension getSize() {
    return size;
  }

  /** @return lesson width */
  public int getWidth() {
    return getSize().width;
  }

  /** @return lesson height */
  public int getHeight() {
    return getSize().height;
  }

  /** @return slide name of given slide number
   * @param i slide number*/
  public String getSlideName(int i) {
    return ( (Slide) slides.get(i)).getName();
  }

  /** Set description for lesson
   * @param description description to set */
  public void setDescription(String description) {
    this.description = description;
  }

  /** @return description for lesson */
  public String getDescription() {
    return description;
  }

  /** @return Classes of used objects */
  public Class[] getUsedObjects() {
    Vector classes = new Vector();
    Iterator i = slides.iterator();
    while (i.hasNext()) {
      Slide s = (Slide) i.next();
      Component[] components = s.getComponents();
      if (components != null) {
        for (int j = 0; j < components.length; j++) {
          classes.add(components[j].getClass());
        }
      }
    }
    i = classes.iterator();
    int j = 0;
    Class[] c = new Class[classes.size()];
    while (i.hasNext()) {
      c[j++] = (Class) i.next();
    }
    return c;
  }

  /** @return default Foreground color for object creation */
  public Color getDefaultFgColor() {
    return defaultFgColor;
  }

  /** set default foreground color for object creation
   * @param defaultFgColor color to set */
  public void setDefaultFgColor(java.awt.Color defaultFgColor) {
    this.defaultFgColor = defaultFgColor;
  }

  /** @return default Background color for object creation */
  public Color getDefaultBgColor() {
    return defaultBgColor;
  }

  /** set default background color for object creation
   * @param defaultBgColor color to set */
  public void setDefaultBgColor(java.awt.Color defaultBgColor) {
    this.defaultBgColor = defaultBgColor;
  }

  /** @return default font for object creation */
  public Font getDefaultFont() {
    return defaultFont;
  }

  /** set default foreground color for object creation
   * @param defaultFont to set */
  public void setDefaultFont(Font defaultFont) {
    this.defaultFont = defaultFont;
  }

  /** @return true if navigation buttons are enabled in view mode */
  public boolean isEnableNavigation() {
    return enableNavigation;
  }

  /** set navigation buttons behavior
       * @param enableNavigation true if navigation buttons are enabled in view mode */
  public void setEnableNavigation(boolean enableNavigation) {
    this.enableNavigation = enableNavigation;
  }

  /** @return applet context when running as Applet */
  public java.applet.AppletContext getAppletContext() {
    return appletContext;
  }

  /** Sets applet context when running as Applet
   * @param  appletContext applet context */
  public void setAppletContext(java.applet.AppletContext appletContext) {
    this.appletContext = appletContext;
  }

  /** @return true if can go to next slide */
  public boolean canGoToNextSlide() {
    return getCurrentSlideNumber() < getSlidesCount() - 1;
  }

  /** @return true if can go to next slide */
  public boolean canGoToPrevSlide() {
    return getCurrentSlideNumber() > 0;
  }

  /** make current slide default slide template for new slide
   * @param ds slide to be set as default */
  public void setDefaultSlide(Slide ds) {
    Lesson ol = ds.getLesson();
    ds.setLesson(null);
    try {
      ByteArrayOutputStream baos = new ByteArrayOutputStream();
      ObjectOutputStream oos = new ObjectOutputStream(baos);

      oos.writeObject(ds);
      oos.close();
      defaultSlide = baos.toByteArray();
    } catch (IOException e) {}
    ;
    ds.setLesson(ol);
  }

  /** Creates new slide, either default (is one was set) or new clean
   * @return new slide */
  public Slide getNewSlide() {
    Slide ret = null;

    if (defaultSlide == null) {
      Utils.sprintln("Default slide null, creating empty one.");
      ret = new Slide(getWidth(), getHeight());
      ret.setLesson(this);
      return ret;
    };

    try {
      Utils.sprintln("Default slide not null, using it");
      ObjectInputStream ois = new LObjectInputStream(new ByteArrayInputStream(
          defaultSlide));
      Object o = ois.readObject();
      ret = (Slide) o;
    } catch (Exception e) {
      Utils.sprintln("Exception "+e.getLocalizedMessage()+" when resuing default slide.");
      ret = new Slide(getWidth(), getHeight());
    }
    ret.setLesson(this);
    return ret;
  }

  /** @return true if grid is shown in design mode */
  public boolean isShowGrid() {
    return showGrid;
  }

  /** Sets showing grid in design mode
   * @param showGrid set to true if gird should be shown
   */
  public void setShowGrid(boolean showGrid) {
    this.showGrid = showGrid;
  }

}
