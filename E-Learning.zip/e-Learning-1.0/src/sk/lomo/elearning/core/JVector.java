package sk.lomo.elearning.core;

/**
 * <p>Title: JVector</p>
 * <p>Description: Class encapsulating vector object in a JComponent.
 * This is a foolish container class used only when doing Transferable actions with
 * cut/copy/paste. Default implementation in Swing requires a JComponent
 * descendant.</p>
 * <p>Author: Julius Loman</p>
 * @version 1.0
 */

import javax.swing.JComponent;
import java.util.*;

/** Class encapsulating vector object in a JComponent. */
public class JVector extends JComponent {
  private Vector vector;
  /** Creates component and sets its transferhandler */
  public JVector() { setTransferHandler(new ObjTransferHandler(null));};
  /** @return vector of components that are in container */
  public Vector getVector() { return vector; }
  /** sets vector container
   * @param v vector of new components to put into container.
   */
  public void setVector(Vector v) { this.vector = v; };
}
