package sk.lomo.elearning.core.interfaces;

/**
 * <p>Title: Answer interface</p>
 * <p>Description: Interface for recognizing and working with answer
 * objects.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

/** Interface for recognizing and working with answer objects. */
public interface IAnswer
{
  /** @return Answer weight (percentage). */
  public int getWeight();
  /** Sets the answer weight (percentage).
   * @param weight answer weight */
  public void setWeight(int weight);
  /** Calculates score
   * @return score in percentage */
  public float calculateScore();
}
