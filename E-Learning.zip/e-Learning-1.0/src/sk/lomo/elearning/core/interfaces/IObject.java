package sk.lomo.elearning.core.interfaces;

/**
 * <p>Title: Object interface</p>
 * <p>Description: Interface for recognizing and working with
 * objects.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.awt.*;
import javax.swing.*;

/** Interface for recognizing and working with objects.*/
public interface IObject extends IBase
{
  /** Sets the object selection behavior
   * @param selected true if object should be selected */
  public void setObjectSelected(boolean selected);
  /** @return true if object has selected behavior */
  public boolean isObjectSelected();
  /** @return true if object should be placed in object library */
  public boolean isLibraryObject();
  /** @return category name in object library */
  public String getDisplayCategory();
  /** @return object name in object library */
  public String getDisplayName();
  /** @return object icon on object library and menus */
  public Icon getRepositoryIcon();
  /** @return object context menu items */
  public JMenuItem[] getMenuItems();
  /** @return default object cursor */
  public Cursor getObjectCursor();
  /** @return default size for drag & drop object placement */
  public Dimension getDefaultSize();
  /** Method to be called after object is placed on a slide */
  public void objectPlacement();
  /** @return object name to display in context */
  public String getName();
  /** @param name object name to display in context */
  public void setName(String name);

}
