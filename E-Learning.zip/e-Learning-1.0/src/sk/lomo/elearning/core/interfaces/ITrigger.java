package sk.lomo.elearning.core.interfaces;

/**
 * <p>Title: Trigger interface</p>
 * <p>Description: Interface for recognizing and working with trigger
 * objects.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import sk.lomo.elearning.core.TriggerAction;

/** Interface for recognizing and working with trigger
 * objects. */
public interface ITrigger {
  /** Fires trigger actions */
  public void triggerActions();
  /** @return true if trigger should be fired after entering slide */
  public boolean isTriggerOnSlideEnter();
  /** @param trigger true if trigger should be fired after entering slide */
  public void setTriggerOnSlideEnter(boolean trigger);
  /** @param object action object to remove (was probably removed from project) */
  public void removeActionObject(javax.swing.JComponent object);
  /** @return true if trigger has this action object
   * @param object action object */
  public boolean hasActionObject(javax.swing.JComponent object);
  /** @return trigger actions for object
   * @param object action object */
  public TriggerAction[] getTriggerActions(javax.swing.JComponent object);
  /** @return all trigger actions for object */
  public TriggerAction[] getTriggerActions();
  /** removes TriggerActions on non-existent object */
  public void removeUnparentedObjectActions();
  /** Inserts TriggerAction into list
   * @param action action to insert */
  public void putAction(TriggerAction action);
}
