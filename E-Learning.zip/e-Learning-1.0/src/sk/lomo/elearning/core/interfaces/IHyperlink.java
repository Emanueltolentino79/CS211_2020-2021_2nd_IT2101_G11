package sk.lomo.elearning.core.interfaces;

/**
 * <p>Title: Hyperlink interface</p>
 * <p>Description: Interface for recognizing and working with
 * objects containing a hyperlink.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import sk.lomo.elearning.core.*;

/** Interface for recognizing and working with objects containing a hyperlink. */
public interface IHyperlink
{
  /** @return object hyperlink */
  public Hyperlink getHyperlink();
  /** Sets object hyperlink
   * @param hyperlink new object hyperlink */
  public void setHyperlink(Hyperlink hyperlink);
}
