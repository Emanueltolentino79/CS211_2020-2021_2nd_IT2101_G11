package sk.lomo.elearning.core.interfaces;

/**
 * <p>Title: Text interface</p>
 * <p>Description: Interface for recognizing and working with text
 * objects.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.awt.Font;

/** Interface for recognizing and working with text. */
public interface ITextObject extends IVisible
{
  /** @return object text */
  public String getText();
  /** Sets the object text
   * @param text new object text */
  public void setText(String text);
  /** @return object Font */
  public Font getFont();
  /** Sets object Font
   * @param font new object Font */
  public void setFont(Font font);
}
