package sk.lomo.elearning.core.interfaces;

/**
 * <p>Title: Visible interface</p>
 * <p>Description: Interface for recognizing and working with visible
 * objects.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import sk.lomo.elearning.core.ui.ResizeBorder;

/** Interface for recognizing and working with visible
 * objects. */

public interface IVisible extends IObject
{
  /** @return true if object is visible */
  public boolean isVisible();
  /** Sets the object visibility
   * @param visible true if object should be visible */
  public void setVisible(boolean visible);
  /** @return objects resize border */
  public ResizeBorder getResizeBorder();
}
