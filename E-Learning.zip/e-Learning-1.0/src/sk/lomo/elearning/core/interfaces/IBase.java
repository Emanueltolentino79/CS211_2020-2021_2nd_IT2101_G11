package sk.lomo.elearning.core.interfaces;

/**
 * <p>Title: Base interface</p>
 * <p>Description: Interface for recognizing and working with objects.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */


/** Interface for recognizing and working with objects. */
public interface IBase extends java.io.Serializable
{
  /** Set object behavior into design mode
   * @param designMode selects design or view mode */
  public void setDesignMode(boolean designMode);
  /** @return true if object is in design mode */
  public boolean isDesignMode();
}
