package sk.lomo.elearning.core.interfaces;

/**
 * <p>Title: Question interface</p>
 * <p>Description: Interface for recognizing and working with question
 * objects.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.util.Vector;

/** Interface for recognizing and working with question objects. */

public interface IQuestion
{
  /** @return question text */
  public String getText();
  /** @return question highest score */
  public int getHiScore();
  /** Sets question highest score
   * @param score highest score */
  public void setHiScore(int score);
  /** @return question lowest score */
  public int getLoScore();
  /** Sets question lowest score
   * @param score lowest score */
  public void setLoScore(int score);
  /** @return true if question is scored */
  public boolean isScorable();
  /** Sets the question to be scored or not
   * @param scorable true if question is scorable */
  public void setScorable(boolean scorable);
  /** @return calculates the question score */
  public float calculateScore();
  /** Adds an answer to this question
   * @param answer answer to be added */
  public void addAnswer(IAnswer answer);
  /** Removes an answer from this question
   * @param answer answer to be removed */
  public void removeAnswer(IAnswer answer);
  /** @return true if answer belongs to this question
   * @param answer answer to ask about */
  public boolean hasAnswer(IAnswer answer);
  /** @return Vector of object answers */
  public Vector getAnswers();
  /** @return true if question is a single choice question */
  public boolean isSingleChoice();
  /** Set question behavior to a single choice question
   * @param singleChoice true if question should be single choice question */
  public void setSingleChoice(boolean singleChoice);
}



