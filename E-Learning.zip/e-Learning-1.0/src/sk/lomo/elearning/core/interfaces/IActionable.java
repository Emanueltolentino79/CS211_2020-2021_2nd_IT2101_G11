package sk.lomo.elearning.core.interfaces;

/**
 * <p>Title: Actionable interface</p>
 * <p>Description: Interface for recognizing and working with objects which
 * could perform an action.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

/** Interface for recognizing and working with objects which
 * could perform an action. */

public interface IActionable {
  /** Triggers object action */
  public void action();
}
