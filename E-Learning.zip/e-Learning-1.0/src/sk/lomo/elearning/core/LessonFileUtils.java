package sk.lomo.elearning.core;

/**
 * <p>Title: LessonFileUtils</p>
 * <p>Description: Class dealing with lesson loading and saving.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.zip.*;

import java.awt.*;
import javax.swing.*;
import javax.swing.filechooser.FileFilter;
import java.beans.*;

import sk.lomo.elearning.*;
import sk.lomo.elearning.core.commands.EventableUndoManager;

/** Class dealing with lesson loading and saving.*/

public class LessonFileUtils {
  /** singleton instance */
  private static LessonFileUtils lessonFileUtils_instance = null;
  /** File chooser used for loading/saving */
  private JFileChooser jfc;
  /** filename of current lesson */
  public String currentFilename;


  /** @return singleton instance */
  public static LessonFileUtils getLessonFileUtils() {
    if (lessonFileUtils_instance==null) lessonFileUtils_instance = new LessonFileUtils();
    return lessonFileUtils_instance;
  }

  /** @return description of lesson in file
   * @param fileName file name to get description from */
  public static String getLessonDescription(String fileName) {
    return getLessonDescription(new File(fileName));
  }

  /** @return description of lesson in file
   * @param f file to get description from */
  public static String getLessonDescription(File f) {
    try {
      ZipFile zf = new ZipFile(f.getAbsolutePath());
      Enumeration enum = zf.entries();

      ZipEntry ze = zf.getEntry("title");

      BufferedReader input = new BufferedReader(new InputStreamReader(zf.
          getInputStream(ze)));

      int size = (int) ze.getSize();
      int charsRead = 0;
      char[] c = new char[1];
      String desc = "";
      charsRead = input.read(c);
      while (charsRead>0) {
        desc += c[0];
        charsRead = input.read(c);
      };
      return desc;
    } catch (IOException e) {
      return null;
    } catch (NullPointerException e) {
      return null;
    }
  }

  /** @return title of lesson in file
   * @param fileName file name to get title from */
  public static String getLessonTitle(String fileName) {
    URL url;
    try {
      url = new URL("file:"+fileName);
      url.openConnection();
      ZipInputStream zis = new ZipInputStream(url.openStream());
      boolean found = false;
      while ((zis.available()!=0) || found)  {
        ZipEntry ze = zis.getNextEntry();
        if (ze.getName().equals("title")) {
          found = true;
          BufferedReader input = new BufferedReader(new InputStreamReader(zis));
          int size = (int) ze.getSize();
          int charsRead = 0;
          char[] c = new char[1];
          String title = "";
          charsRead = input.read(c);
          while (charsRead>0) {
            title += c[0];
            charsRead = input.read(c);
          };
          return title;
        }
      }
    } catch (IOException e) {
      return null;
    } catch (NullPointerException e) {
      return null;
    }
    return null;
  }

  /** @return loaded lesson, or null if dialog was cancelled
   * @throws IOException*/
  public Lesson openLesson() throws IOException {
    if (jfc==null) {
      jfc = new JFileChooser();
      jfc.setFileFilter(new LessonFilenameFilter());
    }
    jfc.setDialogTitle("Open lesson");
    if (jfc.showOpenDialog(null) == jfc.APPROVE_OPTION) {
      return openLesson(jfc.getSelectedFile().getAbsolutePath());
    }
    return null;
  }

  /** @return loaded lesson, or null if dialog was cancelled
   * @param fileName lesson file name to open
   * @throws IOException */
  public Lesson openLesson(String fileName) throws IOException {
    try {
      URL url = new URL("file:" + fileName);
      Lesson l = openLesson(url);
      currentFilename = fileName;
      return l;
    } catch (MalformedURLException e) {
      e.printStackTrace();
      return null;
    }
  }

  /** Open lesson in applet, use ObjectInputStream for security exceptions
   * @param url url to open lesson from */
  public Lesson openAppletLesson(URL url) throws IOException {
    try {
      Utils.sprintln("Opening lesson "+url.toString());
      Utils.sprintln("Opening connection");
      url.openConnection();
      Utils.sprintln("Opening stream");
      ZipInputStream zis = new ZipInputStream(url.openStream());
      boolean found = false;
      while ((zis.available()!=0) || found)  {
        ZipEntry ze = zis.getNextEntry();
        if (ze.getName().equals("data")) {
          found = true;
          ObjectInputStream input = new ObjectInputStream(zis);
          Object o = input.readObject();
          if (o instanceof Lesson) {
            currentFilename = url.toString();
            Lesson l = (Lesson) o;
            l.commandManager = new EventableUndoManager();
            zis.close();
            return l;

        }
      }
      }
      return null;
    } catch (InvalidClassException ex) {
        JOptionPane.showMessageDialog(null, "Lesson saved in old format",
            "Cannot open lesson", JOptionPane.ERROR_MESSAGE);
        Utils.sprintln(ex.getLocalizedMessage());
      return null;
    } catch (ClassNotFoundException ex) {
      Utils.sprintln(ex.getLocalizedMessage());
      return null;
    }
  }

  /** Open lesson
   * @param url url to open lesson from */
  public Lesson openLesson(URL url) throws IOException {
    try {
      Utils.sprintln("Opening lesson "+url.toString());
      Utils.sprintln("Opening connection");
      url.openConnection();
      Utils.sprintln("Opening stream");
      ZipInputStream zis = new ZipInputStream(url.openStream());
      boolean found = false;
      while ((zis.available()!=0) || found)  {
        ZipEntry ze = zis.getNextEntry();
        if (ze.getName().equals("data")) {
          found = true;
          ObjectInputStream input;
          input = new LObjectInputStream(zis);
          Object o = input.readObject();
          if (o instanceof Lesson) {
            currentFilename = url.toString();
            Lesson l = (Lesson) o;
            l.commandManager = new EventableUndoManager();
            zis.close();
            return l;

        }
      }
      }
      return null;
    } catch (InvalidClassException ex) {
        JOptionPane.showMessageDialog(null, "Lesson saved in old format",
            "Cannot open lesson", JOptionPane.ERROR_MESSAGE);
        Utils.sprintln(ex.getLocalizedMessage());
      return null;
    } catch (ClassNotFoundException ex) {
      Utils.sprintln(ex.getLocalizedMessage());
      return null;
    } catch (NullPointerException ex) {
      JOptionPane.showMessageDialog(null, "Corrupted lesson file",
          "Cannot open lesson", JOptionPane.ERROR_MESSAGE);
      Utils.sprintln(ex.getLocalizedMessage());
      return null;
    }
  }

  /** Saves lesson
   * @param lesson Lesson to save
   * @param askForFilename true if save dialog should be displayed */
  public void saveLesson(Lesson lesson,
      boolean askForFilename) {
    if (lesson == null)  return;
    if ( (currentFilename == null) || (askForFilename)) {
      if (jfc == null) {
        jfc = new JFileChooser();
        jfc.setFileFilter(new LessonFilenameFilter());
      }
      jfc.setDialogTitle("Save lesson");
      if (jfc.showSaveDialog(null) == jfc.APPROVE_OPTION) {
        String cfn;
        if ( (!jfc.getSelectedFile().getAbsolutePath().toLowerCase().endsWith(
            ".lesson"))) {
          cfn = jfc.getSelectedFile().getAbsolutePath() + ".lesson";
        } else {
          cfn = jfc.getSelectedFile().getAbsolutePath();
        }
        if (new File(cfn).exists()) {
          if (JOptionPane.showConfirmDialog(null, "File exists, overwrite ?",
              "File exists", JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION) {
            saveLesson(lesson, cfn);
            currentFilename = cfn;
            return;
          }
          return;
        }
        saveLesson(lesson, cfn);
        currentFilename = cfn;
        return;
      } else {
        return;
      }
    }
    else saveLesson(lesson, currentFilename);
  }

    /** Saves lesson
     * @param lesson Lesson to save
     * @param fileName file name to save under */
    public void saveLesson(Lesson lesson, String fileName) {
    try {
      Utils.sprintln("Saving lesson to " + fileName);

      FileOutputStream f = new FileOutputStream(fileName);
      CheckedOutputStream csum =
          new CheckedOutputStream(
          f, new Adler32());
      ZipOutputStream out =
          new ZipOutputStream(
          new BufferedOutputStream(csum));
      out.setComment("e-Learning lesson");
      out.setLevel(9);

      out.putNextEntry(new ZipEntry("data"));
      ObjectOutput output = new ObjectOutputStream(out);
      output.writeObject(lesson);

      out.putNextEntry(new ZipEntry("description"));
      out.write(lesson.getDescription().getBytes());

      out.putNextEntry(new ZipEntry("title"));
      DataOutputStream das = new DataOutputStream(out);
      das.write(lesson.getTitle().getBytes());

      out.close();
      lesson.commandManager.discardAllEdits();
    } catch (IOException ex) {
      ex.printStackTrace();
    }
  }

  /** publishes lesson, creates html file according to template Viewer.html
   * referencing Viewer applet with current lesson
   * @param l lesson to publish
   * @param htmlFileName file name to save html to
   */

  public void publishLesson(Lesson l, String htmlFileName) {
    String directory = new File(htmlFileName).getParent();
    String lessonFileName = htmlFileName + ".lesson";

    Library.getLibrary().createViewerJar("Viewer.jar", directory + File.separator + "viewer.jar");
    Utils.sprintln("Publishing lesson to "+lessonFileName);
    saveLesson(l, lessonFileName);

    try {
      FileOutputStream fos = new FileOutputStream(htmlFileName);
      PrintWriter pw = new PrintWriter(fos);
      HTMLStreamer hs = new HTMLStreamer("Viewer.html", pw, new String[] {"WIDTH", "HEIGHT", "LESSONFILE", "LESSONTITLE", "LESSONDESCRIPTION"},
                  new String[] {Integer.toString(l.getWidth()+30), Integer.toString(l.getHeight()+30),
                  new File(lessonFileName).getName(), l.getTitle(), l.getDescription()});
      pw.flush();
      fos.close();
    } catch (IOException e) {
      Utils.sprintln(e.getLocalizedMessage());
    }
  }

}
