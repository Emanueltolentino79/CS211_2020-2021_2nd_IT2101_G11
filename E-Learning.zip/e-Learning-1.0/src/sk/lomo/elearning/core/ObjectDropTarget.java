package sk.lomo.elearning.core;

/**
 * <p>Title: ObjectDropTarget</p>
 * <p>Description: DropTarget descendant for dropping lesson objects onto Slide</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.io.*;
import java.util.*;

import java.awt.*;
import java.awt.datatransfer.*;
import java.awt.dnd.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.plaf.*;

import sk.lomo.elearning.core.ui.*;

/** DropTarget descendant for dropping lesson objects onto Slide */
public class ObjectDropTarget extends DropTarget implements UIResource,
    Serializable {
  private Point dropPoint = new Point(0, 0);
  private Slide slide;

  public Point getDropPoint() {
    return dropPoint;
  }

  public Slide getSlide() {
    return slide;
  }

  public ObjectDropTarget(JComponent c) {
    super();
    setComponent(c);
    try {
      super.addDropTargetListener(getDropTargetListener());
    } catch (TooManyListenersException tmle) {}
  }

  public void addDropTargetListener(DropTargetListener dtl) throws
      TooManyListenersException {
    // Since the super class only supports one DropTargetListener,
    // and we add one from the constructor, we always add to the
    // extended list.
    if (listenerList == null) {
      listenerList = new EventListenerList();
    }
    listenerList.add(DropTargetListener.class, dtl);
  }

  public void removeDropTargetListener(DropTargetListener dtl) {
    if (listenerList != null) {
      listenerList.remove(DropTargetListener.class, dtl);
    }
  }

  // --- DropTargetListener methods (multicast) --------------------------

  public void dragEnter(DropTargetDragEvent e) {
    super.dragEnter(e);
    if (listenerList != null) {
      Object[] listeners = listenerList.getListenerList();
      for (int i = listeners.length - 2; i >= 0; i -= 2) {
        if (listeners[i] == DropTargetListener.class) {
          ( (DropTargetListener) listeners[i + 1]).dragEnter(e);
        }
      }
    }
  }

  public void dragOver(DropTargetDragEvent e) {
    super.dragOver(e);
    if (listenerList != null) {
      Object[] listeners = listenerList.getListenerList();
      for (int i = listeners.length - 2; i >= 0; i -= 2) {
        if (listeners[i] == DropTargetListener.class) {
          ( (DropTargetListener) listeners[i + 1]).dragOver(e);
        }
      }
    }
  }

  public void dragExit(DropTargetEvent e) {
    super.dragExit(e);
    if (listenerList != null) {
      Object[] listeners = listenerList.getListenerList();
      for (int i = listeners.length - 2; i >= 0; i -= 2) {
        if (listeners[i] == DropTargetListener.class) {
          ( (DropTargetListener) listeners[i + 1]).dragExit(e);
        }
      }
    }
  }

  public void drop(DropTargetDropEvent e) {
    Point p = e.getLocation();

    Component c = getComponent();
    while (! (c instanceof Slide)) {
      p.x = p.x + c.getX();
      p.y = p.y + c.getY();
      c = c.getParent();
    }
    dropPoint = p;
    slide = (Slide) c;
    super.drop(e);
    if (listenerList != null) {
      Object[] listeners = listenerList.getListenerList();
      for (int i = listeners.length - 2; i >= 0; i -= 2) {
        if (listeners[i] == DropTargetListener.class) {
          ( (DropTargetListener) listeners[i + 1]).drop(e);
        }
      }
    }
  }

  public void dropActionChanged(DropTargetDragEvent e) {
    super.dropActionChanged(e);
    if (listenerList != null) {
      Object[] listeners = listenerList.getListenerList();
      for (int i = listeners.length - 2; i >= 0; i -= 2) {
        if (listeners[i] == DropTargetListener.class) {
          ( (DropTargetListener) listeners[i + 1]).dropActionChanged(e);
        }
      }
    }
  }

  private void writeObject(ObjectOutputStream oos) throws IOException {
    oos.defaultWriteObject();
  }

  private void readObject(ObjectInputStream ois) throws ClassNotFoundException,
      IOException {
    ois.defaultReadObject();
  }

  private EventListenerList listenerList;

  private static DropTargetListener dropLinkage = null;

  private static DropTargetListener getDropTargetListener() {
    if (dropLinkage == null) {
      dropLinkage = new DropHandler();
    }
    return dropLinkage;
  }

  private static class DropHandler implements DropTargetListener, Serializable {

    private boolean canImport;

    private boolean actionSupported(int action) {
      return (action & TransferHandler.COPY_OR_MOVE) != TransferHandler.NONE;
    }

    // --- DropTargetListener methods -----------------------------------

    public void dragEnter(DropTargetDragEvent e) {
      DataFlavor[] flavors = e.getCurrentDataFlavors();

      JComponent c = (JComponent) e.getDropTargetContext().getComponent();
      TransferHandler importer = c.getTransferHandler();

      if (importer != null && importer.canImport(c, flavors)) {
        canImport = true;
      } else {
        canImport = false;
      }

      int dropAction = e.getDropAction();

      if (canImport && actionSupported(dropAction)) {
        e.acceptDrag(dropAction);
      } else {
        e.rejectDrag();
      }
    }

    public void dragOver(DropTargetDragEvent e) {
      int dropAction = e.getDropAction();

      if (canImport && actionSupported(dropAction)) {
        e.acceptDrag(dropAction);
      } else {
        e.rejectDrag();
      }
    }

    public void dragExit(DropTargetEvent e) {
    }

    public void drop(DropTargetDropEvent e) {
      int dropAction = e.getDropAction();

      JComponent c = (JComponent) e.getDropTargetContext().getComponent();
      TransferHandler importer = c.getTransferHandler();

      if (canImport && importer != null && actionSupported(dropAction)) {
        e.acceptDrop(dropAction);

        try {
          Transferable t = e.getTransferable();
          e.dropComplete(importer.importData(c, t));
        } catch (RuntimeException re) {
          e.dropComplete(false);
        }
      } else {
        e.rejectDrop();
      }
    }

    public void dropActionChanged(DropTargetDragEvent e) {
      int dropAction = e.getDropAction();

      if (canImport && actionSupported(dropAction)) {
        e.acceptDrag(dropAction);
      } else {
        e.rejectDrag();
      }
    }
  }
}
