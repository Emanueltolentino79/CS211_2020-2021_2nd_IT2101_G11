package sk.lomo.elearning.core.event;

/**
 * <p>Title: SUndoableEditListener</p>
 * <p>Description: Adapter to add serialization to UndoableEditListener</p>
 * <p>Author: Julius Loman</p>
 * @version 1.0
 */

import javax.swing.event.UndoableEditListener;
import javax.swing.event.UndoableEditEvent;

/**Adapter to add serialization to UndoableEditListener. */
public class SUndoableEditListener implements UndoableEditListener, java.io.Serializable{
  public void undoableEditHappened(UndoableEditEvent e) {};
}
