package sk.lomo.elearning.core.event;

/**
 * <p>Title: UndoRedoListener</p>
 * <p>Description: Listener for undo/redo events.</p>
 * <p>Author: Julius Loman</p>
 * @version 1.0
 */

import java.util.*;
import sk.lomo.elearning.core.commands.EventableUndoManager;

/** Listener for undo/redo events. */
public abstract class UndoRedoListener implements EventListener {
  public abstract void disableAllEdits();
  public abstract void undoPerformed(EventableUndoManager undoManager);
  public abstract void redoPerformed(EventableUndoManager undoManager);
  public abstract void undoableEditAdded(EventableUndoManager undoManager);
  public abstract void editsDiscarded(EventableUndoManager undoManager);
  public abstract void refresh(EventableUndoManager undoManager);
}
