package sk.lomo.elearning.core.event;

/**
 * <p>Title: StateChangeListener</p>
 * <p>Description: Event for slide changes</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */
import java.util.*;

import sk.lomo.elearning.core.ui.state.*;

/** Event for slide changes. */
public abstract class StateChangeListener implements EventListener {
  public abstract void stateChanged(State from, State to);
}

