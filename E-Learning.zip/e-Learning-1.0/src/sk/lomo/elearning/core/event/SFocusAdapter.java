package sk.lomo.elearning.core.event;

/**
 * <p>Title: SFocusAdapter</p>
 * <p>Description: Class extending java.awt.event.KeyAdapter to implement
 * serialization.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.awt.event.FocusAdapter;

/** Class extending java.awt.event.KeyAdapter to implement serialization. */
public abstract class SFocusAdapter extends FocusAdapter implements java.io.Serializable {
}
