package sk.lomo.elearning.core.event;

/**
 * <p>Title: NavigationActionListener</p>
 * <p>Description: Action listener for hyperlink navigation. </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.awt.event.*;
import javax.swing.*;

import sk.lomo.elearning.core.*;
import sk.lomo.elearning.core.interfaces.*;
import sk.lomo.elearning.core.ui.*;

/** Action listener for hyperlink navigation. */

public class NavigationActionListener implements ActionListener, java.io.Serializable {
  private Hyperlink hyperlink;

  public NavigationActionListener(Hyperlink h) {
    hyperlink = h;
  }

  public void actionPerformed(ActionEvent e) {
    if (e.getSource() instanceof IObject) {
      if (!((IObject) e.getSource()).isDesignMode()) {
        hyperlink.followHyperlink(((Slide) ((JComponent) e.getSource()).getParent()).getLesson());
      }
    }
  }

}
