package sk.lomo.elearning.core.event;

/**
 * <p>Title: SKeyAdapter</p>
 * <p>Description: Class extending java.awt.event.KeyAdapter to implement
 * serialization.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.awt.event.KeyAdapter;

/** Class extending java.awt.event.KeyAdapter to implement serialization. */
public class SKeyAdapter extends KeyAdapter implements java.io.Serializable {
}
