package sk.lomo.elearning.core.event;

/**
 * <p>Title: SlideChangeEvent</p>
 * <p>Description: Event that is invoked when slide changed.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.util.*;

import sk.lomo.elearning.core.ui.Slide;

/** Event that is invoked when slide changed. */
public abstract class SlideChangeListener implements EventListener {
  public void slideChanged(Slide from, Slide to) {};
  public void slideSelectionChanged(Slide onSlide) {};
}


