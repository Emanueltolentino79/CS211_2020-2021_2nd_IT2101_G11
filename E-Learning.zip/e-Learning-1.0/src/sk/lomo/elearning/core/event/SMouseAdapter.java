package sk.lomo.elearning.core.event;

/**
 * <p>Title: SMouseAdapter</p>
 * <p>Description: Extends mouseadapter to support serialization</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.awt.event.MouseAdapter;

public class SMouseAdapter extends MouseAdapter implements java.io.Serializable {
}