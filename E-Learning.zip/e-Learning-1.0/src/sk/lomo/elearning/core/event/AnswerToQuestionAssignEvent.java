package sk.lomo.elearning.core.event;

/**
 * <p>Title: AnswerToQuestionAssignEvent</p>
 * <p>Description: Actionlistener template for assigning answer to
 * a question in answer's object menu.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.text.*;
import java.beans.*;

import java.awt.event.*;
import sk.lomo.elearning.core.interfaces.*;
import sk.lomo.elearning.core.ui.*;

/** Actionlistener template for assigning answer to a question in answer's object menu. */

public class AnswerToQuestionAssignEvent implements ActionListener {
  /** Answer to assign */
  private IAnswer answer;
  /** @return Answer to assign */
  public IAnswer getAnswer() {
    return answer;
  }

  /** Constructs template for given answer
   * @param answer answer to assign */
  public AnswerToQuestionAssignEvent(IAnswer answer) {
    this.answer = answer;
  }

  /** Assigns answer to question according to question's checkbox
   * @param e ActionEvent which invoked this action */
  public void actionPerformed(ActionEvent e) {
    if (e.getSource()instanceof QuestionCheckBox) {
      QuestionCheckBox s = (QuestionCheckBox) e.getSource();
      if (s.getParent()instanceof JPopupMenu) {
        JPopupMenu container = (JPopupMenu) s.getParent();
        for (int i = 0; i < container.getComponentCount(); i++) {
          if (container.getComponent(i)instanceof QuestionCheckBox) {
            if (container.getComponent(i) == s) {
              if (s.isSelected()) {
                ( (QuestionCheckBox) container.getComponent(i)).getQuestion().
                    addAnswer(getAnswer());
              } else {
                ( (QuestionCheckBox) container.getComponent(i)).getQuestion().
                    removeAnswer(getAnswer());
              }
            } else {
              ( (QuestionCheckBox) container.getComponent(i)).getQuestion().
                  removeAnswer(getAnswer());
            }
          }
        }
        if (s.isSelected()) {
          s.getQuestion().addAnswer(getAnswer());
        } else {
          s.getQuestion().removeAnswer(getAnswer());
        }
      }
    }
  }
}
