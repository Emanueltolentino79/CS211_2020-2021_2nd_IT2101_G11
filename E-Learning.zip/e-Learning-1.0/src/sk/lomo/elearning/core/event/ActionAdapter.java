package sk.lomo.elearning.core.event;

/**
 * <p>Title: ActionAdapter</p>
 * <p>Description: Abstract class for inner classes implementing ActionListener
 * and Serializable for use in events in lesson objects.</p>
 * <p>Author: Julius Loman</p>
 * @version 1.0
 */

/** Abstract class for inner classes implementing ActionListener. */
public class ActionAdapter implements java.awt.event.ActionListener, java.io.Serializable {
  public void actionPerformed(java.awt.event.ActionEvent e){};
}
