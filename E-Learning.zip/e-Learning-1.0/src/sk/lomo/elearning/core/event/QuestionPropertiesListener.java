package sk.lomo.elearning.core.event;

/**
 * <p>Title: QuestionPropertiesListener</p>
 * <p>Description: Set properties on a question.</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * @author Julius Loman
 * @version 1.0
 */

import sk.lomo.elearning.core.interfaces.*;
import sk.lomo.elearning.core.ui.dialogs.*;
import java.awt.event.*;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.*;


/** Set properties on a question. */
public class QuestionPropertiesListener implements java.awt.event.ActionListener, java.io.Serializable{
  /** question to change properties on */
  IQuestion question;

  public QuestionPropertiesListener(IQuestion question) {
    this.question=question;

  }

  public void actionPerformed(ActionEvent e) {
    QuestionPropertiesDialog dlg = new QuestionPropertiesDialog(question);

    Dimension dlgSize = dlg.getPreferredSize();
    Dimension frmSize = Toolkit.getDefaultToolkit().getScreenSize();

    dlg.setLocation((frmSize.width - dlgSize.width) / 2, (frmSize.height - dlgSize.height) / 2);
    dlg.setModal(true);
    dlg.pack();
    dlg.show();

    question.setHiScore(dlg.getHiScore());
    question.setLoScore(dlg.getLoScore());
    question.setSingleChoice(dlg.isSingleChoice());
    question.setScorable(dlg.isScorable());
  }

}


