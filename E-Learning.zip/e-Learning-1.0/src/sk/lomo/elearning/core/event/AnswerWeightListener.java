package sk.lomo.elearning.core.event;

/**
 * <p>Title: AnswerWeightListener</p>
 * <p>Description: Actionlistener template for assigning answer to
 * a question in answer's object menu.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.awt.*;
import java.awt.event.*;

import sk.lomo.elearning.core.interfaces.IAnswer;
import sk.lomo.elearning.core.ui.dialogs.*;

/** Actionlistener template for assigning answer to a question in answer's object menu. */
public class AnswerWeightListener implements java.awt.event.ActionListener {
  /** answer to change weight */
  IAnswer answer;

  public AnswerWeightListener(IAnswer answer) {
    this.answer = answer;
  }

  public void actionPerformed(ActionEvent e) {
    AnswerWeightDialog dlg = new AnswerWeightDialog(answer.getWeight());

    Dimension dlgSize = dlg.getPreferredSize();
    Dimension frmSize = Toolkit.getDefaultToolkit().getScreenSize();

    dlg.setLocation((frmSize.width - dlgSize.width) / 2, (frmSize.height - dlgSize.height) / 2);
    dlg.setModal(true);
    dlg.show();
    answer.setWeight(dlg.getWeight());
  }


}
