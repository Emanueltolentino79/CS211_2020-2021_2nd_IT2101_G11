package sk.lomo.elearning.core;

/**
 * <p>Title: ObjectTransferHandler</p>
 * <p>Description: TransferHandler descendant dealing with cut/copy/paste</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import sk.lomo.elearning.core.commands.*;
import sk.lomo.elearning.core.interfaces.*;
import sk.lomo.elearning.core.ui.Slide;
import java.awt.datatransfer.*;
import javax.swing.*;
import java.io.*;
import java.util.*;
import java.awt.Point;
import java.awt.Dimension;
import sk.lomo.elearning.Utils;

/** TransferHandler descendant dealing with cut/copy/paste */

public class ObjTransferHandler extends TransferHandler implements Transferable, Serializable {
  private byte objectData[];
  private String objectClassNameData;

  private TransferHandler oldTransferHandler;

  /** data flavors */
  public static final DataFlavor SlideDataFlavor = new DataFlavor(Slide.class, "LearningObject");
  public static final DataFlavor ObjDataFlavor = new DataFlavor(JComponent.class, "LearningObject");
  public static final DataFlavor ObjClassDataFlavor = new DataFlavor(Library.class, "LearningObjectClass");
  public static final DataFlavor ObjRTDataFlavor = new DataFlavor(Class.class, "LearningObjectRunTimeClass");

  /** supported data flavors for this handler */
  private DataFlavor flavors[] =
     { ObjDataFlavor, ObjClassDataFlavor };

 public ObjTransferHandler(TransferHandler th) {
   oldTransferHandler = th;
 }

 public int getSourceActions(JComponent c) {
   return TransferHandler.COPY;
 }

 public boolean canImport(JComponent comp, DataFlavor
                          flavor[]) {
   if (! (comp instanceof JComponent)) {
     return false;
   }
   for (int i = 0, n = flavor.length; i < n; i++) {
     if (flavor[i].equals(ObjDataFlavor)) {
       return true;
     }
     if (flavor[i].equals(ObjClassDataFlavor)) {
       return true;
     }
   }
   return false;
 }

 public Transferable createTransferable(JComponent comp) {
   try {
     ByteArrayOutputStream baos = new ByteArrayOutputStream();
     ObjectOutputStream oos = new ObjectOutputStream(baos);

     oos.writeObject(comp);
     oos.close();

     objectData=baos.toByteArray();
     return this;
   } catch (IOException e) {
     e.printStackTrace();
   }
   return null;
 }

 public boolean importData(JComponent comp,
   Transferable t) {
    try {
    if (oldTransferHandler!=null) {
      Utils.sprintln("[ObjTransferHandler] Calling object's original transferhandler");
      return oldTransferHandler.importData(comp,t);
    }
    } catch (Exception e) {
      Utils.sprintln("[ObjTransferHandler] Exception in previous transferhandler "+e.getLocalizedMessage());
    }
    try {
    if (t.isDataFlavorSupported(ObjDataFlavor)) {
      // serialized objects in JVector
        try {
          LObjectInputStream ois = new LObjectInputStream(new
          ByteArrayInputStream( (byte[]) t.getTransferData(ObjDataFlavor)));
          Object o = ois.readObject();
          Utils.sprintln("Object readed");
          if (o instanceof JVector) {
            Utils.sprintln("JVector instance found");
            if (comp instanceof Slide) {
              Slide s = (Slide) comp;
              s.clearSelection();
              Iterator i = ( (JVector) o).getVector().iterator();
              while (i.hasNext()) {
                JComponent jc = (JComponent) i.next();
                ( (IObject) jc).setObjectSelected(true);
                s.add(jc, 0);
              }
              i = ( (JVector) o).getVector().iterator();
              while (i.hasNext()) {
                JComponent jc = (JComponent) i.next();
                if (jc instanceof ITrigger) {
                  ((ITrigger) jc).removeUnparentedObjectActions();
                }
              }

            }
          } else if (o instanceof JComponent) {
            comp.add((JComponent) o);
          };
          return true;
        }
        catch (ClassNotFoundException e) {
          e.printStackTrace();
        }
      }
    } catch (UnsupportedFlavorException ignored) {
      ignored.printStackTrace();
    } catch (IOException ignored) {
      ignored.printStackTrace();
    }

    if (t.isDataFlavorSupported(ObjClassDataFlavor)) {
      Utils.sprintln("ObjClassDataFlavor");
      try {
        // just class name, create instance
        if (comp.getDropTarget() instanceof ObjectDropTarget) {

          Point p = ((ObjectDropTarget) comp.getDropTarget()).getDropPoint();
          Object data = t.getTransferData(ObjClassDataFlavor);

          JComponent jc = Library.getLibrary().createInstance((String)data);
          jc.setForeground(((ObjectDropTarget) comp.getDropTarget()).getSlide().getLesson().getDefaultFgColor());
          jc.setBackground(((ObjectDropTarget) comp.getDropTarget()).getSlide().getLesson().getDefaultBgColor());
          if (jc instanceof ITextObject)
            ((ITextObject) jc).setFont(((ObjectDropTarget) comp.getDropTarget()).getSlide().getLesson().getDefaultFont());
//          Class c = Class.forName((String) data);
//          JComponent jc = (JComponent) c.newInstance();

          ((ObjectDropTarget) comp.getDropTarget()).getSlide().clearSelection();


          SlideAddObjectCommand saoc = new SlideAddObjectCommand(((ObjectDropTarget) comp.getDropTarget()).getSlide(), jc, 0);
          ((IObject) jc).setObjectSelected(true);
          saoc.redo();
          ((ObjectDropTarget) comp.getDropTarget()).getSlide().getLesson().commandManager.addEdit(saoc);

          Dimension size = ((IObject) jc).getDefaultSize();
          Point q = new Point((int) (p.getX()-size.getWidth()/2),(int)(p.getY()-size.getHeight()/2));
          jc.setLocation(q);
          jc.setSize(size);
//          ((IObject) jc).setSelected(true);
          ((IObject) jc).objectPlacement();
          return true;
        }
      }
      catch (UnsupportedFlavorException e) {
        Utils.sprintln(e.getLocalizedMessage());
      }
      catch (IOException e) {
        Utils.sprintln(e.getLocalizedMessage());
      };

    };

    if (t.isDataFlavorSupported(ObjRTDataFlavor)) {
      Utils.sprintln("ObjRTDataFlavor");
      try {
        // run time instance, deserialize
        if (comp.getDropTarget() instanceof ObjectDropTarget) {
          Point p = ((ObjectDropTarget) comp.getDropTarget()).getDropPoint();
          Object data = t.getTransferData(ObjRTDataFlavor);

          JComponent jc = Library.getLibrary().createRunTimeInstance((String)data);

          ((ObjectDropTarget) comp.getDropTarget()).getSlide().clearSelection();
          SlideAddObjectCommand saoc = new SlideAddObjectCommand(((ObjectDropTarget) comp.getDropTarget()).getSlide(), jc, 0);
          ((IObject) jc).setObjectSelected(true);
          saoc.redo();
          ((ObjectDropTarget) comp.getDropTarget()).getSlide().getLesson().commandManager.addEdit(saoc);

          Dimension size = ((IObject) jc).getDefaultSize();
          Point q = new Point((int) (p.getX()-size.getWidth()/2),(int)(p.getY()-size.getHeight()/2));
          jc.setLocation(q);
//          jc.setSize(size);
//          ((IObject) jc).setSelected(true);
//          ((IObject) jc).objectPlacement();
          return true;
        }
      }
      catch (UnsupportedFlavorException e) {
        Utils.sprintln(e.getLocalizedMessage());
      }
      catch (IOException e) {
        Utils.sprintln(e.getLocalizedMessage());
      };
    };
    return false;
 }

 // Transferable
 public Object getTransferData(DataFlavor flavor) {
   if (isDataFlavorSupported(flavor)) {
     if (flavor.equals(ObjDataFlavor)) return objectData;
     if (flavor.equals(ObjClassDataFlavor)) return objectClassNameData;
   }
   return null;
 }

 public DataFlavor[] getTransferDataFlavors() {
   return flavors;
 }

 public boolean isDataFlavorSupported(DataFlavor
   flavor) {
  if (flavor.equals(ObjClassDataFlavor)) return true;
   if (flavor.equals(ObjDataFlavor)) return true;
     return false;
 }

 public void exportToClipboard(JComponent comp, Clipboard clip, int action) {
   if (oldTransferHandler!=null) {
     oldTransferHandler.exportToClipboard(comp, clip, action);
   } else
     super.exportToClipboard(comp, clip, action);
 }

}
