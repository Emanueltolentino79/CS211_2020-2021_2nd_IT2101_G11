package sk.lomo.elearning.core.ui.dialogs;

/**
 * <p>Title: TriggerDialog</p>
 * <p>Description: Default dialog for ITrigger objects.</p>
 * <p>Author: Julius Loman</p>
 * @version 1.0
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

import sk.lomo.elearning.core.*;
import sk.lomo.elearning.core.interfaces.*;
import sk.lomo.elearning.core.ui.*;

class TriggerListCellRenderer extends JLabel implements ListCellRenderer {

  /** Initializes cell renderer with default constants. */
  public TriggerListCellRenderer() {
    setHorizontalTextPosition(SwingConstants.LEFT);
    setHorizontalAlignment(SwingConstants.LEFT);
    setVerticalTextPosition(SwingConstants.CENTER);
    setOpaque(true);
  }

  /** Returns renderer. */
  public Component getListCellRendererComponent(JList list, Object value, int
      index, boolean isSelected, boolean cellHasFocus) {

    this.setText( ((TriggerAction) value).getPresentationName());
    this.setIcon( ( (IObject) ( (TriggerAction) value).getActionObject()).
        getRepositoryIcon());
    setHorizontalAlignment(SwingConstants.LEFT);
    setHorizontalTextPosition(SwingConstants.RIGHT);
    setBackground( (isSelected) ? list.getSelectionBackground() :
        list.getBackground());
    setForeground( (isSelected) ? list.getSelectionForeground() :
        list.getForeground());
    setFont(list.getFont());
    setBorder( (cellHasFocus) ?
        UIManager.getBorder("list.focusCellHighlightBorder") :
        new EmptyBorder(1, 1, 1, 1));
    return this;
  }
}

/** Default dialog for ITrigger objects. */

public class TriggerDialog extends JDialog {
  private int option = JOptionPane.CANCEL_OPTION;
  private Slide slide;

  private BorderLayout borderLayout1 = new BorderLayout();
  private JPanel jPanel1 = new JPanel();
  private Border border1;
  private Border border2;
  private Border border3;
  private TitledBorder titledBorder1;
  private JPanel jPanel3 = new JPanel();
  private Border border4;
  private TitledBorder titledBorder2;
  private BorderLayout borderLayout3 = new BorderLayout();
  private Border border5;
  private TitledBorder titledBorder3;
  private JPanel jPanel5 = new JPanel();
  private JButton jButtonAddObject = new JButton();
  private FlowLayout flowLayout1 = new FlowLayout();
  private JButton jButtonRemoveObject = new JButton();

  private GridBagLayout gridBagLayout1 = new GridBagLayout();
  private JButton jButtonOK = new JButton();
  private JButton jButtonCancel = new JButton();
  private JPanel jOptionPanel = new JPanel();
  public JCheckBox jCheckBoxTriggerSlideEnter = new JCheckBox();
  private Border border6;
  private TitledBorder titledBorder4;
  JButton jButtonHelp = new JButton();
  JScrollPane jScrollPane1 = new JScrollPane();
  JList jListTrigger = new JList();

  private TriggerDialog(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  public TriggerDialog(ITrigger trigger) {
    this(null, "Trigger properties", true);
    slide = (Slide) ( (JComponent) trigger).getParent();
    jCheckBoxTriggerSlideEnter.setSelected(trigger.isTriggerOnSlideEnter());
    Dimension dlgSize = getPreferredSize();
    Dimension frmSize = Toolkit.getDefaultToolkit().getScreenSize();
    setLocation( (frmSize.width - dlgSize.width) / 2,
        (frmSize.height - dlgSize.height) / 2);
    pack();
    getRootPane().setDefaultButton(jButtonOK);
  }

  private void jbInit() throws Exception {
    border6 = new EtchedBorder(EtchedBorder.RAISED, Color.white, new Color(142,
        142, 142));
    titledBorder4 = new TitledBorder(border6, "Trigger options");

    border3 = BorderFactory.createLineBorder(Color.white, 1);
    titledBorder1 = new TitledBorder(new EtchedBorder(EtchedBorder.RAISED,
        Color.white, new Color(178, 178, 178)), "Objects to trigger");
    border4 = new EtchedBorder(EtchedBorder.RAISED, Color.white, new Color(142,
        142, 142));
    titledBorder2 = new TitledBorder(border4, "Objects to trigger");
    border5 = new EtchedBorder(EtchedBorder.RAISED, Color.white, new Color(142,
        142, 142));
    titledBorder3 = new TitledBorder(border5, "Trigger on event");
    this.getContentPane().setLayout(borderLayout1);
    jPanel1.setLayout(gridBagLayout1);
    jPanel3.setBorder(titledBorder2);
    jPanel3.setLayout(borderLayout3);
    jButtonAddObject.setText("Add");
    jButtonAddObject.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonAddObject_actionPerformed(e);
      }
    });
    jPanel5.setLayout(flowLayout1);
    flowLayout1.setAlignment(FlowLayout.RIGHT);
    jButtonRemoveObject.setText("Remove");
    jButtonRemoveObject.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonRemoveObject_actionPerformed(e);
      }
    });
    jPanel1.setMinimumSize(new Dimension(310, 250));
    jPanel1.setPreferredSize(new Dimension(310, 250));
    jButtonOK.setText("OK");
    jButtonOK.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonOK_actionPerformed(e);
      }
    });
    jButtonCancel.setText("Cancel");
    jButtonCancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonCancel_actionPerformed(e);
      }
    });
    jCheckBoxTriggerSlideEnter.setText(
        "Trigger automatically when slide entered");
    jOptionPanel.setLayout(new GridLayout(0,1));
    jOptionPanel.setBorder(titledBorder4);
//    verticalFlowLayout1.setHgap(0);
//    verticalFlowLayout1.setVgap(0);
    jButtonHelp.setText("Help");
    jButtonHelp.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonHelp_actionPerformed(e);
      }
    });
    jListTrigger.setModel(new DefaultListModel());
    jListTrigger.setCellRenderer(new TriggerListCellRenderer());
    this.getContentPane().add(jPanel1, BorderLayout.CENTER);
    jPanel1.add(jPanel3,  new GridBagConstraints(0, 1, 4, 1, 1.0, 0.5
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(5, 5, 5, 5), 155, 143));
    jPanel3.add(jPanel5, BorderLayout.SOUTH);
    jPanel5.add(jButtonAddObject, null);
    jPanel5.add(jButtonRemoveObject, null);
    jPanel3.add(jScrollPane1,  BorderLayout.CENTER);
    jScrollPane1.getViewport().add(jListTrigger, null);
    jPanel1.add(jButtonOK,   new GridBagConstraints(1, 3, 1, 1, 1.0, 0.0
            ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(5, 0, 5, 0), 0, 0));
    jPanel1.add(jButtonCancel,  new GridBagConstraints(2, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(5, 5, 5, 5), 0, 0));
    jPanel1.add(jOptionPanel,  new GridBagConstraints(0, 2, 3, 1, 1.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 5, 5), 0, 0));
    jOptionPanel.add(jCheckBoxTriggerSlideEnter, null);
    jPanel1.add(jButtonHelp,  new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(5, 5, 5, 5), 0, 0));
  }

  void jButtonAddObject_actionPerformed(ActionEvent e) {
    TriggerDialogAdd dlg = new TriggerDialogAdd(slide);
    Dimension dlgSize = dlg.getPreferredSize();
    Dimension frmSize = Toolkit.getDefaultToolkit().getScreenSize();
    dlg.setLocation( (frmSize.width - dlgSize.width) / 2,
        (frmSize.height - dlgSize.height) / 2);
    dlg.setModal(true);
    dlg.pack();
    dlg.show();
    if (dlg.getTriggerListAction() != null) {
      ( (DefaultListModel) jListTrigger.getModel()).addElement(dlg.
          getTriggerListAction());
    }
  }

  void jButtonRemoveObject_actionPerformed(ActionEvent e) {
    try {
      ( (DefaultListModel) jListTrigger.getModel()).removeElementAt(
          jListTrigger.getSelectedIndex());
    } catch (ArrayIndexOutOfBoundsException ex) {
    }
    ;
  }

  public int getOption() {
    return option;
  }

  void jButtonOK_actionPerformed(ActionEvent e) {
    option = JOptionPane.OK_OPTION;
    setVisible(false);
  }

  void jButtonCancel_actionPerformed(ActionEvent e) {
    option = JOptionPane.CANCEL_OPTION;
    setVisible(false);
  }

  public JPanel getOptionPanel() {
    return jOptionPanel;
  }

  public TriggerAction[] getTriggerActions() {
    TriggerAction[] actions = new TriggerAction[ ( (DefaultListModel)
        jListTrigger.getModel()).size()];
    ( (DefaultListModel) jListTrigger.getModel()).copyInto(actions);
    return actions;
  }

  public void setTriggerActions(TriggerAction[] actions) {
    ( (DefaultListModel) jListTrigger.getModel()).removeAllElements();
    try {
      for (int i = 0; i < actions.length; i++) {
        ( (DefaultListModel) jListTrigger.getModel()).addElement(actions[i]);
      }
    } catch (NullPointerException e) {

    }
  }

  void jButtonHelp_actionPerformed(ActionEvent e) {
    WebBrowser.help("designer#TriggerDialog", true);
  }
}
