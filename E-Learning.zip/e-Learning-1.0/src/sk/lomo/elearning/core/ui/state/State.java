package sk.lomo.elearning.core.ui.state;

/**
 * <p>Title: State</p>
 * <p>Description: Abstract class for mouse behavior</p>
 * @author unascribed
 * @version 1.0
 */

import java.awt.event.*;
import sk.lomo.elearning.core.ui.Slide;

/** Abstract class for mouse behavior. */
public abstract class State implements MouseMotionListener, MouseListener {

  public abstract void setCanvas(Slide c);

}

