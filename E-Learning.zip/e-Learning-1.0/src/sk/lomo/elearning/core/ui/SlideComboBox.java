package sk.lomo.elearning.core.ui;

/**
 * <p>Title: SlideComboBox</p>
 * <p>Description: Combo box for selecting slide.</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import javax.swing.JComboBox;
import sk.lomo.elearning.core.*;


/** Combo box for selecting slide. */
public class SlideComboBox extends JComboBox {
  private boolean refreshing=false;

  public SlideComboBox(Lesson lesson) {
    super();
    refresh(lesson);
  }

  public void refresh(Lesson lesson) {
    refreshing=true;
    this.removeAllItems();
    try {
      for (int i=0;i<lesson.getSlidesCount();i++) {
        String sname = lesson.getSlideName(i);
        this.addItem(new SlideListItem(i,sname));
      }
      setSelectedIndex(lesson.getCurrentSlideNumber());
    } catch (NullPointerException e) {
    }
    refreshing=false;
  }
  public boolean isRefreshing() { return refreshing; }

  public int getSelectedSlideNum() {
    return ((SlideListItem) getSelectedItem()).getSlideNum();
  }

  public void setSelectedSlideNum(int slideNumber) {
    try {
      this.setSelectedIndex(slideNumber);
    } catch (Exception e) {
    }
  }

  public String getSelectedSlideName() {
    return ((SlideListItem) getSelectedItem()).getSlideName();
  }
}

