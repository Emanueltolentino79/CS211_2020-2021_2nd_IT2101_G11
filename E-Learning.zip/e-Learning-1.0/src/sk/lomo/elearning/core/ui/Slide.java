package sk.lomo.elearning.core.ui;

/**
 * <p>Title: Slide</p>
 * <p>Description: Representation of single slide (page)</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.util.*;

import java.awt.*;
import java.awt.image.*;
import javax.swing.*;

import sk.lomo.elearning.core.*;
import sk.lomo.elearning.core.commands.*;
import sk.lomo.elearning.core.interfaces.*;

/** Representation of single slide (page). */

public class Slide extends JComponent implements IBase, java.io.Serializable {
  /** set to true if object is in design mode */
  private boolean designMode = false;
  /** list of questions */
  private Vector questions = new Vector();
  /** lesson this slide is in */
  private Lesson lesson = null;
  /** start point for drawing object selection */
  private Point selectionStartPoint = new Point(0, 0);
  /** end point for drawing object selection */
  private Point selectionEndPoint = new Point(0, 0);
  /** set to true if selection should be painted */
  private boolean paintSelection;
  /** defines grid size in pixels */
  private int gridSize = 25;
  /** slide thumbnail */
  private ImageIcon thumbnail;

  /** Constructs slide with given parameters
   * @param width slide width
   * @param height slide height
   */
  public Slide(int width, int height) {
    setPreferredSize(new Dimension(width, height));
    setSize(new Dimension(width, height));
    setMaximumSize(new Dimension(width, height));
    setMinimumSize(new Dimension(width, height));
    setLayout(null);
    lesson = lesson;
//    this.setLesson(lesson);
    setBackground(Color.WHITE);
    setTransferHandler(new ObjTransferHandler(this.getTransferHandler()));
    setDropTarget(new ObjectDropTarget(this));
    super.setName("");
  }

  /** @return lesson this slide is in */
  public Lesson getLesson() {
    return lesson;
  }

  public void setLesson(Lesson lesson) {
    this.lesson = lesson;
  }

  /** adds a question to question list
   * @param question IQuestion object to add */
  protected void addQuestion(IQuestion question) {
    questions.add(question);
    question.getAnswers().removeAllElements();
  }

  /** removes a question from question list
   * @param question IQuestion object to remove */
  protected void removeQuestion(IQuestion question) {
    questions.remove(question);
  }

  /** removes an answer from questions
   * @param answer IAnswer object to remove */
  protected void removeAnswer(IAnswer answer) {
    Iterator i = questions.iterator();
    while (i.hasNext()) {
      IQuestion q = (IQuestion) i.next();
      if (q.hasAnswer(answer)) q.removeAnswer(answer);
    }
  }

  /** returns question list
   * @return question list */
  public Vector getQuestions() {
    return questions;
  }

  /** overrides add method to deal with undo/redo
   * @param component component to add
   * @param index z-index of component
   * @return Component that was added */
  public Component add(Component component, int index) {
    if (component instanceof IQuestion) {
      addQuestion( (IQuestion) component);
    }
    if (component instanceof IAnswer) {
      if (getQuestions().size() == 1) {
        ( (IQuestion) getQuestions().get(0)).addAnswer( (IAnswer) component);
      }
    }
    ( (JComponent) component).setTransferHandler(new ObjTransferHandler( ( (
        JComponent) component).getTransferHandler()));
    component.setDropTarget(new ObjectDropTarget( (JComponent) component));
    super.add(component, index);
    ( (IBase) component).setDesignMode(designMode);
    repaint();
    getLesson().fireSlideSelectionChange(this);
    return component;
  }

  /** overrides remove method to deal with undo/redo
   * @param component component to remove*/
  public void remove(Component component) {
    if (component instanceof IQuestion) {
      removeQuestion( (IQuestion) component);
//    if (component instanceof ITrigger)
//        getTriggerManager().removeTriggerActions((ITrigger) component);
    }
    if (component instanceof IAnswer)
      removeAnswer((IAnswer) component);
    getLesson().removeActionObject( (JComponent) component);
    super.remove(component);
    getLesson().fireSlideSelectionChange(this);
    repaint();
  }

  /** removes object from any TriggerActions that contain it
   * @param obj object to remove  */
  public void removeActionObject(JComponent obj) {
    Component c;
    for (int i = 0; i < getComponentCount(); i++) {
      c = getComponent(i);
      if (c instanceof ITrigger) {
        ( (ITrigger) c).removeActionObject(obj);
      }
    }
  }

  /** clears objects in selection */
  public void clearSelection() {
    for (int i = 0; i < this.getComponentCount(); i++) {
      ( (IObject)this.getComponent(i)).setObjectSelected(false);
    }
  }

  /** overrides object paint method to deal with grid painting and
   * object selection painting
   * @param g Graohics to paint to
   */
  public void paint(Graphics g) {
    g.setColor(getBackground());
    g.fillRect(0, 0, this.getWidth(), this.getHeight());
    g.setColor(Color.gray);
    g.setColor(new Color(255 - g.getColor().getRed(),
        255 - g.getColor().getGreen(),
        255 - g.getColor().getBlue()));
    if (isDesignMode() && getLesson().isShowGrid()) {
      for (int x = 0; x < getWidth(); x = x + getGridSize()) {
        for (int y = 0; y < getHeight(); y = y + getGridSize()) {
          g.drawLine(x, y, x, y);
        }
      }
    }

    super.paint(g); // paint the superclass

    if (isPaintSelection()) {
      int x = (getSelectionStartPoint().getX() > getSelectionEndPoint().getX()) ?
          (int) getSelectionEndPoint().getX() :
          (int) getSelectionStartPoint().getX();
      int y = (getSelectionStartPoint().getY() > getSelectionEndPoint().getY()) ?
          (int) getSelectionEndPoint().getY() :
          (int) getSelectionStartPoint().getY();
      int w = (getSelectionStartPoint().getX() > getSelectionEndPoint().getX()) ?
          (int) getSelectionStartPoint().getX() -
          (int) getSelectionEndPoint().getX() :
          (int) getSelectionEndPoint().getX() -
          (int) getSelectionStartPoint().getX();
      int h = (getSelectionStartPoint().getY() > getSelectionEndPoint().getY()) ?
          (int) getSelectionStartPoint().getY() -
          (int) getSelectionEndPoint().getY() :
          (int) getSelectionEndPoint().getY() -
          (int) getSelectionStartPoint().getY();

      for (int i = x; i < x + w - 4; i = i + 8) {
        g.drawLine(i, y, i + 4, y);

      }
      for (int i = x; i < x + w - 4; i = i + 8) {
        g.drawLine(i, y + h, i + 4, y + h);

      }
      for (int i = y; i < y + h - 4; i = i + 8) {
        g.drawLine(x, i, x, i + 4);

      }
      for (int i = y; i < y + h - 4; i = i + 8) {
        g.drawLine(x + w, i, x + w, i + 4);

//      g.drawRect(x,y,w,h);
      }
    }
    g.drawRect(0, 0, this.getWidth() - 1, this.getHeight() - 1);
  }

  /** Sets the object design mode
   * @param designMode true to set into design mode
   */
  public void setDesignMode(boolean designMode) {
    this.designMode = designMode;
    // set design mode to all containing components
    for (int i = 0; i < getComponentCount(); i++) {
      ( (IBase) getComponent(i)).setDesignMode(designMode);
      getComponent(i).setVisible(true);
    }
    this.repaint();
  }

  /** @return true if object is in design mode */
  public boolean isDesignMode() {
    return designMode;
  }

  /** @return objects in selection */
  public Vector getSelectedObjects() {
    Vector sel = new Vector();
    for (int i = 0; i < getComponentCount(); i++) {
      if ( ( (IObject) getComponent(i)).isObjectSelected()) {
        sel.add(getComponent(i));
      }
    }
    return sel;
  }

  /** @return selected objects in a JVector container */
  public JVector getSelectedObjectsAsJVector() {
    Vector sel = new Vector();
    for (int i = 0; i < getComponentCount(); i++) {
      if ( ( (IObject) getComponent(i)).isObjectSelected()) {
        sel.add(getComponent(i));
      }
    }
    JVector jv = new JVector();
    jv.setVector(sel);
    return jv;
  }

  /** @return slide name for loggin purposes */
  public String toString() {
    return "[Slide] " + getName();
  }

  /** Sets object's z-index to front
   * @param object object to bring to front */
  public void bringToFront(Component object) {
    remove(object);
    add(object, 0);
  }

  /** Sets object's z-index to back
   * @param object object to send to back */
  public void sendToBack(Component object) {
    remove(object);
    add(object, getComponentCount());
  }

  /** removes objects in selection */
  public void removeSelectedObjects() {
    Vector sObj = getSelectedObjects();
    Iterator i = sObj.iterator();
    while (i.hasNext()) {
      remove( (Component) i.next());
    }
    repaint();
  }

  /** sets new selection start point
   * @param p selection start point
   */
  public void setSelectionStartPoint(Point p) {
    if (selectionStartPoint != p) {
      selectionStartPoint = p;
      repaint();
    }
  }

  /** @return selection start point */
  public Point getSelectionStartPoint() {
    return selectionStartPoint;
  }

  /** sets new selection end point
   * @param p selection end point
   */
  public void setSelectionEndPoint(Point p) {
    if (selectionEndPoint != p) {
      selectionEndPoint = p;
      repaint();
    }
  }

  /** @return selection end point */
  public Point getSelectionEndPoint() {
    return selectionEndPoint;
  }

  /** set the object selection painting behavior
   * @param paintSelection true if selection shoud be painted */
  public void setPaintSelection(boolean paintSelection) {
    if (this.paintSelection != paintSelection) {
      this.paintSelection = paintSelection;
      repaint();
    }
  }

  /** @return true if selection should be painted */
  public boolean isPaintSelection() {
    return paintSelection;
  }

  /** Selects objects (calls setSelected() ) that are in selection   */
  public void selectObjectsInSelection() {
    int x = (getSelectionStartPoint().getX() > getSelectionEndPoint().getX()) ?
        (int) getSelectionEndPoint().getX() :
        (int) getSelectionStartPoint().getX();
    int y = (getSelectionStartPoint().getY() > getSelectionEndPoint().getY()) ?
        (int) getSelectionEndPoint().getY() :
        (int) getSelectionStartPoint().getY();
    int w = (getSelectionStartPoint().getX() > getSelectionEndPoint().getX()) ?
        (int) getSelectionStartPoint().getX() -
        (int) getSelectionEndPoint().getX() :
        (int) getSelectionEndPoint().getX() -
        (int) getSelectionStartPoint().getX();
    int h = (getSelectionStartPoint().getY() > getSelectionEndPoint().getY()) ?
        (int) getSelectionStartPoint().getY() -
        (int) getSelectionEndPoint().getY() :
        (int) getSelectionEndPoint().getY() -
        (int) getSelectionStartPoint().getY();

    Rectangle selRect = new Rectangle(x, y, w, h);

    boolean changed = false;
    Vector sel = new Vector();
    for (int i = 0; i < getComponentCount(); i++) {
      if (selRect.contains(getComponent(i).getBounds()) &&
          ! ( (IObject) getComponent(i)).isObjectSelected()) {
        ( (IObject) getComponent(i)).setObjectSelected(true);
        changed = true;
      } else {
        if (!selRect.contains(getComponent(i).getBounds()) &&
            ( (IObject) getComponent(i)).isObjectSelected()) {
          ( (IObject) getComponent(i)).setObjectSelected(false);
          changed = true;
        }
      }
    }
    if (changed) {
      getLesson().fireSlideSelectionChange(this);
    }
  }

  /** Selects all objects */
  public void selectAllObjects() {
    for (int i = 0; i < getComponentCount(); i++) {
      ( (IObject) getComponent(i)).setObjectSelected(true);
    }
    getLesson().fireSlideSelectionChange(this);
  }

  /** Sets new slide size
   * @param size new size
   */
  public void setSize(Dimension size) {
    super.setSize(size);
    setPreferredSize(size);
    setMinimumSize(size);
    setMaximumSize(size);
  }

  /** @return grid size in pixels */
  public int getGridSize() {
    return gridSize;
  }

  /** Sets new grid size
   * @param gridSize new grid size
   */
  public void setGridSize(int gridSize) {
    this.gridSize = gridSize;
  }

  /** Aligns objects to grid */
  public void alignSelectedToGrid() {
    AlignToGridCommand atgc = new AlignToGridCommand(this, getSelectedObjects());
    getLesson().commandManager.addEdit(atgc);
    atgc.redo();
  }

  /** sets slide name
   * @param name new slide name
   */
  public void setName(String name) {
    super.setName(name);
    getLesson().fireSlideChange();
  }

  /** Triggers TriggerActions on all triggers on this slide if
   * they should be triggered on slide change */
  public void fireSlideChangeTriggerActions() {
    Component c;
    for (int i = 0; i < getComponentCount(); i++) {
      c = getComponent(i);
      if (c instanceof ITrigger) {
        ITrigger t = ( (ITrigger) c);
        if (t.isTriggerOnSlideEnter()) {
          t.triggerActions();
        }
      }
    }
  }
  /** Fires a slide object selection change*/
  public void fireSlideSelectionChange() {
    if (getLesson().getCurrentSlide()==this) getLesson().fireSlideSelectionChange(this);
  }

  /** @return component position (z-index)
   * @param c component to get info about */
  public int getPosition(Component c) {
    int r = 0;
    Component[] comp = getComponents();
    while ((comp[r]!=c) && (r<comp.length)) r++;
    if (r<comp.length) return r;
    else return 0;
  }

  /** @return Slide thumbnail */
  public Icon getThumbnail() {
    return thumbnail;
  }

  /** Create thumbnail */
  public void refreshThumbnail() {
    int iconSize = 48;
    double ratio = (double) getWidth()/(double) getHeight();
    int w,h;
    if (ratio>=1.0) {
      w=iconSize;
      h=(int) (iconSize/ratio);
    } else {
      w=(int) ratio*iconSize;
      h=iconSize;
    }

    BufferedImage bi = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
    BufferedImage ii = new BufferedImage(getWidth(), getHeight(),
        BufferedImage.TYPE_INT_RGB);
    paint(ii.getGraphics());
    bi.getGraphics().drawImage(ii, 0, 0, bi.getWidth(), bi.getHeight(), null);
    bi.getGraphics().setColor(Color.BLACK);
    thumbnail = new ImageIcon(bi);
  }
}
