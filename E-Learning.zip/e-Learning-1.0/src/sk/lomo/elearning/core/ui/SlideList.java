package sk.lomo.elearning.core.ui;

/**
 * <p>Title: SlideList</p>
 * <p>Description: JList descendant for representing list of slides with thumbnails.</p>
 * <p>Author: Julius Loman</p>
 * @version 1.0
 */

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.text.*;
import java.beans.*;
import java.awt.image.*;
import sk.lomo.elearning.core.*;

/** Slide cell renderer */
class SlideListCellRenderer extends JLabel implements ListCellRenderer {
  /** Initializes cell renderer with default constants. */
  public SlideListCellRenderer() {
    setHorizontalTextPosition(SwingConstants.LEFT);
    setHorizontalAlignment(SwingConstants.LEFT);
    setVerticalTextPosition(SwingConstants.CENTER);
    setOpaque(true);
  }
  /** Returns renderer. */
  public Component getListCellRendererComponent(JList list, Object value, int
      index, boolean isSelected, boolean cellHasFocus) {

    this.setText("[ "+((SlideListItem) value).getSlideNum()+" ] - "+((SlideListItem) value).getSlideName());
    this.setIcon(((SlideListItem) value).getIcon());
    setHorizontalAlignment(SwingConstants.LEFT);
    setHorizontalTextPosition(SwingConstants.RIGHT);
    setBackground((isSelected) ? list.getSelectionBackground() : list.getBackground());
    setForeground((isSelected) ? list.getSelectionForeground() : list.getForeground());
    setFont(list.getFont());
    setBorder((cellHasFocus) ? UIManager.getBorder("list.focusCellHighlightBorder") : new EmptyBorder(1,1,1,1));
    return this;
  }
}

/** JList descendant for representing list of slides with thumbnails. */

public class SlideList extends JList {
  Lesson lesson;
  int iconSize;

  protected void refreshSlideList(Lesson lesson) {
    ((DefaultListModel) getModel()).clear();
    if (lesson.getCurrentSlide()!=null)
      lesson.getCurrentSlide().refreshThumbnail();

    for (int i=0;i<lesson.getSlidesCount(); i++ ) {
      Slide s = lesson.getSlide(i);
        ((DefaultListModel) getModel()).addElement(
          new SlideListItem(i, s, s.getThumbnail()));
    }
  }

  public SlideList(Lesson l) {
    lesson=l;
    this.iconSize=iconSize;
    setCellRenderer(new SlideListCellRenderer());
    setModel(new DefaultListModel());
//    refreshSlideList(l);
  }

  public void refresh() {
    refreshSlideList(lesson);
  }

  public int getSelectedSlideNumber() {
    return ((SlideListItem) getSelectedValue()).getSlideNum();
  }

  public String getSelectedSlideName() {
      return ((SlideListItem) getSelectedValue()).getSlideName();
  }

  public Lesson getLesson() { return lesson; }
}
