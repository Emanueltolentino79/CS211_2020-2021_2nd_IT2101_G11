package sk.lomo.elearning.core.ui;

/**
 * <p>Title: Object cell</p>
 * <p>Description: Object cell for displaying object information in containers.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.awt.*;
import java.util.*;
import javax.swing.*;
import javax.swing.border.*;

/** Object cell for displaying object information in containers. */
public class ObjectCell extends JLabel implements ListCellRenderer {
  private String className, name;
  private boolean runTime = false;

  /** Creates ObjectCell according given object arguments.
   * @param className object class name
   * @param name object name to display in containers
   * @param icon icon to display in containers */
  public ObjectCell(String className, String name, Icon icon) {
    this.className = className;
    this.name = name;
    setIcon(icon);
    setHorizontalTextPosition(SwingConstants.CENTER);
    setHorizontalAlignment(SwingConstants.CENTER);
    setVerticalTextPosition(SwingConstants.BOTTOM);
    setOpaque(true);
  }
  /** Creates ObjectCell according given object arguments.
   * @param name object name to display in containers
   * @param icon icon to display in containers */
  public ObjectCell(String name, Icon icon) {
    this.className = null;
    this.name = name;
    runTime = true;
    setIcon(icon);
    setHorizontalTextPosition(SwingConstants.CENTER);
    setHorizontalAlignment(SwingConstants.CENTER);
    setVerticalTextPosition(SwingConstants.BOTTOM);
    setOpaque(true);
  }
  /** Returns name (visual) of object.
   * @return object name */
  public String getName() { return name; }
  /** Returns class name of object.
   * @return object class name */
  public String getClassName() { return className; }
  /** Returns object icon
   * @return object icon */

  /** Returns renderer. */
  public Component getListCellRendererComponent(JList list, Object value, int
      index, boolean isSelected, boolean cellHasFocus) {

    this.setText(((ObjectCell) value).getName());
    this.setIcon((((ObjectCell) value)).getIcon());

    setBackground((isSelected) ? list.getSelectionBackground() : list.getBackground());
    setForeground((isSelected) ? list.getSelectionForeground() : list.getForeground());
    setFont(list.getFont());
    setBorder((cellHasFocus) ? UIManager.getBorder("list.focusCellHighlightBorder") : new EmptyBorder(1,1,1,1));

    return this;
  }
  /** @return true if represents a runtime object (serialized) */
  public boolean isRunTime() {
    return runTime;
  }
}


