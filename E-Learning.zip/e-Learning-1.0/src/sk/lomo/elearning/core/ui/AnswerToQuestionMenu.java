package sk.lomo.elearning.core.ui;

/**
 * <p>Title: Answer to question menu</p>
 * <p>Description: Generates context menu with available question for an
 * answer to assign to.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.awt.*;
import java.util.*;
import javax.swing.*;
import sk.lomo.*;
import sk.lomo.elearning.core.event.*;
import sk.lomo.elearning.core.interfaces.*;
import sk.lomo.elearning.core.*;
import sk.lomo.elearning.*;

/** Generates context menu with available question for an
 * answer to assign to. */
public class AnswerToQuestionMenu extends JMenu {

  public AnswerToQuestionMenu(IAnswer answer) {
    setText("Is answer to question");
    ButtonGroup bg = new ButtonGroup();

    Vector questions = ((Slide) ((JComponent) answer).getParent()).getQuestions();
    Iterator i = questions.iterator();
    while (i.hasNext()) {
      IQuestion q = (IQuestion) i.next();
      QuestionCheckBox qCBox = new QuestionCheckBox(q, answer);
      bg.add(qCBox);
      add(qCBox);

      qCBox.addActionListener(new AnswerToQuestionAssignEvent(answer));
    }
    setIcon(Utils.getGraphics("MenuQuestion.gif"));
  }
}
