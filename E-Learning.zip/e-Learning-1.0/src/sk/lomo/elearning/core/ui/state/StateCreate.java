package sk.lomo.elearning.core.ui.state;

/**
 * <p>Title: Create State </p>
 * <p>Description: Realizes object creation on slides</p>
 * @author unascribed
 * @version 1.0
 */

import java.awt.event.*;
import java.awt.*;
import javax.swing.*;
import sk.lomo.elearning.core.interfaces.*;
import sk.lomo.elearning.core.ui.*;
import sk.lomo.elearning.Utils;

/** Realizes object creation on slides */

public class StateCreate extends State implements MouseMotionListener, MouseListener {
  public void mouseDown(int x, int y) {}
  public void mouseUp(int x, int y) {}
  public void mouseDrag(int x, int y) {  }
  public void mouseClicked(MouseEvent e) {  }
  public void mouseEntered(MouseEvent e) {  }
  public void mouseExited(MouseEvent e) {  }
  public void mouseMoved(MouseEvent e) {  }
  public void mouseDragged(MouseEvent e) {  }
  public void mousePressed(MouseEvent e) {  }
  public void mouseReleased(MouseEvent e) {  }
  public void setCanvas(Slide c){};  
  public StateCreate() {  }
  public String toString() { return "Drop object to slide";  }
}
