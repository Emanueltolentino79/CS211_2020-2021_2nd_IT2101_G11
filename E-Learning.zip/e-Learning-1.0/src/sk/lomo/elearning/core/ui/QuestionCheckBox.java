package sk.lomo.elearning.core.ui;

/**
 * <p>Title: QuestionCheckBox</p>
 * <p>Description: JCheckbox descentant referencing a question for use in menu</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */


import javax.swing.JCheckBox;
import sk.lomo.elearning.core.interfaces.*;

/** JCheckbox descentant referencing a question for use in menu. */

public class QuestionCheckBox extends JCheckBox {
  private IQuestion question;

  public QuestionCheckBox(IQuestion question, IAnswer answer) {
    this.question = question;
    setText(((ITextObject) question).getText());
    if (question.hasAnswer(answer)) setSelected(true);
      else setSelected(false);
  }
  public IQuestion getQuestion() { return question; }
}
