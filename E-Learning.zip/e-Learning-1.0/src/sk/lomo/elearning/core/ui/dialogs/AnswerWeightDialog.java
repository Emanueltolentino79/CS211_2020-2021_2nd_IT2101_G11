package sk.lomo.elearning.core.ui.dialogs;

/**
 * <p>Title: Answer weight dialog</p>
 * <p>Description: Default dialog to select answer weight</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;

/** Default dialog to select answer weight. */
public class AnswerWeightDialog extends JDialog {
  private TitledBorder titledBorder1;

  public int option = JOptionPane.CANCEL_OPTION;
  private int oldWeight;
  private JPanel jPanel1 = new JPanel();
  private JButton jButtonCancel = new JButton();
  private JButton jButtonOK = new JButton();
  private JSlider jSliderWeight = new JSlider();
  JSpinner jSpinner1 = new JSpinner();
  BorderLayout borderLayout1 = new BorderLayout();
  GridBagLayout gridBagLayout1 = new GridBagLayout();
  JButton jButtonHelp = new JButton();

  private AnswerWeightDialog(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public AnswerWeightDialog(int weight) {
    this(null, "Answer weight", false);
    oldWeight = weight;
    this.jSliderWeight.setValue(weight);
  }

  /** @return new answer weight if ok option was selected, old answer weight
   * if cancel option was selected */
  public int getWeight() {
    if (option==JOptionPane.OK_OPTION) return jSliderWeight.getValue();
    return oldWeight;
  }
  /** Initializes the dialog components
   * @throws Exception any exception */
  private void jbInit() throws Exception {
    titledBorder1 = new TitledBorder(BorderFactory.createLineBorder(SystemColor.controlText,1),"Answer weight");
    this.setModal(true);
    this.getContentPane().setLayout(borderLayout1);
    jButtonCancel.setText("Cancel");
    jButtonCancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonCancel_actionPerformed(e);
      }
    });
    jButtonOK.setMnemonic('0');
    jButtonOK.setText("OK");
    jButtonOK.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonOK_actionPerformed(e);
      }
    });
    jSliderWeight.setBorder(titledBorder1);
    jSliderWeight.addChangeListener(new javax.swing.event.ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        jSliderWeight_stateChanged(e);
      }
    });
    jPanel1.setLayout(gridBagLayout1);
    jSpinner1.setMinimumSize(new Dimension(50, 24));
    jSpinner1.setOpaque(true);
    jSpinner1.setPreferredSize(new Dimension(50, 24));
    jSpinner1.addChangeListener(new javax.swing.event.ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        jSpinner1_stateChanged(e);
      }
    });
    jButtonHelp.setText("Help");
    jButtonHelp.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonHelp_actionPerformed(e);
      }
    });
    jPanel1.add(jSliderWeight,  new GridBagConstraints(0, 0, 4, 1, 1.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 125, 3));
    jPanel1.add(jButtonHelp,  new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(5, 5, 5, 5), 0, 0));
    jPanel1.add(jSpinner1, new GridBagConstraints(1, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(5, 5, 5, 5), 0, 0));
    jPanel1.add(jButtonOK,  new GridBagConstraints(2, 1, 1, 1, 1.0, 0.0
            ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(5, 5, 5, 0), 0, 0));
    jPanel1.add(jButtonCancel, new GridBagConstraints(3, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(5, 5, 5, 5), 0, 0));
    this.getContentPane().add(jPanel1, BorderLayout.CENTER);

    ((SpinnerNumberModel) jSpinner1.getModel()).setMaximum(new Integer(100));
    ((SpinnerNumberModel) jSpinner1.getModel()).setMinimum(new Integer(0));
    ((SpinnerNumberModel) jSpinner1.getModel()).setStepSize(new Integer(10));
    getRootPane().setDefaultButton(jButtonOK);
  }
  /** Cancel option
   * @param e action event which was performed */
  void jButtonCancel_actionPerformed(ActionEvent e) {
    option = JOptionPane.CANCEL_OPTION;
    setVisible(false);
  }
  /** Ok option
   * @param e action event which was performed */
 void jButtonOK_actionPerformed(ActionEvent e) {
    option = JOptionPane.OK_OPTION;
    setVisible(false);
  }

  void jSliderWeight_stateChanged(ChangeEvent e) {
//    titledBorder1.setTitle("Answer weight - "+jSliderWeight.getValue());
    jSpinner1.setValue(new Integer(jSliderWeight.getValue()));
  }

  void jSpinner1_stateChanged(ChangeEvent e) {
    jSliderWeight.setValue(((Integer)jSpinner1.getValue()).intValue());
  }

  void jButtonHelp_actionPerformed(ActionEvent e) {
    sk.lomo.elearning.core.ui.WebBrowser.help("designer#AnswerWeight", true);
  }
}
