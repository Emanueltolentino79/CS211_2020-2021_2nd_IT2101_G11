package sk.lomo.elearning.core.ui.dialogs;

/**
 * <p>Title: Hyperlink properties dialog</p>
 * <p>Description: Default dialog for setting hyperlink properties</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.net.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import sk.lomo.elearning.core.*;
import sk.lomo.elearning.core.ui.*;

/** Default dialog for setting hyperlink properties. */

public class HyperlinkDialog extends JDialog {
  private Hyperlink lnk;
  private int option = JOptionPane.CANCEL_OPTION;

  private JPanel panel1 = new JPanel();
  private BorderLayout borderLayout1 = new BorderLayout();
  private JPanel jPanel2 = new JPanel();
  private JButton jButtonCancel = new JButton();
  private JRadioButton jRadioButtonSlide = new JRadioButton();
  private SlideComboBox slideComboBox = new SlideComboBox(null);
  private BorderLayout borderLayout4 = new BorderLayout();
  private BorderLayout borderLayout2 = new BorderLayout();
  private JRadioButton jRadioButtonURL = new JRadioButton();
  private JTextField jTextFieldURL = new JTextField();
  private JRadioButton jRadioButtonNextSlide = new JRadioButton();
  private JRadioButton jRadioButtonPreviousSlide = new JRadioButton();
  private ButtonGroup buttonGroup1 = new ButtonGroup();
  private GridBagLayout gridBagLayout1 = new GridBagLayout();
  private JRadioButton jRadioButtonNone = new JRadioButton();
  JButton jButtonOK = new JButton();
  JButton jButtonHelp = new JButton();
  JLabel jLabel1 = new JLabel();

  protected HyperlinkDialog(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public HyperlinkDialog(Hyperlink hyperlink, Lesson lesson) {
    this(null, "", false);
    jRadioButtonNone.setSelected(true);
    lnk = hyperlink;
    if (hyperlink.getHyperlinkURLDest()!=null)
      jTextFieldURL.setText(hyperlink.getHyperlinkURLDest().toString());
    if (hyperlink.getHyperlinkType()==hyperlink.HYPERLINK_NONE) {
      jRadioButtonNone.setSelected(true);
    }
    if (hyperlink.getHyperlinkType()==hyperlink.HYPERLINK_URL) {
      jRadioButtonURL.setSelected(true);
    }
    if (hyperlink.getHyperlinkType()==hyperlink.HYPERLINK_SLIDE) {
      jRadioButtonSlide.setSelected(true);
    }
    if (hyperlink.getHyperlinkType()==hyperlink.HYPERLINK_NEXTSLIDE) {
      jRadioButtonNextSlide.setSelected(true);
    }
    if (hyperlink.getHyperlinkType()==hyperlink.HYPERLINK_PREVSLIDE) {
      jRadioButtonPreviousSlide.setSelected(true);
    }
    slideComboBox.refresh(lesson);
    slideComboBox.setSelectedSlideNum(hyperlink.getHyperlinkSlideDest());
    getRootPane().setDefaultButton(jButtonOK);
  }

  private void jbInit() throws Exception {
    panel1.setLayout(borderLayout1);
    jButtonCancel.setText("Cancel");
    jButtonCancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonCancel_actionPerformed(e);
      }
    });
    jRadioButtonSlide.setText("Other slide");
    jRadioButtonURL.setText("URL");
    jPanel2.setLayout(gridBagLayout1);
    jRadioButtonNextSlide.setText("Next slide");
    jRadioButtonPreviousSlide.setText("Previous slide");
    jRadioButtonNone.setText("No hyperlink");
    jButtonOK.setText("OK");
    jButtonOK.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonOK_actionPerformed(e);
      }
    });
    panel1.setMinimumSize(new Dimension(300, 230));
    panel1.setPreferredSize(new Dimension(300, 230));
    this.setResizable(false);
    jButtonHelp.setText("Help");
    jButtonHelp.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonHelp_actionPerformed(e);
      }
    });
    slideComboBox.setActionCommand("comboBoxChanged");
    jLabel1.setText("Choose hyperlink type:");
    getContentPane().add(panel1);
    panel1.add(jPanel2, BorderLayout.CENTER);

    jPanel2.add(jRadioButtonNone,       new GridBagConstraints(0, 1, 2, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 5, 0, 0), 5, 5));

    jPanel2.add(jRadioButtonPreviousSlide,       new GridBagConstraints(0, 2, 3, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 5, 0, 5), 5, 5));

    jPanel2.add(jRadioButtonNextSlide,       new GridBagConstraints(0, 3, 3, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 5, 0, 5), 5, 5));

    jPanel2.add(jRadioButtonSlide,       new GridBagConstraints(0, 4, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 5, 0, 5), 5, 5));

    jPanel2.add(slideComboBox,        new GridBagConstraints(1, 4, 2, 1, 1.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 0, 5), 0, 5));

    jPanel2.add(jRadioButtonURL,       new GridBagConstraints(0, 5, 3, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 5, 0, 5), 5, 5));


    jPanel2.add(jTextFieldURL,      new GridBagConstraints(0, 6, 3, 1, 1.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 5, 5), 5, 5));
    jPanel2.add(jButtonOK,                 new GridBagConstraints(3, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 0, 5), 0, 0));
    jPanel2.add(jButtonCancel,         new GridBagConstraints(3, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 0, 5), 0, 0));
    jPanel2.add(jButtonHelp,       new GridBagConstraints(3, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(5, 5, 5, 5), 0, 0));

    this.setTitle("Hyperlink properties");
    buttonGroup1.add(jRadioButtonPreviousSlide);
    buttonGroup1.add(jRadioButtonNextSlide);
    buttonGroup1.add(jRadioButtonSlide);
    buttonGroup1.add(jRadioButtonURL);
    buttonGroup1.add(jRadioButtonNone);
    jPanel2.add(jLabel1,       new GridBagConstraints(0, 0, 4, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 5, 5, 0), 0, 0));

  }

  public Hyperlink getHyperlink() {
    if (option==JOptionPane.OK_OPTION) {
      if (jRadioButtonSlide.isSelected()) {
        lnk.setHyperlinkType(lnk.HYPERLINK_SLIDE);
      }
      if (jRadioButtonURL.isSelected()) {
        lnk.setHyperlinkType(lnk.HYPERLINK_URL);
      }
      if (jRadioButtonNone.isSelected()) {
        lnk.setHyperlinkType(lnk.HYPERLINK_NONE);
      }
      if (jRadioButtonPreviousSlide.isSelected()) {
        lnk.setHyperlinkType(lnk.HYPERLINK_PREVSLIDE);
      }
      if (jRadioButtonNextSlide.isSelected()) {
        lnk.setHyperlinkType(lnk.HYPERLINK_NEXTSLIDE);
      }
      try {
        lnk.setURLDest(new URL(jTextFieldURL.getText()));
      } catch (MalformedURLException e) {
        lnk.setURLDest(lnk.getHyperlinkURLDest());
      }
      lnk.setSlideDest(((SlideComboBox) slideComboBox).getSelectedSlideNum());
    }
    return lnk;
  }

  void jButtonOK_actionPerformed(ActionEvent e) {
    try {
      new URL(jTextFieldURL.getText());
      option = JOptionPane.OK_OPTION;
      setVisible(false);
      return;
    } catch (MalformedURLException ex) {
      if (jRadioButtonURL.isSelected())
        JOptionPane.showMessageDialog(this, "Malformed hyperlink: " + ex.getLocalizedMessage(), "Malformed hyperlink", JOptionPane.ERROR_MESSAGE);
      else {
        jTextFieldURL.setText("");
        option = JOptionPane.OK_OPTION;
        setVisible(false);
        return;
      }
    }

  }

  void jButtonCancel_actionPerformed(ActionEvent e) {
    option = JOptionPane.CANCEL_OPTION;
    setVisible(false);
  }

  void jButtonHelp_actionPerformed(ActionEvent e) {
    WebBrowser.help("designer#Hyperlink", true);
  }
}
