package sk.lomo.elearning.core.ui;

/**
 * <p>Title: ObjectList</p>
 * <p>Description: JList descendant to show object in list</p>
 * <p>Author: Julius Loman</p>
 * @version 1.0
 */

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.text.*;
import java.beans.*;
import javax.swing.border.*;
import sk.lomo.elearning.core.interfaces.*;

class ObjectListCellRenderer extends JLabel implements ListCellRenderer {

  /** Initializes cell renderer with default constants. */
  public ObjectListCellRenderer() {
    setHorizontalTextPosition(SwingConstants.LEFT);
    setHorizontalAlignment(SwingConstants.LEFT);
    setVerticalTextPosition(SwingConstants.CENTER);
    setOpaque(true);
  }

  /** Returns renderer. */
  public Component getListCellRendererComponent(JList list, Object value, int
      index, boolean isSelected, boolean cellHasFocus) {

    if (value instanceof IObject) {
      if (
          ( ( (IObject) value).getName() == "") ||
          ( ( (IObject) value).getName() == null)
          ) {
        setText( ( (IObject) value).getDisplayName());
      } else {
        setText( ( (IObject) value).getDisplayName() + " (" +
            ( (IObject) value).getName() + ") ");

      }
      setIcon( ( (IObject) value).getRepositoryIcon());
      if (list instanceof ObjectList) {
        if ( ( (ObjectList) list).isShowActions()) {
          if (value instanceof IAction) {
            setText(getText() + " [" + ( (IAction) value).getActionName() + "]");
          }
        }
      }
    }
    setHorizontalAlignment(SwingConstants.LEFT);
    setHorizontalTextPosition(SwingConstants.RIGHT);
    setBackground( (isSelected) ? list.getSelectionBackground() :
        list.getBackground());
    setForeground( (isSelected) ? list.getSelectionForeground() :
        list.getForeground());
    setFont(list.getFont());
    setBorder( (cellHasFocus) ?
        UIManager.getBorder("list.focusCellHighlightBorder") :
        new EmptyBorder(1, 1, 1, 1));
    return this;
  }
}

/** JList descendant to show object in list. */
public class ObjectList extends JList {
  /** true if actions should be shown in list */
  private boolean showActions = false;

  /** creates list */
  public ObjectList() {
    super();
    setModel(new DefaultListModel());
    setCellRenderer(new ObjectListCellRenderer());
  }

  /** adds an object to list
   * @param object object to add */
  public void addObject(IObject object) {
    ( (DefaultListModel) getModel()).addElement(object);
  }

  /** remove an object from list
   * @param object object to remove */
  public void removeObject(IObject object) {
    ( (DefaultListModel) getModel()).removeElement(object);
  }

  /** removes all objects */
  public void removeAllObjects() {
    ( (DefaultListModel) getModel()).removeAllElements();
  }

  /** adds a object to list
   * @param object object to add */
  public IObject getSelectedObject() {
    return (IObject) getSelectedValue();
  }

  /** @return true is action names are shown on IAction objects */
  public boolean isShowActions() {
    return showActions;
  }

  /** Toggles show action names on IAction objects
   * @param showAction true is action names are shown on IAction objects */
  public void setShowActions(boolean showActions) {
    this.showActions = showActions;
  }
}
