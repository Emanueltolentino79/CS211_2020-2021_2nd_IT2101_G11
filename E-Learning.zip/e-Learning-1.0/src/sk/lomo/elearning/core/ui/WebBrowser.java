package sk.lomo.elearning.core.ui;

/**
 * <p>Title: WebBrowser</p>
 * <p>Description: Simple www browser for displaying URL hyperlinks in Designer</p>
 * <p>Author: Julius Loman</p>
 * @author: Julius Loman
 * @version 1.0
 */

import java.io.*;
import java.net.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

import sk.lomo.elearning.*;

class WebBrowserThread extends Thread {
  private WebBrowser b;
  public WebBrowserThread(WebBrowser wb) {
    b = wb;
  }
  public void start() {
    super.start();
    b.goToUrl();
    b.realShow();
  }
  public void run() {
  }
}
/** Simple www browser for displaying URL hyperlinks in Designer. */
public class WebBrowser extends JDialog {
  JPanel contentPane;
  JScrollPane jScrollPane1 = new JScrollPane();
  public JEditorPane browser = new JEditorPane();
  GridBagLayout gridBagLayout1 = new GridBagLayout();
  JLabel jLabelAddress = new JLabel();
  JButton jButtonGo = new JButton();
  JComboBox jComboBox1 = new JComboBox();
  JButton jButtonBack = new JButton();
  JButton jButtonForward = new JButton();
  JLabel jLabelStatus = new JLabel();

  //Construct the frame
  public WebBrowser(URL url) {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
    ((DefaultComboBoxModel) jComboBox1.getModel()).addElement(url);
  }

  public static void help(String page) {
    help(page, false);
  }

  public static void help(String page, boolean modal) {
    URL url;
    try {
      String[] p = page.split("#");
      if (p.length>=2) url = new URL("file:help"+ File.separator + p[0] + ".html#"+p[1]);
        else url = new URL("file:help" + File.separator + p[0] + ".html");
      Utils.sprintln("Help page is "+ url);
      WebBrowser wb = new WebBrowser(url);
      wb.setNavigationEnabled(false);
      Dimension dlgSize = wb.getPreferredSize();
      Dimension frmSize = Toolkit.getDefaultToolkit().getScreenSize();
      wb.setLocation((frmSize.width - dlgSize.width) / 2, (frmSize.height - dlgSize.height) / 2);
      // dialog must be modal when calling from another modal dialog
      wb.setModal(modal);
      wb.show();
    } catch (MalformedURLException e) {
      e.printStackTrace();
    } catch (IOException ex) {};

  }

  public void setNavigationEnabled(boolean e) {
    jButtonGo.setVisible(e);
    jComboBox1.setVisible(e);
    jLabelAddress.setVisible(e);
    jButtonBack.setVisible(e);
    jButtonForward.setVisible(e);
  }

  //Component initialization
  private void jbInit() throws Exception  {
    setModal(false);
    contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(gridBagLayout1);
    setSize(new Dimension(600, 400));
    contentPane.setPreferredSize(new Dimension(550,400));
    contentPane.setMinimumSize(new Dimension(450,320));
    setTitle("e-Learning Web Browser");
    jLabelAddress.setText("Address:");
    jButtonGo.setText("GO");
    jButtonGo.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonGo_actionPerformed(e);
      }
    });
    jComboBox1.setEditable(true);
    jComboBox1.addKeyListener(new java.awt.event.KeyAdapter() {
      public void keyPressed(KeyEvent e) {
        jComboBox1_keyPressed(e);
      }
    });
    jButtonBack.setText("<");
    jButtonBack.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonBack_actionPerformed(e);
      }
    });
    jButtonForward.setText(">");
    jButtonForward.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonForward_actionPerformed(e);
      }
    });
    contentPane.add(jScrollPane1,             new GridBagConstraints(0, 2, 6, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 251));
    jScrollPane1.getViewport().add(browser, null);
    contentPane.add(jLabelAddress,          new GridBagConstraints(3, 0, 1, 2, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(5, 0, 5, 5), 0, 0));
    contentPane.add(jButtonGo,            new GridBagConstraints(5, 0, 1, 2, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(5, 0, 5, 5), 0, 0));
    contentPane.add(jComboBox1,         new GridBagConstraints(4, 0, 1, 2, 1.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(5, 5, 5, 5), 0, 0));
    contentPane.add(jButtonBack,        new GridBagConstraints(0, 1, 2, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(5, 5, 5, 5), 0, 0));
    contentPane.add(jButtonForward,   new GridBagConstraints(2, 0, 1, 2, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(5, 0, 5, 5), 0, 0));
    contentPane.add(jLabelStatus,             new GridBagConstraints(0, 3, 5, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.BOTH, new Insets(2, 5, 2, 5), 0, 0));

    browser.setEditable(false);
    browser.addHyperlinkListener( new HyperlinkListener() {
      public void hyperlinkUpdate(HyperlinkEvent e) {
        if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
          URL url = e.getURL();
          if (url == null)
            return;
          try {
            int c = jComboBox1.getSelectedIndex();
            while (c>0) {
              ( (DefaultComboBoxModel) jComboBox1.getModel()).removeElementAt(0);
              c--;
            }
            ( (DefaultComboBoxModel) jComboBox1.getModel()).insertElementAt(e.
                getURL(), 0);
            jComboBox1.setSelectedIndex(0);
            browser.setPage(e.getURL());
          }
          catch (IOException ex) {
            JOptionPane.showMessageDialog(getWebBrowser(), ex.getLocalizedMessage(), "Cannot follow hyperlink", JOptionPane.ERROR_MESSAGE);
          }
        }
      }
    });
  }

  private WebBrowser getWebBrowser() { return this; }

  /** Display URL in window's combobox */
  void goToUrl() {
    try {
      browser.setPage(jComboBox1.getSelectedItem().toString());
    } catch (MalformedURLException ex) {
      JOptionPane.showMessageDialog(this, "Bad URL", ex.getLocalizedMessage(), JOptionPane.ERROR_MESSAGE);
    }
    catch (IOException ex) {};
  }

  void jComboBox1_keyPressed(KeyEvent e) {
    if (e.getKeyCode() == e.VK_ENTER) {
      jButtonGo_actionPerformed(null);
    }
  }

  void jButtonBack_actionPerformed(ActionEvent e) {
    if (jComboBox1.getItemCount()-1>jComboBox1.getSelectedIndex()) {
      jComboBox1.setSelectedIndex(jComboBox1.getSelectedIndex()+1);
      goToUrl();
    }
  }

  void jButtonForward_actionPerformed(ActionEvent e) {
    if (jComboBox1.getSelectedIndex()>0) {
      jComboBox1.setSelectedIndex(jComboBox1.getSelectedIndex()-1);
      goToUrl();
    }
  }

  void jButtonGo_actionPerformed(ActionEvent e) {
    int c = jComboBox1.getSelectedIndex();
    while (c>0) {
      ( (DefaultComboBoxModel) jComboBox1.getModel()).removeElementAt(0);
      c--;
    }
    ( (DefaultComboBoxModel) jComboBox1.getModel()).insertElementAt(
        jComboBox1.getSelectedItem().toString(), 0);
    goToUrl();
  }

  public void setStatus(String status) {
    jLabelStatus.setText(status);
  }

  public void show() {
    new WebBrowserThread(this).start();
  }

  public void realShow() {
    super.show();
  }
}
