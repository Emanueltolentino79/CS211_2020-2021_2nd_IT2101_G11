package sk.lomo.elearning.core.ui.dialogs;

/**
 * <p>Title: QuizReportPropertiesDialog</p>
 * <p>Description: Dialog displayed by quiz report object.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.awt.*;
import java.net.*;
import javax.swing.*;
import java.awt.event.*;
import sk.lomo.elearning.core.ui.WebBrowser;

/** Dialog displayed by quiz report object. */

public class QuizReportPropertiesDialog extends JDialog {
  public int result = JOptionPane.CANCEL_OPTION;

  JPanel panel1 = new JPanel();
  ButtonGroup buttonGroup1 = new ButtonGroup();
  JTabbedPane jTabbedPane1 = new JTabbedPane();
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanelControl = new JPanel();
  JButton jButtonCancel = new JButton();
  JButton jButtonHelp = new JButton();
  JPanel jPanelGeneral = new JPanel();
  JButton jButtonOK = new JButton();
  JPanel jPanelHTTP = new JPanel();
  GridBagLayout gridBagLayout1 = new GridBagLayout();
  JCheckBox jCheckBox2 = new JCheckBox();
  JCheckBox jCheckBox1 = new JCheckBox();
  JCheckBox jCheckBox3 = new JCheckBox();
  GridBagLayout gridBagLayout2 = new GridBagLayout();
  JLabel jLabel1 = new JLabel();
  JTextField jPostURL = new JTextField();
  JCheckBox jCheckBoxPostGScore = new JCheckBox();
  JCheckBox jCheckBoxPostMaxScore = new JCheckBox();
  JTextField jPostGained = new JTextField();
  JTextField jPostMax = new JTextField();
  JCheckBox jCheckBoxPostMinScore = new JCheckBox();
  JTextField jPostMin = new JTextField();
  JCheckBox jCheckBoxPostQuestion = new JCheckBox();
  JTextField jPostQuestion = new JTextField();
  JCheckBox jCheckBoxPostResults = new JCheckBox();
  GridBagLayout gridBagLayout3 = new GridBagLayout();

  public QuizReportPropertiesDialog(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public QuizReportPropertiesDialog() {
    this(null, "", false);
  }
  private void jbInit() throws Exception {
    panel1.setLayout(borderLayout1);
    jButtonCancel.setText("Cancel");
    jButtonCancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonCancel_actionPerformed(e);
      }
    });
    jButtonHelp.setText("Help");
    jButtonHelp.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonHelp_actionPerformed(e);
      }
    });
    jButtonOK.setText("OK");
    jButtonOK.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonOK_actionPerformed(e);
      }
    });
    jPanelControl.setLayout(gridBagLayout3);
    jPanelGeneral.setMaximumSize(new Dimension(32767, 32767));
    jPanelGeneral.setLayout(gridBagLayout1);
    jCheckBox2.setText("Show results when clicked");
    jCheckBox2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jCheckBox2_actionPerformed(e);
      }
    });
    jCheckBox1.setEnabled(false);
    jCheckBox1.setBorderPainted(false);
    jCheckBox1.setText("Button is visible");
    jCheckBox1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jCheckBox1_actionPerformed(e);
      }
    });
    jCheckBox3.setText("Show results automatically when slide entered");
    jCheckBox3.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jCheckBox3_actionPerformed(e);
      }
    });
    jPanelHTTP.setLayout(gridBagLayout2);
    jLabel1.setEnabled(false);
    jLabel1.setText("URL:");
    jCheckBoxPostGScore.setEnabled(false);
    jCheckBoxPostGScore.setActionCommand("");
    jCheckBoxPostGScore.setSelected(true);
    jCheckBoxPostGScore.setText("Gained score in field");
    jCheckBoxPostMaxScore.setEnabled(false);
    jCheckBoxPostMaxScore.setToolTipText("");
    jCheckBoxPostMaxScore.setActionCommand("");
    jCheckBoxPostMaxScore.setSelected(true);
    jCheckBoxPostMaxScore.setText("Maximal score in field");
    jPostGained.setEnabled(false);
    jPostGained.setText("score");
    jPostMax.setEnabled(false);
    jPostMax.setText("max");
    jCheckBoxPostMinScore.setEnabled(false);
    jCheckBoxPostMinScore.setSelected(true);
    jCheckBoxPostMinScore.setText("Minimal score in field");
    jPostMin.setEnabled(false);
    jPostMin.setSelectionEnd(0);
    jPostMin.setText("min");
    jCheckBoxPostQuestion.setEnabled(false);
    jCheckBoxPostQuestion.setSelected(true);
    jCheckBoxPostQuestion.setText("Question\'s result in field");
    jPostQuestion.setEnabled(false);
    jPostQuestion.setText("questions");
    jPostURL.setEnabled(false);
    jPostURL.setText("");
    jCheckBoxPostResults.setText("Post quiz results");
    jCheckBoxPostResults.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jCheckBoxPostResults_actionPerformed(e);
      }
    });
    jPanelControl.setMaximumSize(new Dimension(32767, 32767));
    getContentPane().add(panel1);
    panel1.add(jTabbedPane1, BorderLayout.CENTER);
    jTabbedPane1.add(jPanelGeneral,   "General");
    jPanelGeneral.add(jCheckBox2,     new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 5, 0, 5), 0, 0));
    jPanelGeneral.add(jCheckBox3,     new GridBagConstraints(0, 0, 1, 1, 1.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 5, 0, 5), 0, 0));
    jPanelGeneral.add(jCheckBox1,            new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 25, 0, 5), 0, 0));
    jPanelControl.add(jButtonOK,    new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(5, 5, 5, 0), 0, 0));
    jPanelControl.add(jButtonCancel,    new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(5, 5, 5, 5), 0, 0));
    jPanelControl.add(jButtonHelp,    new GridBagConstraints(0, 0, 1, 1, 1.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 5, 5, 0), 0, 0));
    jTabbedPane1.add(jPanelHTTP,  "HTTP Post");
    jPanelHTTP.add(jLabel1,      new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(5, 5, 0, 0), 0, 0));
    jPanelHTTP.add(jPostURL,           new GridBagConstraints(1, 1, 2, 1, 1.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 0, 5), 0, 0));
    jPanelHTTP.add(jCheckBoxPostMaxScore,      new GridBagConstraints(0, 3, 2, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 5, 0, 5), 0, 0));
    jPanelHTTP.add(jCheckBoxPostGScore,    new GridBagConstraints(0, 2, 2, 1, 0.0, 0.0
            ,GridBagConstraints.NORTHWEST, GridBagConstraints.NONE, new Insets(5, 5, 0, 0), 0, 0));
    jPanelHTTP.add(jPostGained,     new GridBagConstraints(2, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 0, 5), 0, 0));
    jPanelHTTP.add(jPostMax,        new GridBagConstraints(2, 3, 1, 1, 1.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 0, 5), 0, 0));
    jPanelHTTP.add(jCheckBoxPostMinScore,      new GridBagConstraints(0, 4, 2, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 5, 0, 5), 0, 0));
    jPanelHTTP.add(jPostMin,     new GridBagConstraints(2, 4, 1, 1, 1.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 0, 5), 0, 0));
    jPanelHTTP.add(jCheckBoxPostQuestion,      new GridBagConstraints(0, 5, 2, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 0, 5), 0, 0));
    jPanelHTTP.add(jPostQuestion,     new GridBagConstraints(2, 5, 1, 1, 1.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 0, 5), 0, 0));
    jPanelHTTP.add(jCheckBoxPostResults,      new GridBagConstraints(0, 0, 3, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    panel1.add(jPanelControl, BorderLayout.SOUTH);
    getRootPane().setDefaultButton(jButtonOK);
  }

  void jButtonOK_actionPerformed(ActionEvent e) {
    try {
      if (jCheckBoxPostResults.isSelected()) new URL(jPostURL.getText());
      if (! (new URL(jPostURL.getText()).getProtocol().toLowerCase().equals("http"))) throw new MalformedURLException("Unsupported protocol");
      result = JOptionPane.OK_OPTION;
      setVisible(false);
      return;
    } catch (MalformedURLException ex) {
      if (jCheckBoxPostResults.isSelected())
        JOptionPane.showMessageDialog(this, ex.getLocalizedMessage(), "Malformed URL", JOptionPane.ERROR_MESSAGE);
      else {
        result = JOptionPane.OK_OPTION;
        setVisible(false);
        return;
      }
    }
  }

  void jButtonCancel_actionPerformed(ActionEvent e) {
    result = JOptionPane.CANCEL_OPTION;
    setVisible(false);
  }


  void jCheckBox2_actionPerformed(ActionEvent e) {
    if (((JCheckBox)e.getSource()).isSelected()) jCheckBox1.setSelected(true);
  }


  void jCheckBox3_actionPerformed(ActionEvent e) {
    jCheckBox1.setEnabled(((JCheckBox)e.getSource()).isSelected());
  }

  public URL getPostUrl() {
    try {
      return new URL(jPostURL.getText());
    } catch (MalformedURLException e) {};
    return null;
  }
  public boolean isButtonVisible() { return jCheckBox1.isSelected(); }
  public boolean shouldPostResults() { return jCheckBoxPostResults.isSelected(); }
  public boolean showResultsAutomatically() { return jCheckBox3.isSelected(); }
  public boolean showResultsWhenClicked() { return jCheckBox2.isSelected(); }


  public boolean isPostMax() { return jCheckBoxPostMaxScore.isSelected(); }
  public boolean isPostMin() { return jCheckBoxPostMinScore.isSelected(); }
  public boolean isPostGained() { return jCheckBoxPostGScore.isSelected(); }
  public boolean isPostQuestion() { return jCheckBoxPostQuestion.isSelected(); }


  public void setPostMax(boolean set) { jCheckBoxPostMaxScore.setSelected(set); }
  public void setPostMin(boolean set) { jCheckBoxPostMinScore.setSelected(set); }
  public void setPostGained(boolean set) { jCheckBoxPostGScore.setSelected(set); }
  public void setPostQuestion(boolean set) { jCheckBoxPostQuestion.setSelected(set); }

  public String getPostMaxName() { return jPostMax.getText(); }
  public String getPostMinName() { return jPostMin.getText(); }
  public String getPostGainedName() { return jPostGained.getText(); }
  public String getPostQuestionName() { return jPostQuestion.getText(); }

  public void setPostMaxName(String name) { jPostMax.setText(name); }
  public void setPostMinName(String name) { jPostMin.setText(name); }
  public void setPostGainedName(String name) { jPostGained.setText(name); }
  public void setPostQuestionName(String name) { jPostQuestion.setText(name); }

  public void setShowResultsWhenClicked(boolean set) { jCheckBox2.setSelected(set); }
  public void setShowResultsAutomatically(boolean set) { jCheckBox3.setSelected(set); }
  public void setShouldPostResults(boolean set) { jCheckBoxPostResults.setSelected(set);}
  public void setButtonVisible(boolean set) { jCheckBox1.setSelected(set); }
  public void setPostUrl(URL url) {
    if (url==null) jPostURL.setText("");
      else jPostURL.setText(url.toString());
  }

  void jButtonHelp_actionPerformed(ActionEvent e) {
    WebBrowser.help("designer#QuizReport", true);
  }
  void jCheckBox1_actionPerformed(ActionEvent e) {

  }
  void jCheckBoxPostResults_actionPerformed(ActionEvent e) {
    jLabel1.setEnabled(jCheckBoxPostResults.isSelected());
    jPostURL.setEnabled(jCheckBoxPostResults.isSelected());
    jPostGained.setEnabled(jCheckBoxPostResults.isSelected());
    jPostMax.setEnabled(jCheckBoxPostResults.isSelected());
    jPostMin.setEnabled(jCheckBoxPostResults.isSelected());
    jPostQuestion.setEnabled(jCheckBoxPostResults.isSelected());
    jCheckBoxPostGScore.setEnabled(jCheckBoxPostResults.isSelected());
    jCheckBoxPostMaxScore.setEnabled(jCheckBoxPostResults.isSelected());
    jCheckBoxPostMinScore.setEnabled(jCheckBoxPostResults.isSelected());
    jCheckBoxPostQuestion.setEnabled(jCheckBoxPostResults.isSelected());
  }
  public void show() {
    jCheckBoxPostResults_actionPerformed(null);
    super.show();
  }
}
