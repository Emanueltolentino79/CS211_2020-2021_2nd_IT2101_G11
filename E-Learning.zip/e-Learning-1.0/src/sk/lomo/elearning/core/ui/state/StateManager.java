package sk.lomo.elearning.core.ui.state;

/**
 * <p>Title: StateManager</p>
 * <p>Description: Class managing state changes</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.text.*;
import java.beans.*;
import sk.lomo.elearning.Utils;
import sk.lomo.elearning.core.event.StateChangeListener;
import sk.lomo.elearning.core.ui.*;
import sk.lomo.elearning.core.interfaces.*;

/** Class managing state changes */

public class StateManager {
  /** Event list for stage changes */
  private EventListenerList stateChangeEventList = new EventListenerList();
  /** State arrow instance */
  private State stateArrow = new StateArrow(this);
  /** State create instance */
  private State stateCreate = new StateCreate();
  /** State arrow button to select/unselect */
  private JToggleButton stateArrowButton;
  /** ObjectRepository to unselect objects from when switching to arrow state */
  private ObjectRepository objectRepository;
  /** Current state */
  private State currentState;
  /** Current slide */
  private Slide canvas = null;

  /** Create manager
   * @param stateArrowButton JToggleButton instance to select/unselect when
   * changing states
   * @param objectRepository ObjectRepository instance to unselect objects
   * when changing states */
  public StateManager(JToggleButton stateArrowButton,
      ObjectRepository objectRepository) {
    this.canvas = canvas;
    this.setStateArrow();
    this.stateArrowButton = stateArrowButton;
    this.objectRepository = objectRepository;
  }
  /** Create manager
   * @param stateArrowButton JToggleButton instance to select/unselect when
   * changing states */
  public StateManager(JToggleButton stateArrowButton) {
    this.canvas = canvas;
    this.setStateArrow();
    this.stateArrowButton = stateArrowButton;
  }
  /** Create manager */
  public StateManager() {
    this.setStateArrow();
  }
  /** Add listener for changing slides
   * @param e StateChangeListener to add */
  public void addStateChangeListener(StateChangeListener e) {
    stateChangeEventList.add(StateChangeListener.class, e);
  }
  /** Remove listener for changing slides
   * @param e StateChangeListener to remove */
  public void removeStateChangeListener(StateChangeListener e) {
    stateChangeEventList.remove(StateChangeListener.class, e);
  }
  /** Fire state change
   * @param from leaving state
   * @param to state to be set */
  protected void fireStateChange(State from, State to) {
    for (int i = 0; i < stateChangeEventList.getListenerCount(); i++) {
      ( (StateChangeListener) stateChangeEventList.getListeners(
          StateChangeListener.class)[i]).stateChanged(from, to);
    }
  }
  /** Remove event listeners from object
   * @param c component
   * @param e event listener to remove */
  protected void removeListener(Component c, EventListener e) {
    if (c != null) {
      c.removeMouseListener( (MouseListener) e);
      c.removeMouseMotionListener( (MouseMotionListener) e);
    }
  }
  /** Add event listeners to object
   * @param c component
   * @param e event listener to add */
  protected void addListener(Component c, EventListener e) {
    if (c != null) {
//        if (((c==canvas) && (currentState==stateCreate)) || (c!=canvas))
      c.addMouseListener( (MouseListener) e);
      c.addMouseMotionListener( (MouseMotionListener) e);
    }
  }
  /** Remove event listener from all objects
   * @param e event listener to remove */
  protected void removeAllListeners(EventListener e) {
    if (canvas == null)  return;
    for (int i = 0; i < canvas.getComponentCount(); i++)
      removeListener(canvas.getComponent(i), e);
  }
  /** Remove all event listener from object
   * @param c object to remove from */
  protected void removeAllListeners(Component c) {
    removeListener(c, stateArrow);
    removeListener(c, stateCreate);
  }
  /** Set new state
   * @param cState new state */
  protected void setCurrentState(State cState) {
    currentState = cState;
    if (canvas == null) return;
    for (int i = 0; i < canvas.getComponentCount(); i++) {
      removeAllListeners( (canvas.getComponent(i)));
      addListener(canvas.getComponent(i), currentState);
    }
    removeAllListeners(canvas);
    addListener(canvas, currentState);
    if (stateArrowButton != null) {
      if (currentState == stateArrow)
        stateArrowButton.setSelected(true);
      else stateArrowButton.setSelected(false);
    }
  }
  /** Set state create */
  public void setStateCreate() {
    Utils.sprintln("Setting to state create");
    fireStateChange(currentState, stateCreate);
    resetCanvasCursors();
    setCurrentState(stateCreate);
  };
  /** Set state arrow */
  public void setStateArrow() {
    fireStateChange(currentState, stateArrow);
    removeListener(canvas, stateCreate);
    removeAllListeners(stateCreate);
//      stateArrow = new StateArrow();
    stateArrow.setCanvas(canvas);
    resetCanvasCursors();
    setCurrentState(stateArrow);
    if (objectRepository != null) objectRepository.clearSelection();
  };
  /** Set new canvas to operate on
   * @param newCanvas new Canvas */
  public void setCanvas(Slide newCanvas) {
    removeAllListeners(canvas);
    canvas = newCanvas;
    stateArrow.setCanvas(newCanvas);
    setCurrentState(currentState);
  }
  /** @return canvas manager is operating on */
  public JComponent getCanvas() {
    return canvas;
  }
  /** Set null state, null functionality */
  public void setStateNull() {
    fireStateChange(currentState, null);
    removeAllListeners(canvas);
    resetCanvasCursors();
    currentState = null;
  }
  /** Resets cursors on objects on slide and unselect all */
  public void resetCanvasCursors() {
    if (canvas!=null) {
      Component[] components = canvas.getComponents();
      for(int i=0; i<components.length; i++) {
        if (components[i] instanceof IObject) {
          components[i].setCursor(((IObject) components[i]).getObjectCursor());
        }
      }
    }
  }
  /** @return current state */
  public String getStatus() {
    if (currentState == stateArrow)
      return "Select object";
    if (currentState == stateCreate)
      return "Create object";
    return "";
  }
  /** Reassign current state */
  public void refresh() {
    removeAllListeners(canvas);
    setCurrentState(currentState);
  }
  /** Force update of status */
  public void updateState() {
    fireStateChange(currentState, currentState);
  }
}
