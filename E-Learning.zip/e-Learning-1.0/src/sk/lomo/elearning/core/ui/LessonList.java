package sk.lomo.elearning.core.ui;

/**
 * <p>Title: Lesson list </p>
 * <p>Description: JList descendant for displaying lists of lessons.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.text.*;
import java.beans.*;
import sk.lomo.elearning.core.*;


class LessonListCellRenderer extends JLabel implements ListCellRenderer {

  /** Initializes cell renderer with default constants. */
  public LessonListCellRenderer() {
    setHorizontalTextPosition(SwingConstants.LEFT);
    setHorizontalAlignment(SwingConstants.LEFT);
    setVerticalTextPosition(SwingConstants.CENTER);
    setOpaque(true);
  }

  /** Returns renderer. */
  public Component getListCellRendererComponent(JList list, Object value, int
      index, boolean isSelected, boolean cellHasFocus) {

    this.setText(((LessonListItem) value).getLessonName());
    this.setIcon(((LessonListItem) value).getIcon());
    setHorizontalAlignment(SwingConstants.LEFT);
    setHorizontalTextPosition(SwingConstants.RIGHT);
    setBackground((isSelected) ? list.getSelectionBackground() : list.getBackground());
    setForeground((isSelected) ? list.getSelectionForeground() : list.getForeground());
    setFont(list.getFont());
    setBorder((cellHasFocus) ? UIManager.getBorder("list.focusCellHighlightBorder") : new EmptyBorder(1,1,1,1));
    return this;
  }
}

/** JList descendant for displaying lists of lessons. */

public class LessonList extends JList {
  public LessonList() {
    setCellRenderer(new LessonListCellRenderer());
    setModel(new DefaultListModel());
  }

  public void addLesson(LessonListItem item) {
    ((DefaultListModel) this.getModel()).addElement(item);
  }
}
