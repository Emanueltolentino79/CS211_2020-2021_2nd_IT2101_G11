package sk.lomo.elearning.core.ui;

/**
 * <p>Title: Lesson list item </p>
 * <p>Description: Lesson list item data container</p>
 * <p>Author: Julius Loman</p>
 * @author unascribed
 * @version 1.0
 */

import sk.lomo.elearning.core.ui.Slide;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import java.awt.image.BufferedImage;
import java.awt.Graphics;
import java.awt.Color;

/** Lesson list item data container. */

public class LessonListItem {
  /** Specifies an Icon for the lesson */
  private Icon icon;
  /** Specifies lesson name */
  private String name;
  /** Specifies lesson description */
  private String description;
  /** Specifies lesson file name  */
  private String fileName;
  /** Creates item with given name
   * @param name lesson name */
  public LessonListItem(String name) {
    this.name = name;
  }
  /** Creates item with given name and icon
   *   @param name lesson name
   *   @param icon lesson icon
   *   @param fileName lesson file name
   *   @param description lesson description
   */
  public LessonListItem(String name, Icon icon, String fileName, String description) {
    this.name = name;
    this.icon = icon;
    this.fileName = fileName;
    this.description = description;
  }
  /** @return lesson name */
  public String getLessonName() { return name; }
  /** @return lesson icon */
  public Icon getIcon() { return icon; }
  /** @return lesson file name */
  public String getFilename() { return fileName; }
  /** @return lesson description */
  public String getDescription() { return description; }
}


