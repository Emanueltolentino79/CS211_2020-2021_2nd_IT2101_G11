package sk.lomo.elearning.core.ui;

/**
 * <p>Title: Answer list</p>
 * <p>Description: JList descendant to display list of answers to a question.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.text.*;
import java.beans.*;
import sk.lomo.elearning.core.interfaces.*;

class AnswerListCellRenderer extends JLabel implements ListCellRenderer {

  /** Initializes cell renderer with default constants. */
  public AnswerListCellRenderer() {
    setHorizontalTextPosition(SwingConstants.LEFT);
    setHorizontalAlignment(SwingConstants.LEFT);
    setVerticalTextPosition(SwingConstants.CENTER);
    setOpaque(true);
  }

  /** Returns renderer. */
  public Component getListCellRendererComponent(JList list, Object value, int
      index, boolean isSelected, boolean cellHasFocus) {
    String text = ((AnswerListItem) value).toString();
    if (((AnswerListItem) value).getAnswer() instanceof IObject) {
      String name = ((IObject)((AnswerListItem) value).getAnswer()).getName();
      if (name!=null)
        if (!name.equals("")) text+=" ("+name+")";
    }
    this.setText(text);
    this.setIcon(((AnswerListItem) value).getIcon());
    setHorizontalAlignment(SwingConstants.LEFT);
    setHorizontalTextPosition(SwingConstants.RIGHT);
    setBackground((isSelected) ? list.getSelectionBackground() : list.getBackground());
    setForeground((isSelected) ? list.getSelectionForeground() : list.getForeground());
    setFont(list.getFont());
    setBorder((cellHasFocus) ? UIManager.getBorder("list.focusCellHighlightBorder") : new EmptyBorder(1,1,1,1));

    return this;
  }
}

class AnswerListItem {
  private int weight;
  private String name;
  private Icon icon;

  private IAnswer answer;

  public AnswerListItem(IAnswer answer) {
    this.weight = answer.getWeight();
    this.name = ((IObject) answer).getDisplayName();
    icon = ((IObject) answer).getRepositoryIcon();
    this.answer = answer;
  }

  public String toString() { return name + " - " + weight; }
  public Icon getIcon() { return icon; }
  public IAnswer getAnswer() { return answer; }
}

/** JList descendant to display list of answers to a question. */

public class AnswerList extends JList {
  /** Creates answer list with answers from given questions
   * @param question question to construct answers from */
  public AnswerList(IQuestion question) {
    setCellRenderer(new AnswerListCellRenderer());
    setModel(new DefaultListModel());
    Iterator i = question.getAnswers().iterator();
    IAnswer a;
    while (i.hasNext()) {
      a = (IAnswer) i.next();
      ((DefaultListModel) this.getModel()).addElement(new AnswerListItem(a));
    }
  }
}
