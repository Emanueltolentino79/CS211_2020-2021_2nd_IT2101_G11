package sk.lomo.elearning.core.ui;
/**
 * <p>Title: LButtonModel</p>
 * <p>Description: LButton model for using buttons in lessons</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import javax.swing.*;

import sk.lomo.elearning.core.interfaces.*;

/** LButton model for using buttons in lessons */

public class LButtonModel extends DefaultButtonModel {
  IObject object;
  /** creates button model on given object
   * @param object object to create button model on */
  public LButtonModel(IObject object) {
    this.object = object;
  }

  /** @return true if object is armed */
  public boolean isArmed() {
//    if (object.isDesignMode()) {
//      return false;
//    } else return super.isArmed();
    return !object.isDesignMode();
  }
}
