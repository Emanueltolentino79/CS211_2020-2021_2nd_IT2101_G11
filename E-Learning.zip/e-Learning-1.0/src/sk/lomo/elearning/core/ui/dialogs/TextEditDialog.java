package sk.lomo.elearning.core.ui.dialogs;

/**
 * <p>Title: TextEditDialog</p>
 * <p>Description: Dialog used in text components to edit text.</p>
 * <p>Author: Julius Loman</p>
 * @version 1.0
 */

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.event.*;
import sk.lomo.elearning.Utils;

/** Dialog used in text components to edit text. */
public class TextEditDialog extends JDialog {
  private Icon iconFontBold = Utils.getGraphics("ActionTextFontBold.gif");
  String oldText;
  Font oldFont;
  int result = JOptionPane.CANCEL_OPTION;

  JPanel panel1 = new JPanel();
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanel1 = new JPanel();
  JButton jButtonOK = new JButton();
  JButton jButtonCancel = new JButton();
  FlowLayout flowLayout1 = new FlowLayout();
  Border border1;
  TitledBorder titledBorder1;
  JScrollPane jScrollPane1 = new JScrollPane();
  JTextArea jTextAreaEdit = new JTextArea();
  Border border2;
  TitledBorder titledBorder2;
  JPanel jPanel2 = new JPanel();
  FlowLayout flowLayout2 = new FlowLayout();
  JLabel jLabel1 = new JLabel();
  JComboBox fontNameComboBox = new JComboBox();
  JLabel jLabel2 = new JLabel();
  JComboBox fontSizeComboBox = new JComboBox();
  JToggleButton jTBBold = new JToggleButton();

  private TextEditDialog(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  public TextEditDialog(String t, Font f) {
    this(null, "Edit text", true);
    oldText = t;
    oldFont = f;
    jTextAreaEdit.setText(t);
    jTextAreaEdit.setFont(f);
    updateFonts();
  }

  private void jbInit() throws Exception {
    border1 = new EtchedBorder(EtchedBorder.RAISED, Color.white, new Color(178,
        178, 178));
    titledBorder1 = new TitledBorder(BorderFactory.createEmptyBorder(), "");
    border2 = new EtchedBorder(EtchedBorder.RAISED, Color.white, new Color(134,
        134, 134));
    titledBorder2 = new TitledBorder(border2, "Text to display");
    panel1.setLayout(borderLayout1);
    jButtonOK.setActionCommand("jButton1");
    jButtonOK.setText("OK");
    jButtonOK.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonOK_actionPerformed(e);
      }
    });
    jButtonCancel.setText("Cancel");
    jButtonCancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonCancel_actionPerformed(e);
      }
    });
    jPanel1.setLayout(flowLayout1);
    flowLayout1.setAlignment(FlowLayout.RIGHT);
    jTextAreaEdit.setBorder(titledBorder1);
    jTextAreaEdit.setMinimumSize(new Dimension(240, 200));
    jTextAreaEdit.setText("");
    jScrollPane1.setHorizontalScrollBarPolicy(JScrollPane.
        HORIZONTAL_SCROLLBAR_AS_NEEDED);
    jScrollPane1.setBorder(titledBorder2);
    jScrollPane1.setMinimumSize(new Dimension(250, 200));
    jScrollPane1.setPreferredSize(new Dimension(250, 200));
    jPanel2.setLayout(flowLayout2);
    flowLayout2.setAlignment(FlowLayout.LEFT);
    jLabel1.setText("Font name:");
    fontNameComboBox.setMinimumSize(new Dimension(130, 22));
    fontNameComboBox.setPreferredSize(new Dimension(130, 22));
    fontNameComboBox.addItemListener(new java.awt.event.ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        fontNameComboBox_itemStateChanged(e);
      }
    });
    jLabel2.setText("Size:");
    fontSizeComboBox.setMinimumSize(new Dimension(80, 22));
    fontSizeComboBox.setPreferredSize(new Dimension(80, 22));
    fontSizeComboBox.setEditable(true);
    fontSizeComboBox.addItemListener(new java.awt.event.ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        fontSizeComboBox_itemStateChanged(e);
      }
    });
    jTBBold.setMaximumSize(new Dimension(22, 22));
    jTBBold.setMinimumSize(new Dimension(22, 22));
    jTBBold.setPreferredSize(new Dimension(22, 22));
    jTBBold.setIcon(iconFontBold);
    jTBBold.addItemListener(new java.awt.event.ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        jTBBold_itemStateChanged(e);
      }
    });
    getContentPane().add(panel1);
    panel1.add(jPanel1, BorderLayout.SOUTH);
    jPanel1.add(jButtonOK, null);
    jPanel1.add(jButtonCancel, null);
    panel1.add(jScrollPane1, BorderLayout.CENTER);
    panel1.add(jPanel2, BorderLayout.NORTH);
    jPanel2.add(jLabel1, null);
    jPanel2.add(fontNameComboBox, null);
    jPanel2.add(jLabel2, null);
    jPanel2.add(fontSizeComboBox, null);
    jPanel2.add(jTBBold, null);
    jScrollPane1.getViewport().add(jTextAreaEdit);
    getRootPane().setDefaultButton(jButtonOK);
    fontNameComboBox.setModel(new DefaultComboBoxModel(
        GraphicsEnvironment.getLocalGraphicsEnvironment().getAllFonts()
        ));
    fontSizeComboBox.setModel(new DefaultComboBoxModel(
        new String[] {"8", "9", "10", "11", "12", "14", "16", "18", "24", "36", "48"}
        ));
    fontNameComboBox.setRenderer(new FontNameRenderer());
  }

  void jButtonOK_actionPerformed(ActionEvent e) {
    result = JOptionPane.OK_OPTION;
    setVisible(false);
  }

  void jButtonCancel_actionPerformed(ActionEvent e) {
    result = JOptionPane.CANCEL_OPTION;
    setVisible(false);
  }

  /** @return font that is set by user in this dialog */
  public Font getEditedFont() {
    if (result == JOptionPane.OK_OPTION) {
      return jTextAreaEdit.getFont();
    } else {
      return oldFont;
    }
  }

  /** @return edited text */
  public String getEditedText() {
    if (result == JOptionPane.OK_OPTION) {
      return jTextAreaEdit.getText();
    } else {
      return oldText;
    }
  }

  /** @return results of user's choice */
  public int getResult() {
    return result;
  }

  public void show() {
    jTextAreaEdit.requestFocus();
    super.show();
  }

  void fontNameComboBox_itemStateChanged(ItemEvent e) {
    if (e.getStateChange() != e.DESELECTED) {
      try {
        float size = Float.parseFloat(fontSizeComboBox.getSelectedItem().
            toString());
        if (size < 0.0 || size > 100.0) {
          size = (float) 12.0;
        }
        int style = Font.PLAIN;
        if (jTBBold.isSelected()) {
          style |= Font.BOLD;
        }
        jTextAreaEdit.setFont(new Font( ( (Font) e.getItem()).getName(), style,
            (int) size));
        jTextAreaEdit.repaint();
      } catch (NumberFormatException ignore) {
      } catch (Exception ex) {
        Utils.sprintln("Exception in selecting font: " + ex.getLocalizedMessage());
      }
    }
  }

  void fontSizeComboBox_itemStateChanged(ItemEvent e) {
    if (e.getStateChange() == e.SELECTED) {
      if (e.getID() != ItemEvent.DESELECTED) {
        try {
          float size = Float.parseFloat(fontSizeComboBox.getSelectedItem().
              toString());
          if (size > 0.0 && size < 100.0) {
            jTextAreaEdit.setFont(jTextAreaEdit.getFont().deriveFont(size));
            jTextAreaEdit.repaint();
          } else {
            fontSizeComboBox.setSelectedIndex(0);
          }
        } catch (NumberFormatException ex) {
          fontSizeComboBox.setSelectedIndex(0);
        }
      }
    }
  }

  void jTBBold_itemStateChanged(ItemEvent e) {
    int style = Font.PLAIN;
    if (jTBBold.isSelected()) {
      style |= Font.BOLD;
    }
    try {
      jTextAreaEdit.setFont(jTextAreaEdit.getFont().deriveFont(style));
      jTextAreaEdit.repaint();
    } catch (Exception ex) {
      Utils.sprintln("Exception in selecting font: " + ex.getLocalizedMessage());
    }
  }

  void updateFonts() {
    Font selectedFont = jTextAreaEdit.getFont();
    String fontName = selectedFont.getFontName();
    DefaultComboBoxModel model = (DefaultComboBoxModel) fontNameComboBox.
        getModel();
    Font availFont;
    for (int index = 0; index < model.getSize(); index++) {
      availFont = (Font) model.getElementAt(index);

      if (availFont.equals(selectedFont) ||
          ( (availFont.getFontName().toUpperCase().indexOf(fontName.toUpperCase()) !=
          -1)
//          && (selectedFont.isBold() == (availFont.isBold() || availFont.getFontName().toUpperCase().indexOf("BOLD") != -1))
          )) {
        fontNameComboBox.setSelectedIndex(index);
        break;
      }
    }
    fontSizeComboBox.setSelectedItem(Integer.toString(selectedFont.getSize()));
    jTBBold.setSelected(selectedFont.isBold());
    jTextAreaEdit.setFont(selectedFont.deriveFont(selectedFont.getSize2D()));
    // workaround for JDK bug 4209476 where font attributes are ignored on second creation of font of same size
    jTextAreaEdit.getFont().canDisplay('a');
    jTextAreaEdit.repaint();
  }
}

/** Font combo box item renderer */
class FontNameRenderer extends JLabel implements ListCellRenderer {
  public FontNameRenderer() {
    setOpaque(true);
  }

  public Component getListCellRendererComponent(JList list,
      Object value,
      int index,
      boolean isSelected,
      boolean cellHasFocus) {

    if (value instanceof Font) {
      setText( ( (Font) value).getFontName());
    } else {
      setText(value.toString());
    }

    if (isSelected) {
      setBackground(list.getSelectionBackground());
      setForeground(list.getSelectionForeground());
    } else {
      setBackground(list.getBackground());
      setForeground(list.getForeground());
    }
    return this;
  }
}
