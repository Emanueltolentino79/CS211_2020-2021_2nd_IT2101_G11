package sk.lomo.elearning.core.ui;

/**
 * <p>Title: Resize Border</p>
 * <p>Description: Default Border assigned to object when they are selected
 * or resized.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;

import javax.swing.border.*;
import sk.lomo.elearning.core.interfaces.*;

/** Default Border assigned to object when they are selected
 * or resized. */

public class ResizeBorder implements Border, java.io.Serializable {
  /** Contstants for border corners */
  public final static int CORNER_NONE=0;
  public final static int CORNER_TOP=2;
  public final static int CORNER_LEFT=4;
  public final static int CORNER_RIGHT=8;
  public final static int CORNER_BOTTOM=16;

  /** Corner width */
  protected int m_w=5;
  /** Corner height */
  protected int m_h=5;
  /** Corner border color */
  protected Color m_borderColor = Color.gray;
  /** Corner fill color */
  protected Color m_fillColor = Color.black;
  /** Creates border with given corner dimensions
   * @param w corner width
   * @param h corner height */
  /** Creates border with default parameters */
  public ResizeBorder() {};
  public ResizeBorder(int w, int h) {
    m_w=w;
    m_h=h;
  }
  /** Creates border with given corner dimensions
   * @param w corner width
   * @param h corner height
   * @param borderColor corner border color
   * @param fillColor corner fill color */
  public ResizeBorder(int w, int h, Color borderColor,
   Color fillColor) {
    m_w=w;
    m_h=h;
    m_borderColor = borderColor;
    m_fillColor = fillColor;
  }
  /** @return border insets
   * @param c component to calculate insets of */
  public Insets getBorderInsets(Component c) {
    return new Insets(0,0,0,0);
  }
  /** @return true if border is opaque */
  public boolean isBorderOpaque() { return true; }
  /** @return true if mouse is in some corner
   * @param w component width
   * @param h component height
   * @param e mouse event currently handled */
  public boolean inResizeArea(
   int w, int h, MouseEvent e) {
    Area resizeArea= new Area();
    resizeArea.add(new Area(new Rectangle(0,0,m_w,m_h)));
    resizeArea.add(new Area(new Rectangle(w-m_w,0,m_w,m_h)));
    resizeArea.add(new Area(new Rectangle(0,h-m_h,m_w,m_h)));
    resizeArea.add(new Area(new Rectangle(w-m_w,h-m_h,m_w,m_h)));
    return resizeArea.contains(e.getX(),e.getY());
  };
  /** @return corner the mouse is in
   * @param w component width
   * @param h component height
   * @param e mouse event currently handled */
  public int getCorner(int w, int h, MouseEvent e) {
     int corner=CORNER_NONE;

     if (new Area(new Rectangle(0,0,m_w,m_h)).contains(e.getX(),e.getY())) corner=corner | CORNER_TOP | CORNER_LEFT;
     if (new Area(new Rectangle(w-m_w,0,m_w,m_h)).contains(e.getX(),e.getY()))  corner=corner | CORNER_TOP | CORNER_RIGHT;
     if (new Area(new Rectangle(0,h-m_h,m_w,m_h)).contains(e.getX(),e.getY()))  corner=corner | CORNER_BOTTOM | CORNER_LEFT;
     if (new Area(new Rectangle(w-m_w,h-m_h,m_w,m_h)).contains(e.getX(),e.getY()))  corner=corner | CORNER_BOTTOM | CORNER_RIGHT;
     return corner;
  };
  /** @return point inside corner
   * @param w component width
   * @param h component height
   * @param e mouse event currently handled */
  public Point getResizeInnerPoint(int w, int h, MouseEvent e) {
    Point rip = new Point(0,0);
    if (new Area(new Rectangle(0,0,m_w,m_h)).contains(e.getX(),e.getY())) rip.setLocation(e.getX(),e.getY());
    if (new Area(new Rectangle(w-m_w,0,m_w,m_h)).contains(e.getX(),e.getY()))  rip.setLocation(m_w-(w-e.getX()),e.getY());
    if (new Area(new Rectangle(0,h-m_h,m_w,m_h)).contains(e.getX(),e.getY()))  rip.setLocation(e.getX(),m_h-(h-e.getY()));
    if (new Area(new Rectangle(w-m_w,h-m_h,m_w,m_h)).contains(e.getX(),e.getY()))  rip.setLocation(m_w-(w-e.getX()),m_h-(h-e.getY()));
    return rip;
  }
  /** Paints the border
   * @param c component to paint the border to
   * @param g gaphics to paint to
   * @param x x position of border component
   * @param y y position of border component
   * @param w w component width
   * @param h h component height
   * */
  public void paintBorder(Component c, Graphics g,
   int x, int y, int w, int h) {
//    if (c.hasFocus())
      g.setColor(new Color(m_fillColor.getRed(), m_fillColor.getGreen(),m_fillColor.getBlue(), 96));
//    else g.setColor(m_fillColor);
    w--;
    h--;
    g.fillRect(0,0,m_w,m_h);
    g.fillRect(w-m_w,0,m_w,m_h);
    g.fillRect(0,h-m_h,m_w,m_h);
    g.fillRect(w-m_w,h-m_h,m_w,m_h);

//    if (c.hasFocus())
    g.setColor(new Color(m_borderColor.getRed(), m_borderColor.getGreen(), m_borderColor.getBlue(), 96));
//      else g.setColor(m_borderColor);
    g.drawRect(0,0,m_w,m_h);
    g.drawRect(w-m_w,0,m_w,m_h);
    g.drawRect(0,h-m_h,m_w,m_h);
    g.drawRect(w-m_w,h-m_h,m_w,m_h);
  }
}
