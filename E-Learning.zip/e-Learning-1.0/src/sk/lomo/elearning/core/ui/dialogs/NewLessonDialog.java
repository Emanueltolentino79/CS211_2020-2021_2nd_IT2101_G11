package sk.lomo.elearning.core.ui.dialogs;

/**
 * <p>Title: NewLessonDialog</p>
 * <p>Description: UI Dialog for creating new lesson</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.util.*;
import java.io.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import sk.lomo.elearning.core.ui.*;
import sk.lomo.elearning.core.*;
import sk.lomo.elearning.Utils;
import java.awt.event.*;

/** UI Dialog for creating new lesson. */

public class NewLessonDialog extends JDialog {
  public static final int ACTION_NONE = 0;
  public static final int ACTION_TEMPLATE = 1;
  public static final int ACTION_EXISTING = 2;
  public static final int ACTION_RECENT = 3;
  public static final int ACTION_EMPTY = 4;

  public int action = ACTION_NONE;

  private JPanel panel1 = new JPanel();
  private Border border1;
  private TitledBorder titledBorder1;
  private Border border2;
  private JPanel jPanel1 = new JPanel();
  private BorderLayout borderLayout1 = new BorderLayout();
  private GridBagLayout gridBagLayout1 = new GridBagLayout();

  private JRadioButton jRadioButtonTemplate = new JRadioButton("New lesson from template");
  private JRadioButton jRadioButtonOpenExisting = new JRadioButton("Open existing lesson");
  private JRadioButton jRadioButtonOpenRecent = new JRadioButton("Open recent lesson");
  private JRadioButton jRadioButtonEmpty = new JRadioButton("Start with empty lesson");

  private ButtonGroup buttonGroup = new ButtonGroup();

  private JComboBox jComboBoxRecent = new JComboBox();
  private LessonList lessonList = new LessonList();

  private JScrollPane lessonScrollPanel = new JScrollPane();
  private Border border3;
  private TitledBorder titledBorder2;
  private JButton jButtonOK = new JButton();
  private JButton jButtonCancel = new JButton();
  private JButton jButtonHelp = new JButton();

  private NewLessonDialog(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }

    Dimension dlgSize = getPreferredSize();
    Dimension frmSize = Toolkit.getDefaultToolkit().getScreenSize();

    setLocation((frmSize.width - dlgSize.width) / 2, (frmSize.height - dlgSize.height) / 2);
    pack();

  }

  public NewLessonDialog(String[] recentFiles) {
    this(null, "New lesson", true);
    for (int i=0;i<recentFiles.length;i++) {
      ((DefaultComboBoxModel) jComboBoxRecent.getModel()).addElement(recentFiles[i]);
    }
    String[] templateNames;
    File templatesDir = new File("./templates/");
    templateNames = templatesDir.list(new LessonFilenameFilter());
    try {
      for (int i = 0; i < templateNames.length; i++) {
        String lfn = templatesDir.getPath() + "/" + templateNames[i];
        lessonList.addLesson(new LessonListItem(
            LessonFileUtils.getLessonTitle(lfn),
            Utils.getGraphics("StartWizardNewLesson.gif"),
            lfn,
            LessonFileUtils.getLessonDescription(lfn)));
      }
    } catch (NullPointerException e) {};
  }

  private void jbInit() throws Exception {
    border1 = new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(142, 142, 142));
    border2 = BorderFactory.createCompoundBorder(titledBorder1,BorderFactory.createEmptyBorder(5,5,5,5));
    border3 = new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(142, 142, 142));
    titledBorder2 = new TitledBorder(border3,"Available templates");
    panel1.setLayout(borderLayout1);


    lessonList.addFocusListener(new java.awt.event.FocusAdapter() {
      public void focusGained(FocusEvent e) {
        jRadioButtonTemplate.setSelected(true);
      }
      public void mouseReleased(MouseEvent e) {}
    });

    jComboBoxRecent.addFocusListener(new java.awt.event.FocusAdapter() {
      public void focusGained(FocusEvent e) {
        jRadioButtonOpenRecent.setSelected(true);
      }
    });

    panel1.setMinimumSize(new Dimension(400, 300));
    panel1.setPreferredSize(new Dimension(400, 400));
    jPanel1.setLayout(gridBagLayout1);
    jButtonOK.setText("OK");
    jButtonOK.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        if (jRadioButtonTemplate.isSelected() && (lessonList.getSelectedIndex()<0)) {
          JOptionPane.showMessageDialog(getDialog(),"Please select a template.", "Warning", JOptionPane.WARNING_MESSAGE);
          return;
        }
        if (jRadioButtonEmpty.isSelected()) action = ACTION_EMPTY;
        else if (jRadioButtonOpenExisting.isSelected()) action = ACTION_EXISTING;
        else if (jRadioButtonOpenRecent.isSelected()) action = ACTION_RECENT;
        else if (jRadioButtonTemplate.isSelected()) action = ACTION_TEMPLATE;
        setVisible(false);
      }
    });
    jButtonCancel.setText("Close");
    jButtonCancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        setVisible(false);
      }
    });
    jButtonHelp.setText("Help");
    jButtonHelp.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        WebBrowser.help("designer#CreateNewLesson", true);
      }
    });
    getContentPane().add(panel1);

    buttonGroup.add(jRadioButtonEmpty);
    buttonGroup.add(jRadioButtonOpenExisting);
    buttonGroup.add(jRadioButtonOpenRecent);
    buttonGroup.add(jRadioButtonTemplate);

    lessonScrollPanel.setBorder(titledBorder2);

    jPanel1.add(jRadioButtonTemplate,                      new GridBagConstraints(0, 1, 3, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 5, 0, 5), 5, 5));
    jPanel1.add(lessonScrollPanel,                              new GridBagConstraints(0, 2, 3, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 20, 5, 5), 5, 5));
    jPanel1.add(jRadioButtonOpenExisting,                    new GridBagConstraints(0, 3, 3, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 5, 5, 0), 5, 5));
    jPanel1.add(jRadioButtonOpenRecent,                  new GridBagConstraints(0, 4, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 5, 5, 0), 5, 5));
    jPanel1.add(jComboBoxRecent,                      new GridBagConstraints(1, 4, 2, 1, 1.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 5, 5), 5, 5));
    jPanel1.add(jRadioButtonEmpty,                    new GridBagConstraints(0, 0, 3, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 5, 5, 5), 5, 5));
    jPanel1.add(jButtonCancel,   new GridBagConstraints(2, 5, 1, 1, 0.0, 0.0
            ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(5, 5, 5, 5), 0, 0));
    jPanel1.add(jButtonHelp,  new GridBagConstraints(0, 5, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 5, 5, 5), 0, 0));
    jPanel1.add(jButtonOK,    new GridBagConstraints(1, 5, 1, 1, 1.0, 0.0
            ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(5, 5, 5, 0), 0, 0));
    lessonScrollPanel.getViewport().add(lessonList);

    jRadioButtonEmpty.setSelected(true);
    panel1.add(jPanel1, BorderLayout.CENTER);
    jButtonOK.requestFocus();
    getRootPane().setDefaultButton(jButtonOK);
  }

  public int getAction() {
    return action;
  }

  public NewLessonDialog getDialog() { return this; }

  public String getRecentLesson() {
    return (String) jComboBoxRecent.getSelectedItem();
  }

  public String getTemplateLesson() {
    return ((LessonListItem) lessonList.getSelectedValue()).getFilename();
  }
}
