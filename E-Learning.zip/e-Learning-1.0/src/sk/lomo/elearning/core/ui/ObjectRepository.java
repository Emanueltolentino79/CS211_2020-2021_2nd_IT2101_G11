package sk.lomo.elearning.core.ui;

/**
 * <p>Title: Object repository</p>
 * <p>Description: Class maintaining the object repository (object library) and
 * object creation.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;
import java.util.*;
import javax.swing.*;
import sk.lomo.elearning.core.*;
import sk.lomo.elearning.core.ui.state.*;

/** Class maintaining the object repository (object library) and
 * object creation. */

public class ObjectRepository extends JTabbedPane {
  public Library library = Library.getLibrary();
  private sk.lomo.elearning.core.ui.state.StateManager stateManager;

  /**
   * Returns list in active repository tab.
   * @return JList that is currently selected
   */
  public JList getSelectedList() {
    JScrollPane jsp = (JScrollPane) this.getSelectedComponent();
    try {
      return (JList) jsp.getViewport().getComponent(0);
      } catch (Exception e) {  }
      return null;
  }

  /**
   * @return class name of selected object in active tab.
   */
  public String getSelectedObjectClassname() {
    try {
    JList list = this.getSelectedList();
    return ((ObjectCell) list.getSelectedValue()).getClassName();
    } catch (Exception e) {
    }
    return null;
  }

  /** Creates a new tab (category)
   * @return container (JScrollPane).
   * @param name category name*/
  protected JScrollPane createCategory(String name) {
    JScrollPane jsp = new JScrollPane();
    jsp.setName(name);
    add(jsp);
    return jsp;
  }

  protected void fireStateChanged() {
    super.fireStateChanged();

    for (int i=0;i<this.getComponentCount(); i++) {
      JScrollPane jsp = (JScrollPane) getComponent(i);
      if (jsp.getViewport().getComponentCount()>0) {
        JList list = (JList) jsp.getViewport().getComponent(0);
        list.clearSelection();
      }
    }

  }

  public void clearSelection() {
    for (int i=0;i<this.getComponentCount(); i++) {
      JScrollPane jsp = (JScrollPane) getComponent(i);
      if (jsp.getViewport().getComponentCount()>0) {
        JList list = (JList) jsp.getViewport().getComponent(0);
        list.clearSelection();
      }
    }
  }

  public StateManager getStateManager() {
    return stateManager;
  }

  public void setStateManager(StateManager stateManager) {
    this.stateManager = stateManager;
  }


  /**
   * Creates library, loads objects into library and creates all
   * the repository tabs by object categories.
   */
  public ObjectRepository() {
    library.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        refreshLibrary();
      }
    });
  }

  public void refreshLibrary() {
    String prevSelelected = (getSelectedComponent()==null) ? null : getSelectedComponent().getName();
    removeAll();
    Component basicCategory = null;

    Iterator categories= library.objectsByCategories.keySet().iterator();

    while (categories.hasNext()) {
      Object category = categories.next();
      Iterator objects = ((Vector) library.objectsByCategories.get(category)).iterator();

      JScrollPane tab = createCategory(category.toString());

      if (category.toString()=="Basic") basicCategory=tab;

      JList objectList = new JList(new DefaultListModel());
      objectList.setTransferHandler(new ObjRepTransferHandler());
      objectList.addMouseListener(new MouseAdapter() {
        public void mousePressed(MouseEvent e) {
          if (!e.isPopupTrigger()) {
            JComponent c = (JComponent) e.getSource();
            TransferHandler th = c.getTransferHandler();
            th.exportAsDrag(c, e, TransferHandler.COPY);
            stateManager.setStateCreate();
          }
        }
      });
      objectList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
      objectList.setFont(new Font("Dialog",Font.PLAIN,10));

      objectList.setCellRenderer(new ObjectCell("","",null));

      while (objects.hasNext()) {
        Class object = (Class) objects.next();
          ( (DefaultListModel) objectList.getModel()).addElement(
              new ObjectCell(object.getName(), library.getDisplayName(object),
              library.getDisplayIcon(object))
              );
      }
      tab.getViewport().add(objectList);
    }



    if (library.objectsRuntime.keySet().size()>0) {
      JScrollPane tab = createCategory("Runtime");

      setForegroundAt(getComponentCount() - 1, Color.WHITE);

      JList objectList = new JList(new DefaultListModel());
      objectList.setTransferHandler(new ObjRepTransferHandler());
      objectList.addMouseListener(new MouseAdapter() {
        public void mousePressed(MouseEvent e) {
          if (!e.isPopupTrigger()) {
            JComponent c = (JComponent) e.getSource();
            TransferHandler th = c.getTransferHandler();
            th.exportAsDrag(c, e, TransferHandler.COPY);
            stateManager.setStateCreate();
          }
        }
      });
      objectList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
      objectList.setFont(new Font("Dialog", Font.PLAIN, 10));

      objectList.setCellRenderer(new ObjectCell("", "", null));
      Iterator i = library.objectsRuntime.keySet().iterator();
      while (i.hasNext()) {
        String name = (String) i.next();
        Icon icon = library.getRuntimeDisplayIcon(name);
        ( (DefaultListModel) objectList.getModel()).addElement(
            new ObjectCell(name, icon));
      }
      tab.getViewport().add(objectList);
    }
    if (basicCategory!=null) setSelectedComponent(basicCategory);
    for (int i=0; i<getComponentCount(); i++) {
      if (getComponent(i).getName().equals(prevSelelected)) {
        setSelectedComponent(getComponent(i));
      }
    }
  }
}
