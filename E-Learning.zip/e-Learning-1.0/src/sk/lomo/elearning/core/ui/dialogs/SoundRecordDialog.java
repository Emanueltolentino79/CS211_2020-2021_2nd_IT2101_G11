package sk.lomo.elearning.core.ui.dialogs;

/**
 * <p>Title: SoundRecordDialog</p>
 * <p>Description: Dialog dealing with sound recording</p>
 * <p>Author: Julius Loman</p>
 * @version 1.0
 */

import java.awt.*;
import javax.swing.*;
import java.io.IOException;
import java.io.*;

import javax.sound.sampled.*;
import java.awt.event.*;

import sk.lomo.elearning.Utils;


/** Tread for recording sound */
class SoundRecordThread extends Thread {
  private byte[] recordBuffer = new byte[128];
  private TargetDataLine line;
  private AudioFileFormat.Type targetType;
  private AudioInputStream audioInputStream;
  private ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
  private AudioFormat audioFormat;

  public SoundRecordThread(TargetDataLine line,
      AudioFileFormat.Type targetType,
      AudioFormat audioFormat) {
    this.line = line;
    audioInputStream = new AudioInputStream(line);
    this.targetType = targetType;
    this.audioFormat = audioFormat;
  }

  public void start() {
    line.start();
    super.start();
  }

  public void stopRecording() {
    Utils.sprintln("[SoundRecordThread] Stopping recording");
    line.stop();
    line.close();
    int numBytesRead = line.read(recordBuffer, 0, recordBuffer.length);
    if (numBytesRead > 0) {
      outputStream.write(recordBuffer, 0, numBytesRead);
    }
  }

  public void run() {
    Utils.sprintln("[SoundRecordThread] Recording");
    int numBytesRead = line.read(recordBuffer, 0, recordBuffer.length);
    while (numBytesRead > 0) {
      outputStream.write(recordBuffer, 0, numBytesRead);
      numBytesRead = line.read(recordBuffer, 0, recordBuffer.length);
    }
  }

  public void save(OutputStream os) {
    byte[] recordedData = outputStream.toByteArray();
    ByteArrayInputStream bytearrayinputstream = new ByteArrayInputStream(
        recordedData);
    try {
      AudioInputStream bdhBlf = new AudioInputStream(bytearrayinputstream,
          audioFormat, recordedData.length / audioFormat.getFrameSize());
      AudioSystem.write(bdhBlf, AudioFileFormat.Type.WAVE, os);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}

/** Thread used for playing sound */
class SoundPlayThread extends Thread {
  /** sound data */
  private byte[] soundData;
  private JButton playerBtn;
  private boolean canPlay = true;

  /** cretes play thread on given soundata
   * @param sound sound data */
  public SoundPlayThread(byte[] sound, JButton playerBtn) {
    soundData = sound;
    this.playerBtn = playerBtn;
  }

  public void stopPlaying() {
    canPlay = false;
  }

  /** runs the thread */
  public void run() {
    try {
      AudioInputStream stream = AudioSystem.getAudioInputStream(new
          ByteArrayInputStream(soundData));

      AudioFormat format = stream.getFormat();
      if (format.getEncoding() != AudioFormat.Encoding.PCM_SIGNED) {
        format = new AudioFormat(
            AudioFormat.Encoding.PCM_SIGNED,
            format.getSampleRate(),
            format.getSampleSizeInBits() * 2,
            format.getChannels(),
            format.getFrameSize() * 2,
            format.getFrameRate(),
            true); // big endian
        stream = AudioSystem.getAudioInputStream(format, stream);
      }

      SourceDataLine.Info info = new DataLine.Info(
          SourceDataLine.class, stream.getFormat(),
          ( (int) stream.getFrameLength() * format.getFrameSize()));
      SourceDataLine line = (SourceDataLine) AudioSystem.getLine(info);
      line.open(stream.getFormat());
      line.start();

      int numRead = 0;
      byte[] buf = new byte[line.getBufferSize()];

      while ( ((numRead = stream.read(buf, 0, buf.length)) >= 0) && canPlay){
        int offset = 0;
        while (offset < numRead) {
          offset += line.write(buf, offset, numRead - offset);
        }
      }
      line.drain();
      line.stop();
      line.close();
      playerBtn.setText("Play");
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }
}

/** Dialog dealing with sound recording. */

public class SoundRecordDialog extends JDialog {
  ByteArrayOutputStream soundData = new ByteArrayOutputStream();

  SoundPlayThread player;
  private int result = JOptionPane.CANCEL_OPTION;

  JPanel panel1 = new JPanel();
  GridBagLayout gridBagLayout1 = new GridBagLayout();
  JButton jButtonOK = new JButton();
  JButton jButtonCancel = new JButton();
  JLabel jLabelFreq = new JLabel();
  JComboBox jComboBoxFrequency = new JComboBox();
  JLabel jLabelBits = new JLabel();
  JLabel jLabelChannels = new JLabel();
  JButton jButtonRecord = new JButton();
  JLabel jLabelInfo = new JLabel();
  JRadioButton jRadioButton16bit = new JRadioButton();
  JRadioButton jRadioButton2 = new JRadioButton();
  ButtonGroup buttonGroupBits = new ButtonGroup();
  JRadioButton jRadioButtonStereo = new JRadioButton();
  JRadioButton jRadioButton3 = new JRadioButton();
  JButton jButtonPlay = new JButton();
  ButtonGroup buttonGroupChannels = new ButtonGroup();

  private SoundRecordDialog(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  public SoundRecordDialog() {
    this(null, "Record sound", true);
  }

  private void jbInit() throws Exception {
    panel1.setLayout(gridBagLayout1);
    jButtonOK.setText("OK");
    jButtonOK.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonOK_actionPerformed(e);
      }
    });
    jButtonCancel.setText("Cancel");
    jButtonCancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonCancel_actionPerformed(e);
      }
    });
    jLabelFreq.setText("Frequency");
    jLabelBits.setText("Bits");
    jLabelChannels.setText("Channels");
    jButtonRecord.setText("Record");
    jButtonRecord.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonRecord_actionPerformed(e);
      }
    });
    jLabelInfo.setForeground(UIManager.getColor("CheckBox.focus"));
    jLabelInfo.setHorizontalAlignment(SwingConstants.LEADING);
    jLabelInfo.setText("Select desired sound quality and press record");
    jRadioButton16bit.setActionCommand("16bit");
    jRadioButton16bit.setSelected(true);
    jRadioButton16bit.setText("16bit");
    jRadioButton2.setText("8bit");
    jRadioButtonStereo.setSelected(true);
    jRadioButtonStereo.setText("Stereo");
    jRadioButton3.setText("Mono");
    jButtonPlay.setEnabled(false);
    jButtonPlay.setFocusPainted(true);
    jButtonPlay.setText("Play");
    jButtonPlay.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonPlay_actionPerformed(e);
      }
    });
    getContentPane().add(panel1);
    panel1.add(jButtonCancel, new GridBagConstraints(3, 4, 1, 1, 0.0, 0.0
        , GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(5, 0,
        5, 5), 0, 0));
    panel1.add(jButtonRecord, new GridBagConstraints(0, 4, 1, 1, 0.0, 0.0
        , GridBagConstraints.WEST, GridBagConstraints.VERTICAL, new Insets(5,
        5, 5, 5), 0, 0));
    panel1.add(jLabelChannels, new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0
        , GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL,
        new Insets(5, 5, 0, 5), 0, 0));
    panel1.add(jLabelBits, new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
        , GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 5,
        0, 5), 0, 0));
    panel1.add(jLabelFreq, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
        , GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 5,
        0, 5), 0, 0));
    panel1.add(jComboBoxFrequency, new GridBagConstraints(1, 1, 3, 1, 1.0,
        0.0
        , GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
        new Insets(5, 5, 0, 5), 0, 0));
    panel1.add(jLabelInfo, new GridBagConstraints(0, 0, 4, 1, 0.0, 0.0
        , GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 5,
        0, 0), 0, 0));
    panel1.add(jRadioButton16bit, new GridBagConstraints(1, 2, 1, 1, 0.0, 0.0
        , GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 5,
        0, 0), 0, 0));
    panel1.add(jRadioButton2, new GridBagConstraints(2, 2, 2, 1, 0.0, 0.0
        , GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 5,
        0, 0), 0, 0));
    panel1.add(jButtonOK, new GridBagConstraints(2, 4, 1, 1, 1.0, 0.0
        , GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(5, 5,
        5, 5), 0, 0));


    ( (DefaultComboBoxModel) jComboBoxFrequency.getModel()).addElement(new
        Integer(44100));
//    ( (DefaultComboBoxModel) jComboBoxFrequency.getModel()).addElement(new
//        Integer(22100));
//    ( (DefaultComboBoxModel) jComboBoxFrequency.getModel()).addElement(new
//        Integer(11050));
    buttonGroupBits.add(jRadioButton2);
    panel1.add(jRadioButtonStereo, new GridBagConstraints(1, 3, 1, 1, 0.0,
        0.0
        , GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(5, 5,
        0, 0), 0, 0));
    panel1.add(jRadioButton3, new GridBagConstraints(2, 3, 1, 1, 0.0, 0.0
        , GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 5,
        0, 0), 0, 0));
    buttonGroupBits.add(jRadioButton16bit);
    panel1.add(jButtonPlay, new GridBagConstraints(1, 4, 1, 1, 0.0, 0.0
        , GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0,
        0, 0), 0, 0));
    buttonGroupChannels.add(jRadioButtonStereo);
    buttonGroupChannels.add(jRadioButton3);
    jComboBoxFrequency.setSelectedIndex(0);
    getRootPane().setDefaultButton(jButtonOK);
  }

  void jButtonRecord_actionPerformed(ActionEvent e) {
    soundData = new ByteArrayOutputStream();
    float freq;
    try {
      freq = ( (Integer) jComboBoxFrequency.getSelectedItem()).floatValue();
    } catch (ClassCastException ex) {
      freq = 44100.0F;
    }
//    AudioFormat audioFormat = new AudioFormat(AudioFormat.Encoding.PCM_SIGNED, 44100.0F,
//        16, 2, 4, 44100.0F, true);
    AudioFormat audioFormat = new AudioFormat(AudioFormat.Encoding.PCM_SIGNED, freq,
        (jRadioButton16bit.isSelected()) ? (16) : (8) ,
        (jRadioButtonStereo.isSelected()) ? (2) : (1) ,
        (jRadioButton16bit.isSelected()) ? (
          (jRadioButtonStereo.isSelected()) ? (4) : (2)) :
          ((jRadioButtonStereo.isSelected()) ? (2) : (1))
        , freq, true);
    DataLine.Info info = new DataLine.Info(TargetDataLine.class, audioFormat);
    TargetDataLine targetDataLine = null;
    try {
      targetDataLine = (TargetDataLine) AudioSystem.getLine(info);
      targetDataLine.open(audioFormat);
    } catch (Exception ex) {
      JOptionPane.showMessageDialog(this, ex.getLocalizedMessage(),
          "Error", JOptionPane.ERROR_MESSAGE);
    }
    AudioFileFormat.Type targetType = AudioFileFormat.Type.WAVE;
    SoundRecordThread recorder = new SoundRecordThread(
        targetDataLine,
        targetType, audioFormat);
    JOptionPane.showMessageDialog(this, "Press OK to start recording.",
        "Start recording", JOptionPane.INFORMATION_MESSAGE);
    Utils.sprintln("Recording...");
    recorder.start();

    JOptionPane.showMessageDialog(this, "Press OK to stop recording.",
        "Stop recording",
        JOptionPane.INFORMATION_MESSAGE);

    recorder.stopRecording();
    targetDataLine.stop();
    targetDataLine.close();

    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    recorder.save(baos);
    soundData = baos;
    Utils.sprintln("Recorded "+soundData.size());
    if (soundData.size()>0) {
      jButtonPlay.setEnabled(true);
    }
    Utils.sprintln("Recording stopped.");
    jButtonRecord.setEnabled(false);
  }

  void jButtonOK_actionPerformed(ActionEvent e) {
    result = JOptionPane.OK_OPTION;
    setVisible(false);
  }

  void jButtonCancel_actionPerformed(ActionEvent e) {
    setVisible(false);
  }

  void jButtonPlay_actionPerformed(ActionEvent e) {
    if (player==null) {
      player = new SoundPlayThread(soundData.toByteArray(), jButtonPlay);
      jButtonPlay.setText("Stop");
      player.start();
    } else {
      player.stopPlaying();
      player=null;
    }
  }

  public byte[] getRecordedSound() {
    if (soundData.size()>0) return soundData.toByteArray();
    return null;
  }
}
