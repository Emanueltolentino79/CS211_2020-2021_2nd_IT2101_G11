package sk.lomo.elearning.core.ui.dialogs;

/**
 * <p>Title: QuizReportDialog</p>
 * <p>Description: Dialog displayed by quiz report object.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.text.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/** Dialog displayed by quiz report object. */

public class QuizReportDialog extends JDialog {
  JPanel panel1 = new JPanel();
  GridBagLayout gridBagLayout1 = new GridBagLayout();
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JLabel jLabelGainedScore = new JLabel();
  JLabel jLabel4 = new JLabel();
  JButton jButton1 = new JButton();
  JLabel jLabel5 = new JLabel();
  JLabel jLabelMaximalScore = new JLabel();
  JLabel jLabel7 = new JLabel();
  JLabel jLabelPercentualSuccess = new JLabel();
  JLabel jLabel6 = new JLabel();
  JLabel jLabelMinimumScore = new JLabel();
  JScrollPane jScrollPane1 = new JScrollPane();
  JTextArea jTextAreaDetails = new JTextArea();

  protected QuizReportDialog(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public QuizReportDialog(double score, double maximum, double minimum, String details) {
    this(null, "Quiz report", false);
    jLabelGainedScore.setText(new DecimalFormat("0.00").format(score));
    jLabelMaximalScore.setText(new DecimalFormat("0.00").format(maximum));
    jLabelMinimumScore.setText(new DecimalFormat("0.00").format(minimum));
    jLabelPercentualSuccess.setText(new DecimalFormat("0.00").format((score/maximum)*100)+" %");
    jTextAreaDetails.setText(details);
  }

  private void jbInit() throws Exception {
    panel1.setLayout(gridBagLayout1);
    jLabel1.setFont(new java.awt.Font("Dialog", 1, 20));
    jLabel1.setText("Lesson quiz report");
    jLabel2.setHorizontalAlignment(SwingConstants.LEFT);
    jLabel2.setHorizontalTextPosition(SwingConstants.LEFT);
    jLabel2.setText("Gained score:");
    jLabel4.setText("Detailed results:");
    jButton1.setActionCommand("OK");
    jButton1.setText("Close");
    jButton1.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        setVisible(false);
      }
    });
    jLabel5.setText("Maximal score:");
    jLabel7.setText("Percentual success:");
    jLabelMaximalScore.setText("maximal");
    panel1.setMinimumSize(new Dimension(300, 300));
    panel1.setPreferredSize(new Dimension(300, 300));
    jLabel6.setText("Minimum score:");
    jLabelGainedScore.setText("gained");
    jLabelPercentualSuccess.setText("percentual");
    jLabelMinimumScore.setText("minimum");
    jTextAreaDetails.setMinimumSize(new Dimension(200, 120));
    jTextAreaDetails.setPreferredSize(new Dimension(200, 120));
    jTextAreaDetails.setEditable(false);
    jTextAreaDetails.setText("");
    getContentPane().add(panel1);
    panel1.add(jLabel1,                    new GridBagConstraints(0, 0, 3, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(5, 5, 5, 5), 0, 0));
    panel1.add(jLabel2,                   new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 5, 5, 0), 0, 0));
    panel1.add(jLabel4,                      new GridBagConstraints(0, 5, 3, 1, 0.0, 0.0
            ,GridBagConstraints.SOUTHWEST, GridBagConstraints.NONE, new Insets(10, 5, 0, 5), 0, 0));
    panel1.add(jButton1,                  new GridBagConstraints(0, 7, 2, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(5, 5, 5, 5), 0, 0));
    panel1.add(jLabel5,               new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 5, 5, 5), 0, 0));
    panel1.add(jLabel7,              new GridBagConstraints(0, 4, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 5, 5, 5), 0, 0));
    panel1.add(jLabelPercentualSuccess,             new GridBagConstraints(1, 4, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    panel1.add(jLabel6,             new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 5, 5, 5), 0, 0));
    panel1.add(jScrollPane1,      new GridBagConstraints(0, 6, 2, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
    panel1.add(jLabelGainedScore,  new GridBagConstraints(1, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    panel1.add(jLabelMaximalScore, new GridBagConstraints(1, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    panel1.add(jLabelMinimumScore, new GridBagConstraints(1, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jScrollPane1.getViewport().add(jTextAreaDetails, null);
  }


}
