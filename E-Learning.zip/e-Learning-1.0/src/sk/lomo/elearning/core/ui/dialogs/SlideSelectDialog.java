package sk.lomo.elearning.core.ui.dialogs;

/**
 * <p>Title: SlideSelectDialog</p>
 * <p>Description: Dialog for selecing slide.</p>
 * <p>Author: Julius Loman</p>
 * @version 1.0
 */

import java.awt.*;
import javax.swing.*;
import sk.lomo.elearning.core.ui.*;
import sk.lomo.elearning.core.*;
import java.awt.event.*;

/** Dialog for selecing slide. */

public class SlideSelectDialog extends JDialog {
  JPanel panel1 = new JPanel();
  public int option=JOptionPane.CANCEL_OPTION;
  public int number;
  GridBagLayout gridBagLayout1 = new GridBagLayout();
  JButton jButtonOK = new JButton();
  JScrollPane jScrollPane1 = new JScrollPane();
  SlideList slideList;
  JButton jButtonCancel = new JButton();
  JButton jButtonHelp = new JButton();

  public SlideSelectDialog(Frame frame, String title, boolean modal, Lesson lesson) {
    super(frame, title, modal);
    slideList = new SlideList(lesson);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
    slideList.refresh();
  }

  private void jbInit() throws Exception {
    panel1.setMinimumSize(new Dimension(400, 150));
    panel1.setPreferredSize(new Dimension(400, 300));
    panel1.setLayout(gridBagLayout1);
    jButtonOK.setToolTipText("");
    jButtonOK.setText("Select");
    jButtonCancel.setText("Cancel");
    jButtonHelp.setText("Help");
    jButtonHelp.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonHelp_actionPerformed(e);
      }
    });
    getContentPane().add(panel1);
    jScrollPane1.getViewport().add(slideList);
    panel1.add(jScrollPane1,                   new GridBagConstraints(0, 0, 4, 1, 1.0, 1.0
            ,GridBagConstraints.NORTH, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
    panel1.add(jButtonHelp,         new GridBagConstraints(0, 1, 1, 1, 0.1, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 5, 5, 0), 0, 0));
    panel1.add(jButtonOK,    new GridBagConstraints(1, 1, 1, 1, 0.1, 0.0
            ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(5, 5, 5, 0), 0, 0));
    panel1.add(jButtonCancel,   new GridBagConstraints(2, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(5, 5, 5, 5), 0, 0));
    jButtonOK.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        option = JOptionPane.OK_OPTION;
        number = slideList.getSelectedSlideNumber();
        setVisible(false);
      }
    });
    jButtonCancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        option = JOptionPane.CANCEL_OPTION;
        setVisible(false);
      }
    });
    getRootPane().setDefaultButton(jButtonOK);
  }

  void jButtonHelp_actionPerformed(ActionEvent e) {
    WebBrowser.help("designer#SlideSelectDialog", true);
  }

}

