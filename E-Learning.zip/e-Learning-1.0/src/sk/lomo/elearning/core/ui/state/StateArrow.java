package sk.lomo.elearning.core.ui.state;

/**
 * <p>Title: StateArrow </p>
 * <p>Description: Realizes mouse arrow tool behavior (object resizing, moving, context menu, ... )</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.awt.event.*;
import java.awt.*;
import javax.swing.*;
import java.util.*;
import sk.lomo.elearning.core.interfaces.*;
import sk.lomo.elearning.core.ui.*;
import sk.lomo.elearning.core.commands.*;
import sk.lomo.elearning.core.*;
import sk.lomo.elearning.Utils;

abstract class ObjectActionListener implements ActionListener {
  private JComponent object;
  private Slide canvas;

  public Slide getCanvas() { return canvas; }
  public JComponent getObject() { return object; }

  public ObjectActionListener(Slide canvas, JComponent object) {
    this.object=object;
    this.canvas=canvas;
  }
}

/** Realizes mouse arrow tool behavior (object resizing, moving, context menu, ... )*/

public class StateArrow extends State implements MouseMotionListener, MouseListener {
  /** No action*/
  protected static final int NO_ACTION=0;
  /** Dragging action*/
  protected static final int DRAGGING_ACTION=1;
  /** Resizing action*/
  protected static final int RESIZING_ACTION=2;
  /** Popup menu action*/
  protected static final int POPUP_ACTION=3;
  /** Object action*/
  protected static final int FOCUS_ACTION=4;

  /** icon for context menu*/
  private Icon iconSlide = Utils.getGraphics("Slide.gif");
  /** icon for context menu*/
  private Icon iconBringToFront = Utils.getGraphics("MenuBringToFront.gif");
  /** icon for context menu*/
  private Icon iconSendToBack = Utils.getGraphics("MenuSendToBack.gif");
  /** icon for context menu*/
  private Icon iconAlignToLeft = Utils.getGraphics("MenuAlignToLeft.gif");
  /** icon for context menu*/
  private Icon iconAlignToRight = Utils.getGraphics("MenuAlignToRight.gif");
  /** icon for context menu*/
  private Icon iconAlignToTop = Utils.getGraphics("MenuAlignToTop.gif");
  /** icon for context menu*/
  private Icon iconAlignToBottom = Utils.getGraphics("MenuAlignToBottom.gif");
  /** icon for context menu*/
  private Icon iconAlignToGrid = Utils.getGraphics("MenuAlignToGrid.gif");
  /** icon for context menu*/
  private Icon iconEditCut = Utils.getGraphics("MenuEditCut.gif");
  /** icon for context menu*/
  private Icon iconEditCopy = Utils.getGraphics("MenuEditCopy.gif");
  /** icon for context menu*/
  private Icon iconEditPaste = Utils.getGraphics("MenuEditPaste.gif");
  /** icon for context menu*/
  private Icon iconEditDelete = Utils.getGraphics("MenuEditDelete.gif");
  /** icon for context menu*/
  private Icon iconObjectRename = Utils.getGraphics("MenuObjectRename.gif");
  /** icon for context menu*/
  private Icon iconObjectAddToRepository = Utils.getGraphics("MenuObjectAddToRepository.gif");
  /** icon for context menu*/
  private Icon iconRemoveSlide = Utils.getGraphics("MenuSlideRemoveSlide.gif");
  /** icon for context menu*/
  private Icon iconRenameSlide = Utils.getGraphics("MenuObjectRename.gif");
  /** icon for context menu*/
  private Icon iconSlideBackground = Utils.getGraphics("MenuSlideBackground.gif");
  /** icon for context menu*/
  private Icon iconSlideDefault = Utils.getGraphics("MenuSlideNewSlide.gif");

  /** Original point for object dragging*/
  private JComponent dragOrigObject;
  /** Original point for object dragging*/
  private Point dragOrigPoint = new Point(0,0);
  /** Original point for objects dragging*/
  private Point[] dragOrigPoints;
  /** Start point for object dragging*/
  private Point dragStartPoint = new Point(0,0);
  /** Point for object dragging (click point inside object)*/
  private Point dragInnerPoint = new Point(0,0);
  /** Point for object resizing (click point inside object)*/
  private Dimension resizeStartDimension = new Dimension(0,0);
  /** Point for object resizing (click point inside object)*/
  private Point resizeBoderInnerPoint = new Point(0,0);
  /** Canvas on which the <code>StateArrow> works*/
  private Slide canvas;

  /** Current action*/
  private int action = NO_ACTION;
  /** Object corner which is the object resized from*/
  private int resizingFromCorner = ResizeBorder.CORNER_NONE;

  /** Cursor for NW object resizing*/
  private Cursor resizeNWCursor = new Cursor(Cursor.NW_RESIZE_CURSOR);
  /** Cursor for NE object resizing*/
  private Cursor resizeNECursor = new Cursor(Cursor.NE_RESIZE_CURSOR);
  /** Cursor for SW object resizing*/
  private Cursor resizeSWCursor = new Cursor(Cursor.SW_RESIZE_CURSOR);
  /** Cursor for SE object resizing*/
  private Cursor resizeSECursor = new Cursor(Cursor.SE_RESIZE_CURSOR);
  /** Cursor for object moving*/
  private Cursor moveCursor = new Cursor(Cursor.MOVE_CURSOR);
  /** State manager this state is connected to */
  private StateManager stateManager;
  /** ObjectTransferHandler for handling cut/copy/paste operations */
  private ObjTransferHandler objectTransferHandler = new ObjTransferHandler(null);
  /** Command for resizing object */
  private SetBoundsCommand setBoundsCommand;


  /** Click on object
   * @param e Mouse event*/
  public void mouseClicked(MouseEvent e) {}
  /** Entering object
   * @param e Mouse event*/
  public void mouseEntered(MouseEvent e) {}
  /** Exiting object
   * @param e Mouse event*/
  public void mouseExited(MouseEvent e) {}
  /** Moving mouse on object. Realizes Cursor changes.
   * @param e Mouse event*/
  public void mouseMoved(MouseEvent e) {
    Container jc = (JComponent) e.getSource();
    while (!(jc instanceof IBase)) { jc = jc.getParent(); };

      int rfc;
      if (jc instanceof IObject) {
        if (((IObject) jc).isObjectSelected()) {
          if (jc.hasFocus()) {
           jc.setCursor(((IObject) jc).getObjectCursor());
          } else
          {
            try {
              if (
                  (((IVisible) jc).getResizeBorder().inResizeArea(jc.getWidth(),jc.getHeight(),e))
                  )
              {
                rfc=((IVisible) jc).getResizeBorder().getCorner(jc.getWidth(),jc.getHeight(),e);

                if (rfc==(ResizeBorder.CORNER_BOTTOM+ResizeBorder.CORNER_RIGHT)) {
                  jc.setCursor(resizeSECursor);
                }
                if (rfc==(ResizeBorder.CORNER_TOP + ResizeBorder.CORNER_RIGHT)) {
                  jc.setCursor(resizeNECursor);
                }
                if (rfc==(ResizeBorder.CORNER_TOP + ResizeBorder.CORNER_LEFT)) {
                  jc.setCursor(resizeNWCursor);
                }
                if (rfc==(ResizeBorder.CORNER_BOTTOM + ResizeBorder.CORNER_LEFT)) {
                  jc.setCursor(resizeSWCursor);
                }
              } else {
                jc.setCursor(moveCursor);
              }
            } catch (ClassCastException ex) {
              jc.setCursor(moveCursor);
            }
          }
        } else {
          jc.setCursor(Cursor.getDefaultCursor());
        }
      }
  }

  /** Dragging on object. Realizes object resizing and moving.
   * @param e Mouse event*/
  public void mouseDragged(MouseEvent e) {
    Container jc = (JComponent) e.getSource();
    while (!(jc instanceof IBase)) { jc = jc.getParent(); };
    if (!((IBase) jc).isDesignMode()) return;

    if (jc==canvas) {
      canvas.setSelectionEndPoint(new Point(e.getX(),e.getY()));
      canvas.selectObjectsInSelection();
      return;
    }

      int x,y;
      int rip_x = (int) resizeBoderInnerPoint.getX();
      int rip_y = (int) resizeBoderInnerPoint.getY();

      if (!jc.hasFocus())
        if (getAction() == RESIZING_ACTION) {
          double aspectRatio = (double) resizeStartDimension.getWidth() /
              resizeStartDimension.getHeight();
          double resizedAspectRatio;

          try {
            if (resizingFromCorner ==
                (ResizeBorder.CORNER_BOTTOM + ResizeBorder.CORNER_RIGHT)) {
              resizedAspectRatio = (double) e.getX() / e.getY();
              jc.setBounds(jc.getX(), jc.getY(), e.getX(), e.getY());
            }
            if (resizingFromCorner ==
                (ResizeBorder.CORNER_TOP + ResizeBorder.CORNER_RIGHT)) {
              jc.setBounds(jc.getX(), jc.getY() + e.getY(), e.getX(),
                  jc.getHeight() - e.getY());
            }
            if (resizingFromCorner ==
                (ResizeBorder.CORNER_TOP + ResizeBorder.CORNER_LEFT)) {
              jc.setBounds(jc.getX() + e.getX(), jc.getY() + e.getY(),
                  jc.getWidth() - e.getX(), jc.getHeight() - e.getY());
            }
            if (resizingFromCorner ==
                (ResizeBorder.CORNER_BOTTOM + ResizeBorder.CORNER_LEFT)) {
              jc.setBounds(jc.getX() + e.getX(), jc.getY(),
                  jc.getWidth() - e.getX(), e.getY());
            }

          } catch (Exception ex) {}
        } else {
          if (getAction() == DRAGGING_ACTION) {
            try {
              x = dragStartPoint.x + e.getX() - dragInnerPoint.x;
              y = dragStartPoint.y + e.getY() - dragInnerPoint.y;

              int dx = dragOrigPoint.x - x;
              int dy = dragOrigPoint.y - y;

              //            jc.setLocation(x,y);
              Iterator i = canvas.getSelectedObjects().iterator();

              int j = 0;
              while (i.hasNext()) {
                ( (JComponent) i.next()).setLocation(dragOrigPoints[j].x - dx,
                    dragOrigPoints[j].y - dy);
                j++;
              }
              dragStartPoint = new Point(jc.getX(), jc.getY());
            } catch (Exception ex) {}
          }
        }
 }


 /** Mouse pressing on object. Realizes object focusing, start of resizing and moving and object context menu.
  * @param e Mouse event*/
  public void mousePressed(MouseEvent e) {
    JComponent jc = (JComponent) e.getSource();
    while (!(jc instanceof IBase)) { jc = (JComponent) jc.getParent(); };

    if (!((IBase) jc).isDesignMode()) return;

    dragStartPoint=new Point(jc.getX(), jc.getY());
    dragOrigPoint=new Point(jc.getX(), jc.getY());
    dragInnerPoint=new Point(e.getX(), e.getY());
    dragOrigObject = jc;

    if (e.isPopupTrigger()) {
      setAction(POPUP_ACTION);
      if (jc instanceof Slide) slideContextMenu(e, (Slide) jc);
      else objectContextMenu(e, jc);
      return;
    }

    if (jc==canvas) {
      canvas.requestFocus();
      canvas.setSelectionStartPoint(new Point(e.getX(),e.getY()));
      canvas.setSelectionEndPoint(new Point(e.getX(),e.getY()));
      canvas.setPaintSelection(true);
      return;
    }

    if (((IBase) jc).isDesignMode()) {
      if (jc.hasFocus()) return;
      Vector v = canvas.getSelectedObjects();
      dragOrigPoints = new Point[v.size()];
      Iterator i = v.iterator();
      int j=0;
      while (i.hasNext()) {
        dragOrigPoints[j] = ((JComponent) i.next()).getLocation();
        j++;
      }

      if (e.getClickCount()==2) {
        jc.requestFocus();
        if (jc!=canvas) jc.setCursor(((IObject) jc).getObjectCursor());
        setAction(FOCUS_ACTION);
        return;
      } else {
        canvas.requestFocus();
        setAction(NO_ACTION);
      }

      try {
        if (jc instanceof IVisible)
          if (((IVisible) jc).getResizeBorder().inResizeArea(jc.getWidth(),jc.getHeight(),e)) {
            setAction(RESIZING_ACTION);
            resizingFromCorner=((IVisible) jc).getResizeBorder().getCorner(jc.getWidth(),jc.getHeight(),e);
            resizeBoderInnerPoint=((IVisible) jc).getResizeBorder().getResizeInnerPoint(jc.getWidth(),jc.getHeight(),e);
            resizeStartDimension=jc.getSize();
            setBoundsCommand = new SetBoundsCommand(jc);
            setBoundsCommand.setOldBounds(jc.getBounds());
            return;
          } else {
            if (jc instanceof IObject)
              if (((IObject) jc).isObjectSelected())
                setAction(DRAGGING_ACTION);
          }
      } catch (ClassCastException ex) {};

      if (jc instanceof IObject)
        if (((IObject) jc).isObjectSelected() && (getAction()==NO_ACTION))
          setAction(DRAGGING_ACTION);


    }
  }

  protected void slideContextMenu(MouseEvent e, Slide s) {
    JPopupMenu scm = new JPopupMenu();

    JMenuItem label = new JMenuItem("Slide     ");
    label.setIcon(iconSlide);
    label.setHorizontalAlignment(SwingConstants.LEFT);
    label.setHorizontalTextPosition(SwingConstants.RIGHT);
    label.setModel(new DefaultButtonModel() {
      public boolean isArmed() { return false; }
    });
    scm.add(label);
    scm.addSeparator();

    JMenuItem mi = new JMenuItem("Paste");
    mi.setIcon(iconEditPaste);
    mi.addActionListener(new ObjectActionListener(s,s) {
      public void actionPerformed(ActionEvent e) {
        ClipboardPasteCommand cpc = new ClipboardPasteCommand(getCanvas(), objectTransferHandler);
        cpc.redo();
        getCanvas().getLesson().commandManager.addEdit(cpc);
      }
    });
    scm.add(mi);

    mi = new JMenuItem("Remove");
    mi.setIcon(iconRemoveSlide);
    mi.addActionListener(new ObjectActionListener(s,s) {
      public void actionPerformed(ActionEvent e) {
        RemoveSlideCommand dsc = new RemoveSlideCommand(getCanvas().getLesson(), getCanvas());
        getCanvas().getLesson().commandManager.addEdit(dsc);
        dsc.redo();
      }
    });
    scm.add(mi);

    mi = new JMenuItem("Rename");
    mi.setIcon(iconRenameSlide);
    mi.addActionListener(new ObjectActionListener(s,s) {
      public void actionPerformed(ActionEvent e) {
        Object newText = JOptionPane.showInputDialog(null,"Enter slide name", "Slide name", JOptionPane.QUESTION_MESSAGE, null, null, getCanvas().getName());
        if (newText!=null) {
          ChangeObjectNameCommand conc = new ChangeObjectNameCommand(getCanvas(), newText.toString());
          getCanvas().getLesson().commandManager.addEdit(conc);
          conc.redo();
        }
        getCanvas().getLesson().fireSlideChange();
      }
    });
    scm.add(mi);

    mi = new JMenuItem("Background");
    mi.setIcon(iconSlideBackground);
    mi.addActionListener(new ObjectActionListener(s,s) {
      public void actionPerformed(ActionEvent e) {
        Color newColor = JColorChooser.showDialog(getCanvas(), "Set background color", getCanvas().getBackground());
        if (newColor!=null) {
          Vector objects = new Vector();
          objects.add(getCanvas());
          ChangeObjectColorCommand cocc = new ChangeObjectColorCommand(objects,ChangeObjectColorCommand.COLOR_BACKGROUND, newColor);
          getCanvas().getLesson().commandManager.addEdit(cocc);
          cocc.redo();
        }
      }
    });
    scm.add(mi);


    mi = new JMenuItem();
    mi.setIcon(iconAlignToGrid);
    if (canvas.getLesson().isShowGrid()) mi.setText("Hide grid"); else mi.setText("Show grid");
    mi.addActionListener(new ObjectActionListener(s,s) {
      public void actionPerformed(ActionEvent e) {
        if (getCanvas().getLesson().isShowGrid()) getCanvas().getLesson().setShowGrid(false);
        else getCanvas().getLesson().setShowGrid(true);
        getCanvas().repaint();
      }
    });
    scm.add(mi);

    mi = new JMenuItem();
    mi.setIcon(iconSlideDefault);
    mi.setText("Set slide as default");
    mi.addActionListener(new ObjectActionListener(s,s) {
      public void actionPerformed(ActionEvent e) {
        getCanvas().getLesson().setDefaultSlide(getCanvas());
      }
    });
    scm.add(mi);



    scm.show(s,e.getX(),e.getY());
  }

  /** Releasing mouse on object. Realizes end of resizing and dragging.
   * @param e Mouse event*/
  public void mouseReleased(MouseEvent e) {
    JComponent jc = (JComponent) e.getSource();

    while (!(jc instanceof IBase))
      jc = (JComponent) jc.getParent();

    // show popup menu if it is a popup action
    if (e.isPopupTrigger()) {
      setAction(POPUP_ACTION);
      if (jc instanceof Slide) slideContextMenu(e, (Slide) jc);
      else objectContextMenu(e, jc);
    }

    if (getAction()==NO_ACTION) {
      if (!e.isShiftDown()) {
        canvas.clearSelection();
        if (dragOrigObject instanceof IObject) {
          ((IObject) dragOrigObject).setObjectSelected(true);
        }
      } else {
        if (dragOrigObject instanceof IObject) {
          ( (IObject) dragOrigObject).setObjectSelected(! ( (IObject) e.getSource()).
              isObjectSelected());
        }
      }
      canvas.getLesson().fireSlideSelectionChange(canvas);
    }

    if (jc==canvas) {
      if (!e.isShiftDown()) canvas.clearSelection();
      canvas.selectObjectsInSelection();
      canvas.setPaintSelection(false);
      setAction(NO_ACTION);
      return;
    }

    int x, y;
    if (!jc.hasFocus())
      if (getAction() == RESIZING_ACTION) {
        resizingFromCorner = ResizeBorder.CORNER_NONE;
        setAction(NO_ACTION);
        setBoundsCommand.setNewBounds(jc.getBounds());
        canvas.getLesson().commandManager.addEdit(setBoundsCommand);
        setBoundsCommand.redo();
      } else {
        if (getAction() == DRAGGING_ACTION) {
          Point dropPoint = new Point(dragStartPoint.x + e.getX() -
              dragInnerPoint.x, dragStartPoint.y + e.getY() - dragInnerPoint.y);
          Point newPoints[] = new Point[dragOrigPoints.length];
          Iterator i = canvas.getSelectedObjects().iterator();
          int j = 0;
          while (i.hasNext()) {
            newPoints[j++] = ( (JComponent) i.next()).getLocation();
          }

          canvas.getLesson().commandManager.addEdit(new ObjectMoveCommand(
              canvas.
              getSelectedObjects(), dragOrigPoints, newPoints));
//          x=dragStartPoint.x+e.getX()-dragInnerPoint.x;
//          y=dragStartPoint.y+e.getY()-dragInnerPoint.y;
//
//          jc.setBounds(x,y,jc.getWidth(),jc.getHeight());
          setAction(NO_ACTION);
        }
      }
  }

  protected void objectContextMenu(MouseEvent e, JComponent jc) {
    if (!(e.getSource() instanceof IObject)) return;
    IObject object = (IObject) e.getSource();
    JPopupMenu ocm = new JPopupMenu();
    Icon icon;
    String name;
    JMenuItem[] items = new JMenuItem[0];

    if (canvas.getSelectedObjects().size()>1) {
      name = "[Multiple objects]";
      icon = Utils.getGraphics("MenuMultipleObjects.gif");
    }
    else {
      icon = object.getRepositoryIcon();
      name = object.getDisplayName();
      items = object.getMenuItems();
      if (object.getName() != null) {
        if (object.getName() != "") {
          name = name + " [" + object.getName() + "]";

        }
      }
    }
    JMenuItem label = new JMenuItem(name+"     ");
    label.setHorizontalAlignment(SwingConstants.LEFT);
    label.setIcon(icon);
    label.setHorizontalTextPosition(SwingConstants.RIGHT);
    label.setModel(new DefaultButtonModel() {
      public boolean isArmed() {
        return false;
      }
    });
    ocm.add(label);

    if (items.length > 0) {
      ocm.addSeparator();
    }
    for (int i = 0; i < items.length; i++) {
      ocm.add(items[i]);
    }

    ocm.addSeparator();

    JMenuItem mi;
    JMenu alignMenu = new JMenu("Alignment");
    mi = new JMenuItem("Align to left");
    mi.setIcon(iconAlignToLeft);
    mi.addActionListener(new ObjectActionListener((Slide) jc.getParent(), jc) {
      public void actionPerformed(ActionEvent e) {
        Vector objects = getCanvas().getSelectedObjects();
        Iterator i = objects.iterator();
        int minLeft=((JComponent) i.next()).getLocation().x;
        while (i.hasNext()) {
          JComponent o = (JComponent) i.next();
          if (o.getLocation().x<minLeft)
            minLeft=o.getLocation().x;
        }
        i = objects.iterator();
        while (i.hasNext()) {
          JComponent o = (JComponent) i.next();
          o.setLocation(new Point(minLeft,o.getLocation().y));
        }
        getCanvas().repaint();
      }
    });
    alignMenu.add(mi);


    mi = new JMenuItem("Align to right");
    mi.setIcon(iconAlignToRight);
    mi.addActionListener(new ObjectActionListener((Slide) jc.getParent(), jc) {
      public void actionPerformed(ActionEvent e) {
        Vector objects = getCanvas().getSelectedObjects();
        Iterator i = objects.iterator();

        JComponent o = (JComponent) i.next();
        int maxRight=o.getLocation().x+o.getWidth();

        while (i.hasNext()) {
          o = (JComponent) i.next();
          if (o.getLocation().x+o.getWidth()>maxRight)
            maxRight=o.getLocation().x+o.getWidth();
        }
        i = objects.iterator();
        while (i.hasNext()) {
          o = (JComponent) i.next();
          o.setLocation(new Point(maxRight-o.getWidth(),o.getLocation().y));
        }
        getCanvas().repaint();
      }
    });
    alignMenu.add(mi);


    mi = new JMenuItem("Align to top");
    mi.setIcon(iconAlignToTop);
    mi.addActionListener(new ObjectActionListener((Slide) jc.getParent(), jc) {
      public void actionPerformed(ActionEvent e) {
        Vector objects = getCanvas().getSelectedObjects();
        Iterator i = objects.iterator();
        int minTop=((JComponent) i.next()).getLocation().y;
        while (i.hasNext()) {
          JComponent o = (JComponent) i.next();
          if (o.getLocation().y<minTop)
            minTop=o.getLocation().y;
        }
        i = objects.iterator();
        while (i.hasNext()) {
          JComponent o = (JComponent) i.next();
          o.setLocation(new Point(o.getLocation().x,minTop));
        }
        getCanvas().repaint();
      }
    });
    alignMenu.add(mi);

    mi = new JMenuItem("Align to bottom");
    mi.setIcon(iconAlignToBottom);
    mi.addActionListener(new ObjectActionListener((Slide) jc.getParent(), jc) {
      public void actionPerformed(ActionEvent e) {
        Vector objects = getCanvas().getSelectedObjects();
        Iterator i = objects.iterator();

        JComponent o = (JComponent) i.next();
        int maxTop=o.getLocation().y+o.getHeight();

        while (i.hasNext()) {
          o = (JComponent) i.next();
          if (o.getLocation().y+o.getHeight()>maxTop)
            maxTop=o.getLocation().y+o.getHeight();
        }
        i = objects.iterator();
        while (i.hasNext()) {
          o = (JComponent) i.next();
          o.setLocation(new Point(o.getLocation().x,maxTop-o.getHeight()));
        }
        getCanvas().repaint();
      }
    });
    alignMenu.add(mi);

    mi = new JMenuItem("Cut");
    mi.setIcon(iconEditCut);
    mi.addActionListener(new ObjectActionListener((Slide) jc.getParent(), jc) {
      public void actionPerformed(ActionEvent e) {
        if (getCanvas().getSelectedObjects().size() > 0) {
          ClipboardCutCommand ccc = new ClipboardCutCommand(
              getCanvas(), objectTransferHandler);
          ccc.redo();
          getCanvas().getLesson().commandManager.addEdit(ccc);
        }
      }});
    ocm.add(mi);

    mi = new JMenuItem("Copy");
    mi.setIcon(iconEditCopy);
    mi.addActionListener(new ObjectActionListener((Slide) jc.getParent(), jc) {
      public void actionPerformed(ActionEvent e) {
        if (getCanvas().getSelectedObjects().size() > 0) {
          JVector objects = getCanvas().getSelectedObjectsAsJVector();
          objectTransferHandler.getCopyAction().actionPerformed(new ActionEvent(
              objects, 0, "copy"));
        }
      }});
    ocm.add(mi);

    mi = new JMenuItem("Delete");
    mi.setIcon(iconEditDelete);
    mi.addActionListener(new ObjectActionListener((Slide) jc.getParent(), jc) {
      public void actionPerformed(ActionEvent e) {
        DeleteCommand dc = new DeleteCommand(getCanvas());
        dc.redo();
        getCanvas().getLesson().commandManager.addEdit(dc);
      }
    });
    ocm.add(mi);

    mi = new JMenuItem("Add to repository");
    mi.setIcon(iconObjectAddToRepository);
    mi.addActionListener(new ObjectActionListener((Slide) jc.getParent(), jc) {
      public void actionPerformed(ActionEvent e) {
        Object newText = JOptionPane.showInputDialog(getObject(),"Enter object name", "Object repository name",JOptionPane.QUESTION_MESSAGE,iconObjectRename,null,((IObject) getObject()).getDisplayName());
        if (newText!=null)
          Library.getLibrary().addRuntimeObject((IObject) getObject(),((IObject) getObject()).getRepositoryIcon(), newText.toString());
      }
    });
    if (canvas.getSelectedObjects().size()==1) ocm.add(mi);
    ocm.addSeparator();

    mi = new JMenuItem("Rename object");
    mi.setIcon(iconObjectRename);
    mi.addActionListener(new ObjectActionListener((Slide) jc.getParent(), jc) {
      public void actionPerformed(ActionEvent e) {
        Object newText = JOptionPane.showInputDialog(getObject(),"Enter object name", "Object name",JOptionPane.QUESTION_MESSAGE,iconObjectRename,null,getObject().getName());
        if (newText!=null) getObject().setName(newText.toString());
      }
    });
    if (canvas.getSelectedObjects().size()<=1) ocm.add(mi);

    mi = new JMenuItem("Align to grid");
    mi.setIcon(iconAlignToGrid);
    mi.addActionListener(new ObjectActionListener((Slide) jc.getParent(), jc) {
      public void actionPerformed(ActionEvent e) {
        getCanvas().alignSelectedToGrid();
      }
    });
    ocm.add(mi);


    mi = new JMenuItem("Bring to front");
    mi.setIcon(iconBringToFront);
    mi.addActionListener(new ObjectActionListener((Slide) jc.getParent(), jc) {
      public void actionPerformed(ActionEvent e) {
        ZIndexCommand zic = new ZIndexCommand(getCanvas(), getCanvas().getSelectedObjects(), ZIndexCommand.ACTION_TO_FRONT);
        getCanvas().getLesson().commandManager.addEdit(zic);
        zic.redo();
      }
    });
    ocm.add(mi);

    mi = new JMenuItem("Send to back");
    mi.setIcon(iconSendToBack);
    mi.addActionListener(new ObjectActionListener((Slide) jc.getParent(), jc) {
      public void actionPerformed(ActionEvent e) {
        ZIndexCommand zic = new ZIndexCommand(getCanvas(), getCanvas().getSelectedObjects(), ZIndexCommand.ACTION_TO_BACK);
        getCanvas().getLesson().commandManager.addEdit(zic);
        zic.redo();
      }
    });
    ocm.add(mi);

    if (((Slide) jc.getParent()).getSelectedObjects().size()>1)
      ocm.add(alignMenu);

//    Font defaultFont = new Font("Dialog",0,10);
//    for (int i=0;i<ocm.getComponentCount();i++) {
//      ocm.getComponent(i).setFont(defaultFont);
//    }
//    for (int i=0;i<alignMenu.getItemCount();i++) {
//      alignMenu.getItem(i).setFont(defaultFont);
//    }

    ocm.show((JComponent) e.getSource(),e.getX(),e.getY());
  }

  /** Setting the canvas for state.
   * @param c New Canvas*/
  public void setCanvas(Slide c) {
    this.canvas=c;
  }
  /** Creates new StateArrow
   * @param sm StateManager that should be notified after significant changes */
  public StateArrow(StateManager sm) {
    stateManager = sm;
  }
  /** Set GUI action that's active
   *  @param newAction new action to set */
  protected void setAction(int newAction) {
    action = newAction;
    if (newAction == FOCUS_ACTION) {
      Utils.sprintln("focus");
    }
    stateManager.updateState();
  }
  /** @return GUI action that's active */
  protected int getAction() {
    return action;
  }
  /** @return current */
  public String toString() {
    switch (action) {
      case RESIZING_ACTION: return "Move mouse to resize object.";
      case DRAGGING_ACTION: return "Move mouse to move objects.";
      case FOCUS_ACTION: return "Edit object.";
    }
    return "Click object to select. Right click to display object menu. Drag selected object to move. Drag object from repository to create new one.";
  }
}
