package sk.lomo.elearning.core.ui;

/**
 * <p>Title: SlideListItem</p>
 * <p>Description: Slide data container for lists and comboboxes</p>
 * <p>Author: Julius Loman</p>
 * @author unascribed
 * @version 1.0
 */

import sk.lomo.elearning.core.ui.Slide;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import java.awt.image.BufferedImage;
import java.awt.Image;
import java.awt.Graphics;
import java.awt.Color;

/** Slide data container for lists and comboboxes. */

public class SlideListItem {

  /** Specifies slide number in lesson. */
  private int number;
  private Icon preview;

  /** Specifies slide name in lesson. */
  private String name;

  /** Creates item with given number and name */
  public SlideListItem(int number, String name) {
    this.number = number;
    this.name = name;
  }

  /** Creates item with given number, slide and generates slide preview icon */
  public SlideListItem(int number, Slide s, Icon bi) {
    this.number = number;
    name = s.getName();
    preview = bi;
  }

  /** @return a value for displaying item in lists */
  public String toString() { return "["+number+"] "+name;  }
  /** @return slide number */
  public int getSlideNum() { return number; }
  /** @return slide name */
  public String getSlideName() { return name; }
  /** @return slide icon (preview) */
  public Icon getIcon() { return preview; }

}


