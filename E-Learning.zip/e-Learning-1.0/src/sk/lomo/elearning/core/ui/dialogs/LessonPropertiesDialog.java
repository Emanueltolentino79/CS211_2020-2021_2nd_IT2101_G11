package sk.lomo.elearning.core.ui.dialogs;

/**
 * <p>Title: LessonPropertiesDialog</p>
 * <p>Description: Dialog to modify or enter new lesson properites</p>
 * <p>Author: Julius Loman</p>
 * @version 1.0
 */

import java.net.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.text.*;
import java.awt.event.*;
import sk.lomo.elearning.core.Lesson;
import javax.swing.border.*;
import java.text.*;
import sk.lomo.elearning.core.ui.*;

/** Dialog to modify or enter new lesson properites. */
public class LessonPropertiesDialog extends JDialog {
  private int MIN_LESSON_HEIGHT = 240;
  private int MAX_LESSON_HEIGHT = 1200;
  private int DEFAULT_LESSON_HEIGHT = 384;
  private int MIN_LESSON_WIDTH = 320;
  private int MAX_LESSON_WIDTH = 1600;
  private int DEFAULT_LESSON_WIDTH = 512;
  private int DEFAULT_STEP_SIZE = 20;

  private int option = JOptionPane.CANCEL_OPTION;
  private String lessonName = "New lesson";
  private String lessonComment = "";

  private JPanel panel1 = new JPanel();
  private JButton jButtonCancel = new JButton();
  private FlowLayout flowLayout1 = new FlowLayout();
  private JButton jButtonOk = new JButton();
  private BorderLayout borderLayout1 = new BorderLayout();

  private NumberFormatter numberFormatter = new NumberFormatter();

  private JSpinner jSpinnerWidth = new JSpinner();
  private JSpinner jSpinnerHeight = new JSpinner();
  private JTextField jTextFieldName = new JTextField();
  private JLabel jLabel3 = new JLabel();
  private JLabel jLabel2 = new JLabel();
  private JLabel jLabel1 = new JLabel();
  private JPanel panelComment = new JPanel();
  private GridBagLayout gridBagLayout = new GridBagLayout();
  private Border border1;
  private JPanel jPanel1 = new JPanel();
  private BorderLayout borderLayout2 = new BorderLayout();
  private Border border2;
  private TitledBorder titledBorder1;
  JCheckBox jCheckBoxNavigationButtons = new JCheckBox();
  JButton jButtonHelp = new JButton();
  JScrollPane jScrollPane1 = new JScrollPane();
  JTextArea jTextAreaComment = new JTextArea();

  private LessonPropertiesDialog(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public LessonPropertiesDialog(Lesson lesson) {
    this(null, "", true);
    JSpinner.NumberEditor editor1 = new JSpinner.NumberEditor(jSpinnerHeight);
    jSpinnerHeight.setEditor(editor1);
    editor1.getFormat().setParseIntegerOnly(true);
    editor1.getFormat().setGroupingUsed(false);
    ((SpinnerNumberModel) jSpinnerHeight.getModel()).setMaximum(new Integer(MAX_LESSON_HEIGHT));
    ((SpinnerNumberModel) jSpinnerHeight.getModel()).setMinimum(new Integer(MIN_LESSON_HEIGHT));
    ((SpinnerNumberModel) jSpinnerHeight.getModel()).setStepSize(new Integer(DEFAULT_STEP_SIZE));
    JSpinner.NumberEditor editor2 = new JSpinner.NumberEditor(jSpinnerWidth);
    jSpinnerWidth.setEditor(editor2);
    editor2.getFormat().setParseIntegerOnly(true);
    editor2.getFormat().setGroupingUsed(false);
    ((SpinnerNumberModel) jSpinnerWidth.getModel()).setMaximum(new Integer(MAX_LESSON_WIDTH));
    ((SpinnerNumberModel) jSpinnerWidth.getModel()).setMinimum(new Integer(MIN_LESSON_WIDTH));
    ((SpinnerNumberModel) jSpinnerWidth.getModel()).setStepSize(new Integer(DEFAULT_STEP_SIZE));
    jCheckBoxNavigationButtons.setSelected(true);

    jSpinnerWidth.setValue(new Integer(DEFAULT_LESSON_WIDTH));
    jSpinnerHeight.setValue(new Integer(DEFAULT_LESSON_HEIGHT));

    if (lesson!=null) {
      lessonName = lesson.getTitle();
      jSpinnerWidth.setValue(new Integer(lesson.getWidth()));
      jSpinnerHeight.setValue(new Integer(lesson.getHeight()));
      lessonComment = lesson.getDescription();
      jCheckBoxNavigationButtons.setSelected(lesson.isEnableNavigation());
    }



    jTextFieldName.setText(lessonName);
    jTextAreaComment.setText(lessonComment);
  }

  private void jbInit() throws Exception {
    DecimalFormat df = new DecimalFormat();
    df.setParseIntegerOnly(true);
    df.setGroupingUsed(false);
    numberFormatter.setFormat(df);


    border1 = BorderFactory.createEmptyBorder();
    border2 = new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(142, 142, 142));
    titledBorder1 = new TitledBorder(border2,"Comment");
    this.setTitle("New lesson");
    panel1.setLayout(gridBagLayout);
    jButtonCancel.setText("Cancel");
    jButtonCancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonCancel_actionPerformed(e);
      }
    });
    flowLayout1.setAlignment(FlowLayout.RIGHT);
    jButtonOk.setText("Ok");
    jButtonOk.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonOk_actionPerformed(e);
      }
    });
    jTextFieldName.setText("New lesson (1)");
    jLabel3.setText("Slide height:");
    jLabel2.setToolTipText("");
    jLabel2.setText("Slide width:");
    jLabel1.setText("Lesson title:");
    borderLayout1.setHgap(5);
    borderLayout1.setVgap(5);
    jPanel1.setLayout(borderLayout2);
    panelComment.setBorder(titledBorder1);
    panel1.setMinimumSize(new Dimension(280, 290));
    panel1.setPreferredSize(new Dimension(280, 290));
    jCheckBoxNavigationButtons.setSelected(true);
    jCheckBoxNavigationButtons.setText("Allow view mode navigation buttons");
    jButtonHelp.setText("Help");
    jButtonHelp.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonHelp_actionPerformed(e);
      }
    });
    jTextAreaComment.setBorder(border1);
    this.getContentPane().add(panel1,  BorderLayout.CENTER);


    panelComment.setLayout(new BorderLayout());
    panelComment.add(jPanel1, null);
    jPanel1.add(jScrollPane1,  BorderLayout.CENTER);
    jScrollPane1.getViewport().add(jTextAreaComment, null);

    panel1.add(jLabel1,   new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 5, 5), 5, 5));

    panel1.add(jLabel2,   new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 5, 5), 5, 5));

    panel1.add(jLabel3,   new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 0, 5), 5, 5));

    panel1.add(jTextFieldName,   new GridBagConstraints(1, 0, 4, 1, 1.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 5, 5), 5, 5));

    panel1.add(jSpinnerWidth,   new GridBagConstraints(1, 1, 4, 1, 1.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 5, 5), 5, 5));

    panel1.add(jSpinnerHeight,     new GridBagConstraints(1, 2, 4, 1, 1.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 5, 5), 5, 5));

    panel1.add(panelComment,   new GridBagConstraints(0, 4, 5, 1, 1.0, 1.0
            ,GridBagConstraints.WEST, GridBagConstraints.BOTH, new Insets(5, 5, 5, 5), 5, 5));



    panel1.add(jButtonOk,            new GridBagConstraints(0, 5, 3, 1, 1.0, 0.0
            ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(5, 5, 5, 0), 0, 0));

    panel1.add(jButtonCancel,     new GridBagConstraints(3, 5, 1, 1, 0.0, 0.0
            ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(5, 5, 5, 5), 0, 0));
    panel1.add(jCheckBoxNavigationButtons,        new GridBagConstraints(0, 3, 5, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 5, 5, 5), 0, 0));
    panel1.add(jButtonHelp,         new GridBagConstraints(0, 5, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 5, 5, 5), 0, 0));

    getRootPane().setDefaultButton(jButtonOk);
  }

  public Lesson getLesson(Lesson lesson) {
    if (option == JOptionPane.OK_OPTION) {
      lesson.setSize(new Dimension(
        ((Integer) jSpinnerWidth.getValue()).intValue(),
        ((Integer) jSpinnerHeight.getValue()).intValue()));
      lesson.setTitle(jTextFieldName.getText());
      lesson.setDescription(jTextAreaComment.getText());
      lesson.setEnableNavigation(jCheckBoxNavigationButtons.isSelected());
    } else return null;
    return lesson;
  }

  void jButtonOk_actionPerformed(ActionEvent e) {
    option = JOptionPane.OK_OPTION;
    setVisible(false);
  }

  void jButtonCancel_actionPerformed(ActionEvent e) {
    option = JOptionPane.CANCEL_OPTION;
    setVisible(false);
  }

  void jButtonHelp_actionPerformed(ActionEvent e) {
    WebBrowser.help("designer#LessonProperties", true);
  }
}
