package sk.lomo.elearning.core.ui.dialogs;

/**
 * <p>Title: TriggerDialogAdd</p>
 * <p>Description: Default dialog for adding a actionable object for ITrigger
 * object.</p>
 * <p>Author: Julius Loman</p>
 * @version 1.0
 */

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import sk.lomo.elearning.core.TriggerAction;
import sk.lomo.elearning.core.ui.*;
import sk.lomo.elearning.core.interfaces.*;
import java.awt.event.*;

/** Default dialog for adding a actionable object for ITrigger
 * object. */

public class TriggerDialogAdd extends JDialog {
  private int option = JOptionPane.CANCEL_OPTION;
  private JPanel panel1 = new JPanel();
  private BorderLayout borderLayout1 = new BorderLayout();
  private Border border1;
  private TitledBorder titledBorder1;
  private JPanel jPanel3 = new JPanel();
  private Border border2;
  private TitledBorder titledBorder2;
  private ButtonGroup buttonGroup1 = new ButtonGroup();
  private VerticalFlowLayout verticalFlowLayout1 = new VerticalFlowLayout();
  private JButton jButtonOk = new JButton();
  private JButton jButtonCancel = new JButton();
  private JPanel jPanel1 = new JPanel();
  private ObjectList jListObject = new ObjectList();
  private JPanel jPanel4 = new JPanel();
  private JRadioButton jRadioButtonHide = new JRadioButton();
  private BorderLayout borderLayout2 = new BorderLayout();
  private JRadioButton jRadioButtonShow = new JRadioButton();
  private GridLayout gridLayout1 = new GridLayout();
  private JRadioButton jRadioButtonTrigger = new JRadioButton();
  private JScrollPane jPanel2 = new JScrollPane();
  private BorderLayout borderLayout3 = new BorderLayout();

  private TriggerDialogAdd(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public TriggerDialogAdd(Slide s) {
    this(null, "Add trigger object", false);
    jListObject.setShowActions(true);
    for (int i=0;i<s.getComponentCount();i++) {
      if (s.getComponent(i) instanceof IObject)
        jListObject.addObject((IObject) s.getComponent(i));
    }
    jListObject.getSelectionModel().addListSelectionListener(new javax.swing.event.ListSelectionListener() {
      public void valueChanged(javax.swing.event.ListSelectionEvent e) {
        buttonGroup1.remove(jRadioButtonHide);
        buttonGroup1.remove(jRadioButtonShow);
        buttonGroup1.remove(jRadioButtonTrigger);
        jRadioButtonHide.setSelected(false);
        jRadioButtonShow.setSelected(false);
        jRadioButtonTrigger.setSelected(false);
        buttonGroup1.add(jRadioButtonHide);
        buttonGroup1.add(jRadioButtonShow);
        buttonGroup1.add(jRadioButtonTrigger);
        if (!e.getValueIsAdjusting()) {
          if (jListObject.getSelectedObject()!=null) {
            IObject o = jListObject.getSelectedObject();
            if (o instanceof IAction) {
              jRadioButtonTrigger.setText("Trigger action " + ((IAction) o).getActionName());
              jRadioButtonTrigger.setEnabled(true);
            } else {
              jRadioButtonTrigger.setText("Trigger");
              jRadioButtonTrigger.setEnabled(false);
            }
            if (o instanceof IVisible) {
              jRadioButtonHide.setEnabled(true);
              jRadioButtonShow.setEnabled(true);
            } else {
              jRadioButtonHide.setEnabled(false);
              jRadioButtonShow.setEnabled(false);
            }
         }
        }
      }

    });

  }

  public TriggerAction getTriggerListAction() {
    int action = TriggerAction.ACTION_NONE;
    if (jRadioButtonHide.isSelected()) action = TriggerAction.ACTION_HIDE;
    else
      if (jRadioButtonShow.isSelected()) action = TriggerAction.ACTION_SHOW;
    else
      if (jRadioButtonTrigger.isSelected()) action = TriggerAction.ACTION_TRIGGER;
    if (option ==JOptionPane.OK_OPTION)  return new TriggerAction((JComponent) jListObject.getSelectedObject(), action);
    else return null;
  }

  private void jbInit() throws Exception {
    border1 = new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(142, 142, 142));
    titledBorder1 = new TitledBorder(border1,"Choose object to trigger");
    border2 = new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(142, 142, 142));
    titledBorder2 = new TitledBorder(border2,"Trigger action");
    panel1.setLayout(borderLayout1);
    jPanel3.setLayout(verticalFlowLayout1);
    jButtonOk.setText("Ok");
    jButtonOk.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonOk_actionPerformed(e);
      }
    });
    jButtonCancel.setText("Cancel");
    jButtonCancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonCancel_actionPerformed(e);
      }
    });
    jPanel4.setLayout(gridLayout1);
    jPanel4.setBorder(titledBorder2);
    jRadioButtonHide.setText("Hide object");
    jRadioButtonShow.setText("Show object");
    gridLayout1.setColumns(1);
    gridLayout1.setRows(0);
    gridLayout1.setVgap(0);
    jRadioButtonTrigger.setText("Trigger");
    jRadioButtonTrigger.setEnabled(false);
    jRadioButtonShow.setEnabled(false);
    jRadioButtonHide.setEnabled(false);
    jPanel2.setBorder(titledBorder1);
    jPanel2.setMinimumSize(new Dimension(268, 156));
    jPanel2.setPreferredSize(new Dimension(268, 156));
    jPanel1.setLayout(borderLayout3);
    getContentPane().add(panel1);
    panel1.add(jPanel3,  BorderLayout.EAST);
    jPanel3.add(jButtonOk, null);
    jPanel3.add(jButtonCancel, null);
    panel1.add(jPanel1,  BorderLayout.CENTER);
    jPanel4.add(jRadioButtonShow, null);
    jPanel4.add(jRadioButtonHide, null);
    jPanel4.add(jRadioButtonTrigger, null);
    jPanel1.add(jPanel2, BorderLayout.CENTER);
    jPanel2.getViewport().add(jListObject);
    jPanel1.add(jPanel4,  BorderLayout.SOUTH);
    buttonGroup1.add(jRadioButtonTrigger);
    buttonGroup1.add(jRadioButtonHide);
    buttonGroup1.add(jRadioButtonShow);
    getRootPane().setDefaultButton(jButtonOk);
  }

  void jButtonOk_actionPerformed(ActionEvent e) {
    option = JOptionPane.OK_OPTION;
    if (jListObject.getSelectedObject()!=null) setVisible(false);
  }

  void jButtonCancel_actionPerformed(ActionEvent e) {
    option = JOptionPane.CANCEL_OPTION;
    setVisible(false);
  }
}
