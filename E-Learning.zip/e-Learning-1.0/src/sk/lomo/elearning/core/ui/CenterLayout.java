package sk.lomo.elearning.core.ui;

/**
 * <p>Title: Center Layout</p>
 * <p>Description: Layout for displaying only one object in his preferred size
 * centered.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.awt.*;
import java.util.*;
import javax.swing.*;

/** Layout for displaying only one object in his preferred size
 * centered. */

public class CenterLayout implements LayoutManager, java.io.Serializable
{
        /** Blank method */
        public void addLayoutComponent(String name, Component comp) {}
        /** Blank method */
        public void removeLayoutComponent(Component comp) {}
        /** Calculates preferred layout size */
        public Dimension preferredLayoutSize(Container parent)
        {
            if (parent.getComponentCount()>0) {
              int w=parent.getComponent(0).getWidth();
              int h=parent.getComponent(0).getHeight();
              return new Dimension(w,h);
            }
            return new Dimension(0,0);
        }

        /** Calculates minimum layout size */
        public Dimension minimumLayoutSize(Container parent)
        {
                return preferredLayoutSize(parent);
        }

        /** Lays out the container */
        public void layoutContainer(Container parent)
        {
          if (parent.getComponentCount()>0) {
            int cw=new Double(parent.getComponent(0).getPreferredSize().getWidth()).intValue();
            int ch=new Double(parent.getComponent(0).getPreferredSize().getHeight()).intValue();
            int w=parent.getWidth();
            int h=parent.getHeight();

            parent.getComponent(0).setBounds((w-cw)/2,(h-ch)/2,cw,ch);
          }
        }

        public String toString()
        {
                return getClass().getName();
        }
}
