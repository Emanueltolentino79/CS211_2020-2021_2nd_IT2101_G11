package sk.lomo.elearning.core.ui.dialogs;

/**
 * <p>Title: Question properties dialog</p>
 * <p>Description: Default dialog for setting hyperlink properties</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import sk.lomo.elearning.core.interfaces.*;
import sk.lomo.elearning.core.ui.*;

/** Default dialog for setting hyperlink properties. */

public class QuestionPropertiesDialog extends JDialog {
  private int option=JOptionPane.CANCEL_OPTION;
  protected int hiScore, loScore;
  protected boolean singleChoice, scorable;

  private JPanel panel1 = new JPanel();
  private JButton jButtonOK = new JButton();
  private Border border1;
  private TitledBorder titledBorder1;
  private JLabel jLabel3 = new JLabel();
  private JLabel jLabel2 = new JLabel();
  private AnswerList answerList;
  private BorderLayout borderLayout2 = new BorderLayout();
  private JCheckBox jCheckBoxScorable = new JCheckBox();
  private JCheckBox jCheckBoxSingleChoice = new JCheckBox();
  private FlowLayout flowLayout1 = new FlowLayout();
  private GridBagLayout gridBagLayout1 = new GridBagLayout();
  private GridBagLayout gridBagLayout2 = new GridBagLayout();
  JSpinner jSpinnerHigh = new JSpinner();
  JSpinner jSpinnerLow = new JSpinner();
  JPanel jPanel1 = new JPanel();
  JButton jButtonCancel = new JButton();
  JButton jButtonHelp = new JButton();
  JScrollPane jScrollPane1 = new JScrollPane();
  GridBagLayout gridBagLayout3 = new GridBagLayout();

  private QuestionPropertiesDialog(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
  }

  public QuestionPropertiesDialog(IQuestion question) {
    this(null, "Question properties", true);
    answerList = new AnswerList(question);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }

    loScore = question.getLoScore();
    hiScore = question.getHiScore();
    scorable = question.isScorable();
    singleChoice = question.isSingleChoice();
    jCheckBoxScorable.setSelected(question.isScorable());
    jCheckBoxSingleChoice.setSelected(question.isSingleChoice());
    jSpinnerHigh.setValue(new Integer(hiScore));
    jSpinnerLow.setValue(new Integer(loScore));
    getRootPane().setDefaultButton(jButtonOK);
  }
  private void jbInit() throws Exception {
    jButtonOK.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonOK_actionPerformed(e);
      }
    });
    border1 = BorderFactory.createLineBorder(Color.black,1);
    titledBorder1 = new TitledBorder(new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(142, 142, 142)),"Answers (height)");
    panel1.setLayout(gridBagLayout1);
    jButtonOK.setText("OK");
    jLabel3.setText("Lowest score:");
    jLabel2.setToolTipText("");
    jLabel2.setText("Highest score:");
    jScrollPane1.setBorder(titledBorder1);
    jScrollPane1.setMinimumSize(new Dimension(290, 200));
    jScrollPane1.setPreferredSize(new Dimension(290, 200));
    panel1.setMinimumSize(new Dimension(300, 300));
    panel1.setPreferredSize(new Dimension(300, 300));
    jCheckBoxScorable.setSelected(true);
    jCheckBoxScorable.addChangeListener(new javax.swing.event.ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        jCheckBoxScorable_stateChanged(e);
      }
    });
    jCheckBoxScorable.setText("Score this question");
    jCheckBoxSingleChoice.setText("Single choice question");
    flowLayout1.setAlignment(FlowLayout.RIGHT);


//    jPanel2.add(jPanel3, BorderLayout.CENTER);
//    jPanel3.add(answerList, BorderLayout.CENTER);
//    jPanel2.add(jPanel5, BorderLayout.SOUTH);
//    jPanel4.add(jLabel2, null);
//    jPanel4.add(jLabel3, null);
//    jPanel2.add(jPanel6, BorderLayout.NORTH);
//    jPanel6.add(jCheckBoxScorable, BorderLayout.CENTER);
//    jPanel6.add(jCheckBoxSingleChoice, BorderLayout.SOUTH);
//    jPanel5.add(jPanelHeight, BorderLayout.CENTER);
//    jPanel5.add(jPanel4, BorderLayout.WEST);
//    jPanelHeight.add(jTextFieldHighest, null);
//    jPanelHeight.add(jTextFieldLowest, null);
//    jPanel1.add(jButtonOK, null);
//    jPanel1.add(jButton1, null);
    jSpinnerHigh.setMinimumSize(new Dimension(64, 24));
    jSpinnerHigh.setPreferredSize(new Dimension(64, 24));
    jSpinnerLow.setPreferredSize(new Dimension(64, 24));
    jSpinnerLow.setMinimumSize(new Dimension(64, 24));
    jButtonCancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonCancel_actionPerformed(e);
      }
    });
    jButtonCancel.setText("Cancel");
    jPanel1.setLayout(gridBagLayout3);
    jButtonHelp.setText("Help");
    jButtonHelp.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonHelp_actionPerformed(e);
      }
    });
    getContentPane().add(panel1);
//
    panel1.add(jCheckBoxScorable,                new GridBagConstraints(0, 0, 5, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 5, 0, 5), 0, 0));
    panel1.add(jCheckBoxSingleChoice,                new GridBagConstraints(0, 1, 5, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 5, 0, 5), 0, 0));
    panel1.add(jScrollPane1,               new GridBagConstraints(0, 2, 5, 1, 1.0, 1.0
            ,GridBagConstraints.WEST, GridBagConstraints.BOTH, new Insets(5, 5, 5, 5), 0, 0));
    jScrollPane1.getViewport().add(answerList);
    panel1.add(jLabel2,                new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.BOTH, new Insets(5, 5, 5, 5), 0, 0));



    panel1.add(jSpinnerHigh,          new GridBagConstraints(1, 3, 1, 1, 0.5, 0.0
            ,GridBagConstraints.NORTHWEST, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 5, 0), 0, 0));
    panel1.add(jLabel3,            new GridBagConstraints(2, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(5, 10, 5, 5), 0, 0));
    panel1.add(jSpinnerLow,      new GridBagConstraints(3, 3, 1, 1, 0.5, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 5, 5), 0, 0));
    this.getContentPane().add(jPanel1, BorderLayout.SOUTH);
    jPanel1.add(jButtonOK,    new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(5, 5, 5, 0), 0, 0));
    jPanel1.add(jButtonCancel,    new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(5, 5, 5, 0), 0, 0));
    jPanel1.add(jButtonHelp,     new GridBagConstraints(0, 0, 1, 1, 1.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 5, 5, 5), 0, 0));


//    panel1.add(jPanel1,  new GridBagConstraints(0, 1, 1, 1, 1.0, 1.0
//            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 270, 0));
//      this.getContentPane().setLayout(gridBagLayout2);
//    panel1.add(jCheckBoxScorable);
    getRootPane().setDefaultButton(jButtonOK);
  }

  void jButtonCancel_actionPerformed(ActionEvent e) {
    option = JOptionPane.CANCEL_OPTION;
    setVisible(false);
  }

  void jButtonOK_actionPerformed(ActionEvent e) {
    option = JOptionPane.OK_OPTION;
    setVisible(false);
  }

  void jCheckBoxScorable_stateChanged(ChangeEvent e) {
    if (jCheckBoxScorable.isSelected()) {
      jSpinnerHigh.setEnabled(true);
      jSpinnerLow.setEnabled(true);
      answerList.setEnabled(true);
    } else {
      jSpinnerHigh.setEnabled(false);
      jSpinnerLow.setEnabled(false);
      answerList.setEnabled(false);
    }
  }

  public int getLoScore() {
    if (option == JOptionPane.OK_OPTION ) return ((Integer) (jSpinnerLow.getValue())).intValue();
    return loScore;
  }

  public int getHiScore() {
    if (option == JOptionPane.OK_OPTION ) return ((Integer) (jSpinnerHigh.getValue())).intValue();
    return hiScore;
  }

  public boolean isSingleChoice() {
    if (option == JOptionPane.OK_OPTION ) return jCheckBoxSingleChoice.isSelected();
    return singleChoice;
  }

  public boolean isScorable() {
    if (option == JOptionPane.OK_OPTION ) return jCheckBoxScorable.isSelected();
    return scorable;
  }

  void jButtonHelp_actionPerformed(ActionEvent e) {
    WebBrowser.help("designer#QuestionProperties", true);
  }


}
