package sk.lomo.elearning.core.ui;

/**
 * <p>Title: ObjectTools</p>
 * <p>Description: Helper class encapsulating common object methods.</p>
 * <p>Author: Julius Loman</p>
 * @author not attributable
 * @version 1.0
 */
import java.awt.*;
import javax.swing.border.*;
import javax.swing.*;

import sk.lomo.elearning.core.*;

/** Helper class encapsulating common object methods. */
public class ObjectUtils implements java.io.Serializable {
  /** designMode - if object is in design mode
   * selected - if object is selected */
  private boolean designMode, selected;
  /** object icon */
  private Icon icon;
  /** border used for resizing and object selection */
  protected ResizeBorder resizeBorder = new ResizeBorder();
  /** default cursor above object */
  private Cursor defaultCursor = Cursor.getDefaultCursor();
  /** pointer to object this helper is created in */
  private JComponent object;

  /** Creates given helper on given object
   * @param o component to create helper on*/
  public ObjectUtils(JComponent o) {
    object = o;
    String cname = o.getClass().getName();
    icon = Library.getGraphics(cname.substring(cname.lastIndexOf(".")+1)+".gif");
  }
  /** Creates given helper on given object
  * @param o component to create helper on
  * @param i object icon */
  public ObjectUtils(JComponent o, Icon i) {
    object = o;
    icon = i;
  }
  /** @return object icon on object library and menus */
  public Icon getRepositoryIcon() { return icon; }
  /** @return object border used for resizing and object selection */
  public ResizeBorder getResizeBorder() { return resizeBorder; }
  /** @return default object cursor */
  public Cursor getObjectCursor() { return Cursor.getDefaultCursor(); }
  /** Selects object.
   * @param selected true if object should be selected */
  public void setSelected(boolean selected) {
    if (this.selected!=selected) {
      this.selected=selected;
      object.repaint();
    }
  }
  /** @return true if object is selected */
  public boolean isSelected() {
      return selected;
  };
  /** @param designMode true to set object to design mode */
  public void setDesignMode(boolean designMode) {
    if (this.designMode!=designMode) {
      this.designMode=designMode;
      if (designMode) object.setCursor(getObjectCursor());
        else object.setCursor(Cursor.getDefaultCursor());
      object.repaint();
    }
  }
  /** @return true if object is in design mode */
  public boolean isDesignMode() {
      return designMode;
  };
}
