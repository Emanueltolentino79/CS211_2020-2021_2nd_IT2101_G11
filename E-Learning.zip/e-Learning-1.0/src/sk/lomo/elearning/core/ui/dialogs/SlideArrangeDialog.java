package sk.lomo.elearning.core.ui.dialogs;

/**
 * <p>Title: SlideArrangeDialog</p>
 * <p>Description: Dialog used for arranging slides and removing them</p>
 * <p>Author: Julius Loman</p>
 * @version 1.0
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.undo.*;

import sk.lomo.elearning.*;
import sk.lomo.elearning.core.*;
import sk.lomo.elearning.core.commands.*;
import sk.lomo.elearning.core.ui.*;

/** Dialog used for arranging slides and removing them. */

public class SlideArrangeDialog extends JDialog {
  private int option = JOptionPane.CANCEL_OPTION;
  private Icon iconMoveUp = Utils.getGraphics("MenuMoveUp.gif");
  private Icon iconMoveDown = Utils.getGraphics("MenuMoveDown.gif");
  private Icon iconCut = Utils.getGraphics("MenuEditCut.gif");
  private Icon iconCopy = Utils.getGraphics("MenuEditCopy.gif");
  private Icon iconPaste = Utils.getGraphics("MenuEditPaste.gif");
  private Icon iconRemove = Utils.getGraphics("MenuSlideRemoveSlide.gif");
  private Icon iconUndo = Utils.getGraphics("MenuEditUndo.gif");
  private Icon iconRedo = Utils.getGraphics("MenuEditRedo.gif");

  private JPanel panel1 = new JPanel();
  private SlideList jListSlides;
  private JScrollPane jListPane = new JScrollPane();
  private JButton jButtonRemove = new JButton();
  private JButton jButtonMoveDown = new JButton();
  private JButton jButtonMoveUp = new JButton();
  private Border border1;
  private TitledBorder titledBorder1;
  private GridBagLayout gridBagLayout1 = new GridBagLayout();
  private JButton jButtonOk = new JButton();
  JButton jButtonUndo = new JButton();
  JButton jButtonRedo = new JButton();
  JButton jButtonDuplicate = new JButton();
  JButton jButtonHelp = new JButton();

  public SlideArrangeDialog(Frame frame, String title, boolean modal, Lesson l) {
    super(frame, title, modal);
    jListSlides = new SlideList(l);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
    jListSlides.refresh();
  }

  private void jbInit() throws Exception {
    border1 = new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(142, 142, 142));
    jButtonMoveUp.setIcon(iconMoveUp);
    jButtonMoveDown.setIcon(iconMoveDown);
    titledBorder1 = new TitledBorder(border1,"Slides");
    jListPane.setBorder(titledBorder1);
    jButtonRemove.setText("Remove");
    jButtonRemove.setIcon(iconRemove);
    jButtonRemove.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        actionDelete(e);
      }
    });
    jButtonMoveDown.setText("Down");
    jButtonMoveDown.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        actionMoveDown(e);
      }
    });
    jButtonMoveUp.setMargin(new Insets(2, 14, 2, 14));
    jButtonMoveUp.setText("Up");
    jButtonMoveUp.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        actionMoveUp(e);
      }
    });
    panel1.setLayout(gridBagLayout1);
    jButtonOk.setText("OK");
    jButtonOk.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonClose_actionPerformed(e);
      }
    });
    jButtonUndo.setText("");
    jButtonUndo.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonUndo_actionPerformed(e);
      }
    });
    jButtonRedo.setText("");
    jButtonRedo.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonRedo_actionPerformed(e);
      }
    });
    jButtonUndo.setToolTipText("Undo");
    jButtonUndo.setIcon(iconUndo);
    jButtonRedo.setToolTipText("Redo");
    jButtonRedo.setIcon(iconRedo);
    panel1.setMinimumSize(new Dimension(400, 400));
    panel1.setPreferredSize(new Dimension(400, 400));
    jButtonDuplicate.setIcon(iconCopy);
    jButtonDuplicate.setSelectedIcon(null);
    jButtonDuplicate.setText("Duplicate");
    jButtonDuplicate.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        actionDuplicate(e);
      }
    });
    jButtonHelp.setToolTipText("");
    jButtonHelp.setText("Help");
    jButtonHelp.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonHelp_actionPerformed(e);
      }
    });
    getContentPane().add(panel1);
    jListPane.getViewport().add(jListSlides);
    panel1.add(jListPane,                                              new GridBagConstraints(0, 0, 1, 8, 1.0, 1.0
            ,GridBagConstraints.NORTHWEST, GridBagConstraints.BOTH, new Insets(5, 5, 5, 5), 0, 0));
    panel1.add(jButtonMoveUp,                          new GridBagConstraints(1, 0, 2, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 5, 5), 0, 0));
    panel1.add(jButtonMoveDown,                        new GridBagConstraints(1, 1, 2, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 5, 5), 0, 0));
    panel1.add(jButtonRemove,                        new GridBagConstraints(1, 4, 2, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 5, 5), 0, 0));
    panel1.add(jButtonOk,                      new GridBagConstraints(1, 7, 2, 1, 0.0, 0.0
            ,GridBagConstraints.SOUTH, GridBagConstraints.HORIZONTAL, new Insets(0, 5, 5, 5), 0, 0));
    panel1.add(jButtonUndo,                 new GridBagConstraints(1, 5, 1, 1, 0.0, 0.1
            ,GridBagConstraints.NORTH, GridBagConstraints.NONE, new Insets(5, 5, 0, 5), 0, 0));
    panel1.add(jButtonRedo,                    new GridBagConstraints(2, 5, 1, 3, 0.0, 0.1
            ,GridBagConstraints.NORTH, GridBagConstraints.NONE, new Insets(5, 5, 5, 5), 0, 0));
    panel1.add(jButtonDuplicate,             new GridBagConstraints(1, 3, 2, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 5, 5), 0, 0));
    panel1.add(jButtonHelp,    new GridBagConstraints(1, 6, 2, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(5, 5, 5, 5), 0, 0));
    getRootPane().setDefaultButton(jButtonOk);
  }

  void jButtonClose_actionPerformed(ActionEvent e) {
    option = JOptionPane.CLOSED_OPTION;
    setVisible(false);
  }

  void actionMoveUp(ActionEvent e) {
    SlideListItem sc = (SlideListItem) jListSlides.getSelectedValue();
    int scindex = jListSlides.getSelectedIndex();
    if (sc!=null)
    if (sc.getSlideNum()>0) {
      MoveSlideCommand msc = new MoveSlideCommand(jListSlides.getLesson(),sc.getSlideNum(),sc.getSlideNum()-1);
      jListSlides.getLesson().commandManager.addEdit(msc);
      msc.redo();
      jListSlides.refresh();
      jListSlides.setSelectedIndex(scindex-1);
    }
  }

  void actionMoveDown(ActionEvent e) {
    SlideListItem sc = (SlideListItem) jListSlides.getSelectedValue();
    int scindex = jListSlides.getSelectedIndex();
    if (sc!=null)
    if (sc.getSlideNum()<jListSlides.getLesson().getSlidesCount()-1) {
      MoveSlideCommand msc = new MoveSlideCommand(jListSlides.getLesson(),sc.getSlideNum(),sc.getSlideNum()+1);
      jListSlides.getLesson().commandManager.addEdit(msc);
      msc.redo();
      jListSlides.refresh();
      jListSlides.setSelectedIndex(scindex+1);
    }
  }

  void actionDelete(ActionEvent e) {
    SlideListItem sc = (SlideListItem) jListSlides.getSelectedValue();
    if (sc==null) return;
    RemoveSlideCommand dsc = new RemoveSlideCommand(jListSlides.getLesson(), jListSlides.getLesson().getSlide(sc.getSlideNum()));
    jListSlides.getLesson().commandManager.addEdit(dsc);
    dsc.redo();
    jListSlides.refresh();
  }

  void jButtonUndo_actionPerformed(ActionEvent e) {
    try {
      jListSlides.getLesson().commandManager.undo();
    } catch (CannotRedoException ex) {};
    jListSlides.refresh();
  }

  void jButtonRedo_actionPerformed(ActionEvent e) {
    try {
    jListSlides.getLesson().commandManager.redo();
    } catch (CannotRedoException ex) {};
    jListSlides.refresh();
  }

  void actionDuplicate(ActionEvent e) {
    SlideListItem sc = (SlideListItem) jListSlides.getSelectedValue();
    if (sc==null) return;
    SlideDuplicateCommand cscc = new SlideDuplicateCommand(jListSlides.getLesson(),
        jListSlides.getLesson().getSlide(sc.getSlideNum()));
    cscc.redo();
    jListSlides.getLesson().commandManager.addEdit(cscc);
    jListSlides.refresh();
  }

  void jButtonHelp_actionPerformed(ActionEvent e) {
    WebBrowser.help("designer#ArrangeSlides", true);
  }

}
