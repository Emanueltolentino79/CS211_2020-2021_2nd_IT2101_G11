package sk.lomo.elearning.core;

/**
 * <p>Title: TriggerManager</p>
 * <p>Description: Class for handling trigger actions</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.text.*;
import java.beans.*;
import sk.lomo.elearning.core.interfaces.*;

/** Class for handling trigger actions. */

public class TriggerManager implements java.io.Serializable {
  private Vector list = new Vector();
  /** trigger parameters */
  private boolean triggerOnSlideEnter= true;

  /** @return TriggerAction on given position
   * @param i position */
  public TriggerAction getAction(int i) {
    return (TriggerAction) list.get(i);
  }
  /** removes TriggerActions on non-existent object */
  public void removeUnparentedObjectActions() {
    Vector list2 = new Vector();
    int j=0;
    Iterator i = list.iterator();
    while (i.hasNext()) {
      TriggerAction ta;
      ta = (TriggerAction) i.next();
      if (ta.getActionObject().getParent()!=null) {
        list2.add(ta);
      }
    }
    list = list2;
  }
  /** @return all trigger actions */
  public TriggerAction[] getTriggerActions() {
    int j=0;
    TriggerAction[] res = new TriggerAction[list.size()];
    Iterator i = list.iterator();
    while (i.hasNext())
        res[j++] = (TriggerAction) i.next();
    return res;
  }
  /** @return number of actions */
  public int getActionCount() {
    return list.size();
  }
  /** Inserts TriggerAction into list
   * @param action action to insert */
  public void putAction(TriggerAction action) {
    list.add(action);
  }
  /** Removes all trigger actions */
  public void removeAllActions() {
    list.removeAllElements();
  }
  /** Fires all actions */
  public void doActions() {
    Iterator i = list.iterator();
    while (i.hasNext()) {
      TriggerAction a = (TriggerAction) i.next();
      a.doAction();
    }
  }
  /** Sets trigger actions
   * @param ta trigger actions to set */
  public void setAllActions(TriggerAction[] ta) {
    removeAllActions();
    for(int i=0; i<ta.length; i++)
      putAction(ta[i]);
  }
  /** Removes all TriggerActions with given action object
   * @param object object to remove TriggerActions of */
  public void removeActionObject(JComponent object) {
    int size=list.size();
    for (int i=0; i<size; i++) {
      TriggerAction a = (TriggerAction) list.get(i);
      if (a.getActionObject()==object) {
        list.remove(a);
        i--;
        size--;
      }
    }
  }

    /** @return true if trigger should be fired after entering slide */
    public boolean isTriggerOnSlideEnter() {
      return triggerOnSlideEnter;
    }

    /** @param trigger true if trigger should be fired after entering slide */
    public void setTriggerOnSlideEnter(boolean trigger) {
      triggerOnSlideEnter = trigger;
    }

    /** @return true if trigger has this action object */
    public boolean hasActionObject(javax.swing.JComponent object) {
      int c=0;
      Iterator i = list.iterator();
      while (i.hasNext())
        if (((TriggerAction) i.next()).getActionObject()==object) c++;
      return c>0;
    }
    /** @return trigger actions for object
     * @param object action object */
    public TriggerAction[] getTriggerActions(javax.swing.JComponent object) {
      int c=0;
      Iterator i = list.iterator();
      while (i.hasNext())
        if (((TriggerAction) i.next()).getActionObject()==object) c++;
      TriggerAction[] res = new TriggerAction[c];
      c=0;
      i = list.iterator();
      while (i.hasNext()) {
        TriggerAction ta = (TriggerAction) i.next();
        if (ta.getActionObject() == object)
          res[c++] = ta;
      }
      return res;
    }
}

