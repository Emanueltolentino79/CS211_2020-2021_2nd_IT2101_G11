package sk.lomo.elearning.core;

/**
 * <p>Title: FileObjectClassLoader</p>
 * <p>Description: Loads classes from specified directory.</p>
 * <p>Author: Julius Loman</p>
 * @version 1.0
 */
import java.io.*;

/** Class loader for objects in class files in given directory. */
class FileObjectClassLoader extends ClassLoader {
  /** directory to look in */
  private String directory;
  /** Create loader
   * @param directory directory to load class files from */
  public FileObjectClassLoader(String directory) {
    this.directory = directory;
  }

  /** Load class code and define class from bytecode
   * @param name class name
   * @return Loaded Class */
  public Class findClass(String name) {
    byte[] b = loadClassCode(name);
    if (b != null) {
      return defineClass(name, b, 0, b.length);
    } else {
      return null;
    }
  }

  /** Load class code from file
   * @param fullClassName given full class name
   * @return bytecode for this class */
  public byte[] loadClassCode(String fullClassName) {
    byte[] data;
    try {
      String className = fullClassName.substring(fullClassName.lastIndexOf(".") +
          1);
      File f = new File(directory + className + ".class");
      FileInputStream fis = new FileInputStream(f);
      data = new byte[ (int) f.length()];
      fis.read(data);
      return data;
    } catch (IOException ex) {
    }
    ;
    return null;
  }
}
