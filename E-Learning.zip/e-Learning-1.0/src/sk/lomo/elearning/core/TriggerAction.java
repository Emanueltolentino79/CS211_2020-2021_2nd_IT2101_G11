package sk.lomo.elearning.core;

/**
 * <p>Title: TriggerAction</p>
 * <p>Description: Object encapsulates a trigger action.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.text.*;
import java.beans.*;
import sk.lomo.elearning.core.interfaces.*;

/** Object encapsulates a trigger action. */

public class TriggerAction  implements java.io.Serializable {
  /** defines no action */
  public static final int ACTION_NONE=0;
  /** defines action to show object */
  public static final int ACTION_SHOW=1;
  /** defines action to hide object */
  public static final int ACTION_HIDE=2;
  /** defines action to trigger objects */
  public static final int ACTION_TRIGGER=4;
  /** action that is about to be taken */
  private int action;
  /** object that is action defined on */
  private JComponent object;
  /** Creates action
   * @param actionObject object that is action defined on
   * @param action action to take
   */

  public TriggerAction(JComponent actionObject, int action) {
    this.action = action;
    this.object = actionObject;
  }
  /** @return object that is action defined on */
  public JComponent getActionObject() { return object; }
  /** @return action to take */
  public int getAction() { return action; }
  /** does desired action */
  public void doAction() {
    switch (action) {
      case ACTION_SHOW:
        object.setVisible(true);
        break;
      case ACTION_HIDE:
        object.setVisible(false);
        break;
      case ACTION_TRIGGER:
        if (object instanceof IAction) {
          ((IAction) object).action();
        }
        break;
      default:
    }
  }
  /** @return presentation name for this action */
  public String getPresentationName() {
    String on = ((IObject) object).getDisplayName();
    String act = "";
    if (object.getName()!=null)
      on = on + " ["+object.getName()+"]";
    switch (action) {
      case ACTION_SHOW:
        return "Show object "+on;
      case ACTION_HIDE:
        return "Hide object "+on;
      case ACTION_TRIGGER:
        if (object instanceof IAction) {
          act = ((IAction) object).getActionName();
        }
        return "Trigger action '"+act+"' on object "+on;
    }
    return null;
  }
}

