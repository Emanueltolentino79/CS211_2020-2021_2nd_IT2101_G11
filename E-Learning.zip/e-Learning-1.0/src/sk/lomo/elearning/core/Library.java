package sk.lomo.elearning.core;

/**
 * <p>Title: Library</p>
 * <p>Description: Class dealing with object storage and creation. Design
 * patterns Singleton and Factory are used.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.awt.event.*;
import java.io.*;
import java.util.zip.*;
import java.util.*;
import javax.swing.event.*;

import javax.swing.*;

import sk.lomo.elearning.*;
import sk.lomo.elearning.core.interfaces.*;

/** Filename filter for class files */
class ClassFilenameFilter implements FilenameFilter {
  public boolean accept(File dir, String name) {
    if (name.toLowerCase().endsWith(".class")) {
      return true;
    }
    return false;
  }
}


/** Class dealing with object storage and creation. */
public class Library {
  /** singleton object instance */
  private static Library library_instance = null;
  /** Library change notifiers */
  private transient EventListenerList libraryChanged = new EventListenerList();
  /** Map categories to vectors of objects*/
  public HashMap objectsByCategories = new HashMap();
  /** Map repository object names to objects */
  public HashMap objectsByNames = new HashMap();
  /** Map object names to objects */
  private HashMap objects = new HashMap();
  /** Map object names to icons */
  private HashMap objectIcons = new HashMap();
  /** Map class name to object name */
  private HashMap objectNames = new HashMap();
  /** Map object names to runtime serialized objects */
  public HashMap objectsRuntime = new HashMap();
  /** Map objects names to runtime object's icons */
  private HashMap objectsRuntimeIcons = new HashMap();
  /** Directory to store object class files */
  public static String directory = "./classes/";

  /** Construct and initialize library */
  public Library() {
    clearObjects();
  }

  /** Add library change listener
   * @param a ChangeListener to add */
  public void addChangeListener(ChangeListener a) {
    libraryChanged.add(ChangeListener.class, a);
  }

  /** Remove library change listener
   * @param a ChangeListener to remove */
  public void removeChangeListener(ChangeListener a) {
    libraryChanged.remove(ChangeListener.class, a);
  }

  /** Fire library change
   * @param e ChangeEvent to send to listeners */
  protected void fireChange(ChangeEvent e) {
    Utils.sprintln("Library changed");
    EventListener[] l = libraryChanged.getListeners(ChangeListener.class);
    for (int i = 0; i < l.length; i++) {
      ( (ChangeListener) l[i]).stateChanged(e);
    }
  }

  /** @return singleton instance */
  public static Library getLibrary() {
    if (library_instance == null) {
      library_instance = new Library();
    }
    return library_instance;
  }

  /** @return directory where class files are stored */
  public String getDirectory() {
    return directory;
  }

  /** Clears run time (serialized) objects */
  public void clearRuntimeObjects() {
    objectsRuntime.clear();
  }

  /** Create a new runtime object form given instance
   * @param object object instance to create from
   * @param icon icon representing this object
   * @param name object runtime name in library
   */
  public void addRuntimeObject(IObject object, Icon icon, String name) {
    byte[] objectData;

    String name1 = name;
    int c = 1;
    while (objectsRuntime.containsKey(name1)) {
      name1 = name + " " + c++;
    }
    name = name1;
    try {
      ByteArrayOutputStream baos = new ByteArrayOutputStream();
      ObjectOutputStream oos = new ObjectOutputStream(baos);

      oos.writeObject(object);
      oos.close();

      objectData = baos.toByteArray();
      objectsRuntime.put(name, objectData);
      objectsRuntimeIcons.put(name, icon);

      fireChange(new ChangeEvent(object));
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  /** Load objects from class files to library */
  public void loadFileObjects() {
    Utils.sprintln("Starting object loading");
    FileObjectClassLoader fileClassLoader = new FileObjectClassLoader(directory);
    File Browser = new File(directory);
    String[] list;
    list = Browser.list(new ClassFilenameFilter());
    Utils.sprintln("Got list of found classes");
    if (list != null) {
      for (int i = 0; i < list.length; i++) {
        String className = list[i].substring(0,
            list[i].lastIndexOf(".class"));
        Utils.sprintln("Checking object - " + className);
        try {
          Class testClass = Class.forName(className, true, fileClassLoader);

          Object o = null;

          try {
            o = testClass.newInstance();
          } catch (IllegalAccessException e1) {
            Utils.sprintln("class (" + className +
                ") cannot be instantiated, skipping");
          } catch (InstantiationException e2) {
            Utils.sprintln("class (" + className +
                ") cannot be instantiated, skipping");
          }
          ;

          if ( (o instanceof IObject) && (o instanceof JComponent)) {
            if ( ( (IObject) o).isLibraryObject()) {
              objects.put(o.getClass().getName(), testClass);
              objectIcons.put(o.getClass(), ( (IObject) o).getRepositoryIcon());
              objectNames.put(o.getClass(), ( (IObject) o).getDisplayName());

              objectsByNames.put( ( (IObject) o).getDisplayName(), testClass);
              String category = ( (IObject) o).getDisplayCategory();

              Utils.sprintln("Object category - " + category);
              Utils.sprintln("Object display name - " +
                  ( (IObject) o).getDisplayName());

              if (objectsByCategories.containsKey(category)) {
                ( (Vector) objectsByCategories.get(category)).add(testClass);
              } else {
                Vector v = new Vector();
                v.add(testClass);
                objectsByCategories.put(category, v);
              }
            }
          }
        } catch (ClassNotFoundException e) {
          Utils.sprintln("Class file found, but class not (" +
              className + ")");
        }
      }
    }
    fireChange(new ChangeEvent(this));
  }

  /** Clear all library objects */
  public void clearObjects() {
    objects.clear();
    objectsByNames.clear();
    objectsByCategories.clear();
    objectsByCategories.put("Basic", new Vector());
  }

  /** Create new object from library
   * @param classname class name of object to create
   * @return created instance */
  public JComponent createInstance(String classname) {
    if (objects.containsKey(classname)) {
      try {
        return (JComponent) ( (Class) objects.get(classname)).newInstance();
      } catch (IllegalAccessException e1) {
        Utils.sprintln(e1.toString());
      } catch (InstantiationException e2) {
        Utils.sprintln(e2.toString());
      }
      ;
    }
    return null;
  }

  /** Create new object from library
   * @param name repository name of object to create
   * @return created instance */
  public JComponent createRunTimeInstance(String name) {
    if (objectsRuntime.containsKey(name)) {
      try {
        ObjectInputStream ois = new LObjectInputStream(new
            ByteArrayInputStream( (byte[]) objectsRuntime.get(name)));
        Object o = ois.readObject();
        if (o instanceof JComponent) {
          return (JComponent) o;
        }
      } catch (IOException e1) {
        e1.printStackTrace();
      } catch (ClassNotFoundException e2) {
        e2.printStackTrace();
      }
      ;
    }
    return null;
  }

  /** @return object icon for given class
   * @param c class get icon from */
  public Icon getDisplayIcon(Class c) {
    try {
      return (Icon) objectIcons.get(c);
    } catch (Exception e) {
    }
    return null;
  }

  /** @return object icon for given object name
   * @param s name get icon from */
  public Icon getRuntimeDisplayIcon(String s) {
    try {
      return (Icon) objectsRuntimeIcons.get(s);
    } catch (Exception e) {
    }
    return null;
  }

  /** @return display category for object
   * @param c class object get information about */
  public String getDisplayCategory(Class c) {
    try {
      Object o = c.newInstance();
      return ( (IObject) o).getDisplayCategory();
    } catch (Exception e) {
    }
    return null;
  }

  /** @return repository display name for object
   * @param c class object get information about */
  public String getDisplayName(Class c) {
    try {
      return (String) objectNames.get(c);
    } catch (Exception e) {
    }
    return null;
  }

  /** Loads an Icon with given name
   * @param name icon name to load
   * @return graphics Icon to return */
  public static Icon getGraphics(String name) {
    try {
      Utils.sprintln("Loading icon: " + directory + name);
      return new ImageIcon(directory + name);
    } catch (Exception e) {
      e.printStackTrace();
      return null;
    }
  }

  /** Creates runtime viewer jar file
   * @param sourceJar jar from which to create
   * @param outputJar jar file name to create
   */
  public void createViewerJar(String sourceJar, String outputJar) {
    try {
      ZipFile zf = new ZipFile(sourceJar);

      FileOutputStream f = new FileOutputStream(outputJar);
      CheckedOutputStream csum =
          new CheckedOutputStream(
          f, new Adler32());
      ZipOutputStream out =
          new ZipOutputStream(
          new BufferedOutputStream(csum));
      out.setComment("e-Learning viewer");

      // copy each file from source jar
      Enumeration en = zf.entries();
      while (en.hasMoreElements()) {
        ZipEntry ze = (ZipEntry) en.nextElement();
        ZipEntry nze = new ZipEntry(ze.getName());
        out.putNextEntry(nze);

        byte[] data = new byte[1024];
        int read;
        // copy file into new jar
        InputStream is = zf.getInputStream(ze);
        read = is.read(data);
        while (read > 0) {
          out.write(data, 0, read);
          read = is.read(data);
        }
      }

      // copy each file from directory classDir
      File Browser = new File(directory);
      String[] list;
      list = Browser.list();
      if (list != null) {
        for (int i = 0; i < list.length; i++) {
          File af = new File(directory + list[i]);
          String newEntry = af.getName().replace(af.separatorChar, '/');
          // add only if entry with same name does not exist
          if ( (zf.getEntry(newEntry) == null) && (!af.isDirectory())) {
            ZipEntry nze = new ZipEntry(newEntry);
            out.putNextEntry(nze);
            FileInputStream fis = new FileInputStream(af);
            byte[] data = new byte[ (int) af.length()];
            int read = fis.read(data);
            while (read > 0) {
              out.write(data, 0, read);
              read = fis.read(data);
            }
          }
        }
      }
      out.close();
    } catch (IOException ex) {
      ex.printStackTrace();
    }
  }
}
