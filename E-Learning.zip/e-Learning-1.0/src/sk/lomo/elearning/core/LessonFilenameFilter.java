package sk.lomo.elearning.core;

/**
 * <p>Title: LessonFilenameFilter</p>
 * <p>Description: Filename filter for lesson files</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */
import java.io.*;

import javax.swing.filechooser.FileFilter;

/** Filename filter for lesson files. */
public class LessonFilenameFilter extends FileFilter implements FilenameFilter {
   public boolean accept(File path, String fileName) {
     if (fileName.toLowerCase().endsWith(".lesson")) return true;
     return false;
   }

   public boolean accept(File pathname) {
     if (pathname.isDirectory()) return true;
     if (pathname.getName().toLowerCase().endsWith(".lesson")) return true;
     return false;
   }

   public String getDescription() {
     return "Lesson files";
   }
 }
