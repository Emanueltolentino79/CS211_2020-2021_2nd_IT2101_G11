package sk.lomo.elearning;

/**
 * <p>Title: Utilities</p>
 * <p>Description: Utilities for string output and graphics loading</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.io.*;
import java.net.*;
import javax.swing.*;
import java.awt.*;
import java.awt.image.*;

/** Utilities for string output and graphics loading. */

public class Utils {
  /** Turns on debugging information */
  public static boolean debug = true;
  /** Outputs a debug string
   * @param s string to output */
  public static void sprintln(String s) {
    try {
      System.out.print("["+new Throwable().getStackTrace()[1].getClassName()+"] ");
    } catch (Exception e) { System.out.print("[  UNKNOWN  ] "); };
    System.out.println(s);
  };
  /** Outputs a debug string
   * @param b boolean expression to output */
  public static void sprintln(boolean b) {
    try {
      System.out.print("["+new Throwable().getStackTrace()[1].getClassName()+"] ");
    } catch (Exception e) { System.out.print("[  UNKNOWN  ] "); };
    System.out.println(b);
  };
  /** Loads an Icon with given name
   * @param name resource graphics name to load
   * @return graphics Icon to return */
  public static Icon getGraphics(String name) {
    try {
      sprintln("Loading icon: " + name);
      return new ImageIcon(Utils.class.getResource(name));
    } catch (Exception e) {
      BufferedImage im = new BufferedImage(16,16,BufferedImage.TYPE_4BYTE_ABGR);
//      im.getGraphics().setColor(new Color(255,255,255,0);
//      im.getGraphics().fillRect(0,0,im.getWidth(),im.getHeight());
      ImageIcon i = new ImageIcon(im);
      return i;
    }
  }

  public static void httpPostData(URL url, String content) {
    if (url==null) return;
    Utils.sprintln("Trying to post data to URL "+url.toString());
    try {
      URLConnection urlConn;
      DataOutputStream printout;
      urlConn = url.openConnection();
      urlConn.setDoInput(true);
      urlConn.setDoOutput(true);
      urlConn.setUseCaches(false);
      urlConn.setRequestProperty("Content-Type",
          "application/x-www-form-urlencoded");
      printout = new DataOutputStream(urlConn.getOutputStream());

//  String content = "name="+URLEncoder.encode(jTextFieldName.getText())+
//    "&image="+URLEncoder.encode(jComboBoxPicture.getSelectedItem().toString())+
//    "&pieces="+URLEncoder.encode(new Integer(pieces).toString())+
//    "&time="+URLEncoder.encode(new Integer(timeElapsed).toString());
      printout.writeBytes(content);
      Utils.sprintln("Posting URL data");
      printout.flush();
      printout.close();
      BufferedReader input = new BufferedReader(new InputStreamReader(urlConn.getInputStream()));
      String str;
      while (null != ( (str = input.readLine()))) {
      }
      input.close();
    } catch (Exception ex) {
      JOptionPane.showMessageDialog(null, ex.getLocalizedMessage(), "HTTP Error",
          JOptionPane.ERROR_MESSAGE);
    }
  }
}
