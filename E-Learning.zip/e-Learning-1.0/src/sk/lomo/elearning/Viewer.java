package sk.lomo.elearning;

/**
 * <p>Title: e-Learning Viewer</p>
 * <p>Description: Viewer applet and application for displaying lesson files</p>
 * <p>Author: Julius Loman</p>
 * @version 1.0
 */

import java.io.*;
import java.net.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import sk.lomo.elearning.core.*;
import sk.lomo.elearning.core.commands.*;
import sk.lomo.elearning.core.event.*;
import sk.lomo.elearning.core.ui.*;
import sk.lomo.elearning.core.ui.dialogs.*;
import sk.lomo.elearning.core.ui.state.*;

class LFrame extends JFrame {
  //Overridden so we can exit when window is closed
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      setVisible(false);
      System.exit(0);
    }
  }
}

/** Viewer applet and application for displaying lesson files. */

public class Viewer extends JApplet {
  private Lesson lesson;
  private StateManager stateManager = new StateManager();
  private String lessonURL;

  private boolean isStandalone = false;
  JScrollPane jScrollPaneSlide = new JScrollPane();
  BorderLayout borderLayout1 = new BorderLayout();

  private AbstractAction actionFileOpen = new AbstractAction("Open lesson",
      Utils.getGraphics("MenuFileOpen.gif")) {
    {
//      putValue(Action.MNEMONIC_KEY, new Integer(java.awt.event.KeyEvent.VK_O));
      putValue(Action.SHORT_DESCRIPTION, "Open existing lesson");
//      putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control O"));
      putValue(Action.LONG_DESCRIPTION, "Open exisiting lesson");
    }

    public void actionPerformed(ActionEvent e) {
      try {
        openLesson(LessonFileUtils.getLessonFileUtils().openLesson());
      } catch (FileNotFoundException ex) {
        JOptionPane.showMessageDialog(null, ex.getLocalizedMessage(),
            "Cannot open lesson", JOptionPane.ERROR_MESSAGE);
      } catch (IOException ex) {
        Utils.sprintln(ex.getLocalizedMessage());
      }
    }
  };

  private AbstractAction actionFileExit = new AbstractAction("Exit",
      Utils.getGraphics("MenuFileExit.gif")) {
    {
//      putValue(Action.MNEMONIC_KEY, new Integer(java.awt.event.KeyEvent.VK_X));
      putValue(Action.SHORT_DESCRIPTION, "Exit");
//      putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control N"));
      putValue(Action.LONG_DESCRIPTION, "Exit the designer");
    }

    public void actionPerformed(ActionEvent e) {
      Utils.sprintln("Exitting");
      System.exit(0);
    }
  };
  private AbstractAction actionViewPrevSlide = new AbstractAction(
      "Previous slide", Utils.getGraphics("MenuViewPreviousSlide.gif")) {
    {
//      putValue(Action.MNEMONIC_KEY, new Integer(java.awt.event.KeyEvent.VK_P));
      putValue(Action.SHORT_DESCRIPTION, "Previous slide");
      putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("F7"));
      putValue(Action.LONG_DESCRIPTION, "Go to previous slide");
    }

    public void actionPerformed(ActionEvent e) {
      if (lesson == null) {
        return;
      }
      lesson.goToPrevSlide();
    }
  };

  private AbstractAction actionViewNextSlide = new AbstractAction("Next slide",
      Utils.getGraphics("MenuViewNextSlide.gif")) {
    {
//      putValue(Action.MNEMONIC_KEY, new Integer(java.awt.event.KeyEvent.VK_N));
      putValue(Action.SHORT_DESCRIPTION, "Next slide");
      putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("F8"));
      putValue(Action.LONG_DESCRIPTION, "Go to next slide");
    }

    public void actionPerformed(ActionEvent e) {
      if (lesson == null) {
        return;
      }
      lesson.goToNextSlide();
    }
  };

  private AbstractAction actionViewGoToSlide = new AbstractAction("Go to slide",
      Utils.getGraphics("MenuViewGoToSlide.gif")) {
    {
//      putValue(Action.MNEMONIC_KEY, new Integer(java.awt.event.KeyEvent.VK_T));
      putValue(Action.SHORT_DESCRIPTION, "Go to slide");
//      putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("F12"));
      putValue(Action.LONG_DESCRIPTION, "Go to specific slide");
    }

    public void actionPerformed(ActionEvent e) {
      if (lesson == null) {
        return;
      }
      SlideSelectDialog d = new SlideSelectDialog(null, "Select slide", true,
          lesson);

      Point loc = getLocation();
      Dimension dlgSize = d.getPreferredSize();
      Dimension frmSize = getSize();
      d.setLocation( (frmSize.width - dlgSize.width) / 2 + loc.x,
          (frmSize.height - dlgSize.height) / 2 + loc.y);

      d.show();
      if (d.option == JOptionPane.OK_OPTION) {
        lesson.goToSlide(d.number);
      }
    }
  };

  private AbstractAction actionHelpAbout = new AbstractAction("Designer",
      Utils.getGraphics("MenuHelpDesigner.gif")) {
    {
      putValue(Action.MNEMONIC_KEY, new Integer(java.awt.event.KeyEvent.VK_H));
      putValue(Action.SHORT_DESCRIPTION, "Help");
      putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("F1"));
      putValue(Action.LONG_DESCRIPTION, "Show help");
    }

    public void actionPerformed(ActionEvent e) {
      sk.lomo.elearning.core.ui.WebBrowser.help("index");
    }
  };

  private SlideChangeListener slideChangeListener = new SlideChangeListener() {
    public void slideChanged(Slide from, Slide to) {
      actionViewNextSlide.setEnabled(lesson.canGoToNextSlide());
      actionViewPrevSlide.setEnabled(lesson.canGoToPrevSlide());

      Utils.sprintln("Slide changed " + from + " -> " + to);
      if (from != null) {
        stateManager.setStateNull();
      }
      stateManager.setCanvas(to);
      stateManager.setStateArrow();
//      slideComboBox.refresh(lesson);

      if (lesson.getCurrentSlide() != null) {
        lesson.getCurrentSlide().clearSelection();
        lesson.getCurrentSlide().setDesignMode(lesson.isDesignMode());
      }
      setSlide(lesson.getCurrentSlide());
      if (lesson.getCurrentSlide() != null) {
        lesson.getCurrentSlide().updateUI();
//        lesson.getCurrentSlide().removeContainerListener(slideObjectsListener);
//        lesson.getCurrentSlide().addContainerListener(slideObjectsListener);

        requestFocus();
      }
    }

    public void slideSelectionChanged(Slide onSlide) {

    };
  };
  JMenuBar jMenuBar1 = new JMenuBar();
  JMenu jMenuFile = new JMenu();
  JMenu jMenuHelp = new JMenu();
  JMenu jMenuView = new JMenu();

  private void openLesson(Lesson l) {
    if (l != null) {
      lesson = l;
      lesson.addSlideChangeListener(slideChangeListener);
      lesson.setCurrentSlide(0);
      clearSlideViewPort();
      setSlide(lesson.getCurrentSlide());
      stateManager.setCanvas(lesson.getCurrentSlide());
      stateManager.setStateArrow();
      lesson.commandManager = new EventableUndoManager();
      lesson.fireSlideChange();
      lesson.setDesignMode(false);
      if (!isStandalone) {
        lesson.setAppletContext(getAppletContext());
      }
      jMenuView.setVisible(lesson.isEnableNavigation());
      jMenuView.setEnabled(lesson.isEnableNavigation());
//      setSize((int) jScrollPaneSlide.getPreferredSize().getWidth()+(int)jScrollPaneSlide.getHorizontalScrollBar().getPreferredSize().getWidth(), (int) jScrollPaneSlide.getPreferredSize().getHeight()+(int) jScrollPaneSlide.getHorizontalScrollBar().getPreferredSize().getHeight()+jMenuBar1.getHeight());
    }
  }

  protected void setSlide(Slide s) {
    clearSlideViewPort();
    if (s != null) {
      jScrollPaneSlide.getViewport().add(s, BorderLayout.CENTER);
    }
    jScrollPaneSlide.getViewport().updateUI();
  }

  protected void clearSlideViewPort() {
    jScrollPaneSlide.getViewport().removeAll();
  }

  //Get a parameter value
  public String getParameter(String key, String def) {
    return "";
//    return isStandalone ? System.getProperty(key, def) :
//      (getParameter(key) != null ? getParameter(key) : def);
  }

  //Construct the applet
  public Viewer() {
  }

  //Construct the applet
  public Viewer(String fileName) {
    lessonURL = fileName;
  }

  //Initialize the applet
  public void init() {
    Utils.sprintln("Applet initializing");
    try {
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    } catch (Exception e) {
      e.printStackTrace();
    }
    try {
      jbInit();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  //Component initialization
  private void jbInit() throws Exception {
    getContentPane().setLayout(borderLayout1);
    jMenuFile.setText("File");
    jMenuHelp.setText("Help");
    jMenuView.setText("View");
    getContentPane().add(jScrollPaneSlide, BorderLayout.CENTER);
    jMenuBar1.add(jMenuFile);
    jMenuBar1.add(jMenuView);
    jMenuBar1.add(jMenuHelp);
    jMenuFile.add(actionFileOpen);
    jMenuFile.addSeparator();
    jMenuFile.add(actionFileExit);

    if (!isStandalone) {
      jMenuFile.setVisible(false);
      jMenuFile.setEnabled(false);
    }
    jMenuView.add(actionViewPrevSlide);
    jMenuView.add(actionViewNextSlide);
    jMenuView.add(actionViewGoToSlide);
    jMenuView.setEnabled(false);
    jMenuView.setVisible(false);

    jMenuHelp.add(actionHelpAbout);
    jScrollPaneSlide.getViewport().setLayout(new CenterLayout());
    jScrollPaneSlide.getViewport().add(new JLabel("No lesson opened."));
    setJMenuBar(jMenuBar1);
  }

  //Start the applet
  public void start() {
//    library.setDirectory("./plugins/");
//    library.loadFileObjects();
    try {
      Utils.sprintln("Viewer applet starting");
      if (isStandalone) {
        Utils.sprintln("Running as standalone");
        if (lessonURL == null) {
          openLesson(LessonFileUtils.getLessonFileUtils().openLesson());
        } else {
          actionFileOpen.actionPerformed(null);
        }
        lessonURL = LessonFileUtils.getLessonFileUtils().currentFilename;
      } else {
        Utils.sprintln("Running as applet");
        try {
          URL url = new URL(getCodeBase(), getParameter("lesson"));
          openLesson(LessonFileUtils.getLessonFileUtils().openAppletLesson(url));
        } catch (MalformedURLException mue) {
          Utils.sprintln("Malformed url " + getCodeBase() +
              getParameter("lesson"));
        }
      }
    } catch (FileNotFoundException e) {
      JOptionPane.showMessageDialog(null, "File not found",
          "Cannot open lesson", JOptionPane.ERROR_MESSAGE);
    } catch (IOException e) {
      Utils.sprintln(e.getLocalizedMessage());
    }
  }

  //Stop the applet
  public void stop() {
    Utils.sprintln("Viewer applet stopping");
  }

  //Destroy the applet
  public void destroy() {
    Utils.sprintln("Viewer applet destroying");
  }

  //Get Applet information
  public String getAppletInfo() {
    return "e-Learning lesson viewer";
  }

  //Get parameter info
  public String[][] getParameterInfo() {
    return null;
  }

  //Main method
  public static void main(String[] args) {
    Utils.sprintln("Starting viewer as standalone");
    Viewer applet;
    if (args.length > 0) {
      applet = new Viewer(args[0]);
    } else {
      applet = new Viewer();
    }
    applet.isStandalone = true;
    LFrame frame = new LFrame();
    frame.setTitle("e-Learning Lesson viewer");
    frame.getContentPane().setLayout(new BorderLayout());
    frame.getContentPane().add(applet, BorderLayout.CENTER);
    applet.init();
    applet.start();
    frame.setSize(650, 550);
    Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
    frame.setLocation( (d.width - frame.getSize().width) / 2,
        (d.height - frame.getSize().height) / 2);
    frame.setVisible(true);
  }
}
