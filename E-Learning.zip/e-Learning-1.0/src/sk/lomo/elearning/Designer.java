package sk.lomo.elearning;

/**
 * <p>Title: Designer</p>
 * <p>Description: Main system window Frame</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.io.*;
import java.util.*;

import java.awt.*;
import java.awt.event.*;
import java.awt.datatransfer.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.undo.*;

import sk.lomo.elearning.core.*;
import sk.lomo.elearning.core.commands.*;
import sk.lomo.elearning.core.event.*;
import sk.lomo.elearning.core.interfaces.*;
import sk.lomo.elearning.core.ui.*;
import sk.lomo.elearning.core.ui.dialogs.*;
import sk.lomo.elearning.core.ui.state.*;

/** Main system window Frame */

public class Designer extends JFrame {
  /** file, properties are in */
  private String PROPERTIES_FILENAME = ".properties";
  /** how many recent files will be remebered */
  private int RECENTFILES_COUNT = 9;
  /** window title*/
  private String WINDOW_TITLE = "e-Learning Designer";
  /** properties file */
  private Properties properties = new Properties();
  /** lesson that is loaded */
  private Lesson lesson;
  /** globaal state manager for mouse states*/
  private StateManager stateManager;
  /** color chooser for fg/bg colors */
  private JColorChooser colorChooser = new JColorChooser();
  /** true if we are determining fonts, don't update font lists */
  private boolean determiningFonts = false;
  /** true if we are pasting, don't update font lists */
  private boolean pastingObjects = false;
  /** Object transfer handler for dropping new objects onto existing */
  private ObjTransferHandler objectTransferHandler = new
      ObjTransferHandler(null);

  /** undo/redo listener for updating UI */
  private UndoRedoListener undoRedoListener = new UndoRedoListener() {
    public void disableAllEdits() {
      actionEditUndo.setEnabled(false);
      actionEditRedo.setEnabled(false);
    }

    public void refresh(EventableUndoManager um) {
      if (um.canUndo()) {
        actionEditUndo.setEnabled(true);
      } else {
        actionEditUndo.setEnabled(false);
      }
      if (um.canRedo()) {
        actionEditRedo.setEnabled(true);
      } else {
        actionEditRedo.setEnabled(false);
      }
      actionEditUndo.putValue("Name", um.getUndoPresentationName());
      actionEditRedo.putValue("Name", um.getRedoPresentationName());
      jButtonEditRedo.setText("");
      jButtonEditUndo.setText("");
    }

    public void undoPerformed(EventableUndoManager undoManager) {
      refresh(undoManager);
    };
    public void redoPerformed(EventableUndoManager undoManager) {
      refresh(undoManager);
    };
    public void undoableEditAdded(EventableUndoManager undoManager) {
      refresh(undoManager);
    };

    public void editsDiscarded(EventableUndoManager undoManager) {
      refresh(undoManager);
    }
  };

  private SlideChangeListener slideChangeListener = new SlideChangeListener() {
    Color foregroundColor = Color.BLACK;
    Color backgroundColor = Color.WHITE;
    // old values, before something was selected
    int fontName = 0;
    int fontSize = 0;
    boolean fontBold = false;
    int lastSelectedCount = -1;

    public void slideChanged(Slide from, Slide to) {
      Utils.sprintln("Slide changed " + from + " -> " + to);
      updateUISlide();
      updateUIEdit();
      if (from != null) {
        stateManager.setStateNull();
      }
      stateManager.setCanvas(to);
      stateManager.setStateArrow();
      slideComboBox.refresh(lesson);

      if (lesson.getCurrentSlide() != null) {
        lesson.getCurrentSlide().clearSelection();
        lesson.getCurrentSlide().setDesignMode(lesson.isDesignMode());
      }
      ;
      setSlide(lesson.getCurrentSlide());
      if (lesson.getCurrentSlide() != null) {
        lesson.getCurrentSlide().updateUI();
        lesson.getCurrentSlide().removeContainerListener(slideObjectsListener);
        lesson.getCurrentSlide().addContainerListener(slideObjectsListener);

        requestFocus();
      }
    }

    public void slideSelectionChanged(Slide onSlide) {

      boolean allIText = true;
      String fontName = null;
      int fontSize = -1;
      boolean fontStyleBold = false;

      if (pastingObjects) {
        return;
      }

      Utils.sprintln("Selection changed on " +
          onSlide.toString());

      updateUIEdit();

      determiningFonts = true;

      // determine fonts of selected objects
      Vector selObjects = onSlide.getSelectedObjects();
      Iterator i = selObjects.iterator();
      while (i.hasNext()) {
        Object o = i.next();
        if (o instanceof ITextObject) {
          // initialize first
          if (fontName == null) {
            fontName = ( (ITextObject) o).getFont().getFontName();
            fontStyleBold = ( (ITextObject) o).getFont().isBold();
          }
          if (fontSize == -1) {
            fontSize = ( (ITextObject) o).getFont().getSize();
            // compare with existing
          }
          if (! ( (ITextObject) o).getFont().getFontName().equals(fontName)) {
            fontName = "";
          }
          if ( ( (ITextObject) o).getFont().getSize() != fontSize) {
            fontSize = -1;
          }
          if ( ( (ITextObject) o).getFont().isBold() != fontStyleBold) {
            fontStyleBold = false;
          }
        } else {
          allIText = false;
        }
      }
      if (selObjects.size() == 0 && this.lastSelectedCount > 0) {
        // user has cleared selection
        jComboBoxFontList.setSelectedIndex(this.fontName);
        jComboBoxFontSize.setSelectedIndex(this.fontSize);
        jButtonFontBold.setSelected(this.fontBold);
        this.lastSelectedCount = selObjects.size();
        setLessonDefaultValues();
        lesson.setDefaultBgColor(this.backgroundColor);
        lesson.setDefaultFgColor(this.foregroundColor);
        jButtonFgColor.setBackground(this.foregroundColor);
        jButtonBgColor.setBackground(this.backgroundColor);
        determiningFonts = false;
        return;
      }

      if ( (selObjects.size() > 0) && (this.lastSelectedCount == 0)) {
        // user has selected some objects
        this.fontName = jComboBoxFontList.getSelectedIndex();
        this.fontSize = jComboBoxFontSize.getSelectedIndex();
        this.fontBold = jButtonFontBold.isSelected();
        this.foregroundColor = lesson.getDefaultFgColor();
        this.backgroundColor = lesson.getDefaultBgColor();
      }

      if (this.lastSelectedCount == -1) {
        // initialize default values, we get only once here
        this.fontName = jComboBoxFontList.getSelectedIndex();
        this.fontSize = jComboBoxFontSize.getSelectedIndex();
        this.fontBold = jButtonFontBold.isSelected();
        this.foregroundColor = lesson.getDefaultFgColor();
        this.backgroundColor = lesson.getDefaultBgColor();

        this.lastSelectedCount = selObjects.size();
        setLessonDefaultValues();
      }

      this.lastSelectedCount = selObjects.size();

      if (allIText && (selObjects.size() > 0)) {
        Utils.sprintln("All fonts are name: " + fontName);

        DefaultComboBoxModel model = (DefaultComboBoxModel) jComboBoxFontList.
            getModel();
        Font availFont;
        boolean foundFontFace = false;
        for (int index = 0; index < model.getSize(); index++) {
          availFont = (Font) model.getElementAt(index);
          if (availFont.getFontName().toUpperCase().indexOf(fontName.
              toUpperCase()) != -1) {
            Utils.sprintln("Font matches at index " + index + " with font " +
                availFont.getFontName());
            jComboBoxFontList.setSelectedIndex(index);
            foundFontFace = true;
            break;
          }
        }
        if (!foundFontFace) {
          jComboBoxFontList.setSelectedIndex(0);

//        if (fontName.indexOf(".") > 0) {
//          fontName = fontName.substring(0, fontName.indexOf("."));
//        }
//        int idx = -1; // find index of font combo box item
//        for (int j = 0; j < jComboBoxFontList.getItemCount(); j++) {
//          if ( ( (DefaultComboBoxModel) jComboBoxFontList.getModel()).
//              getElementAt(j).equals(fontName)) {
//            idx = j;
//          }
//        }

        }
        int idx = -1;
        // set font size combo box
        Utils.sprintln(
            "[SlideChangeEvent: SelectionChange] All fonts are size: " +
            fontSize);
        if (fontSize == -1) {
          jComboBoxFontSize.setSelectedIndex(0);
        } else {
          jComboBoxFontSize.setSelectedItem(Integer.toString(fontSize));

//        for (int j = 0; j < jComboBoxFontSize.getItemCount(); j++) {
//          if ( ( ( (DefaultComboBoxModel) jComboBoxFontSize.getModel()).
//              getElementAt(j)).equals(new Integer(fontSize))) {
//            idx = j;
//          }
//        }
//        if (idx >= 0) {
//          jComboBoxFontSize.setSelectedIndex(idx);
//        } else {
//          jComboBoxFontSize.setSelectedIndex(0);
//
//        }
        }
        Utils.sprintln(
            "All fonts are bold: " +
            fontStyleBold);
        jButtonFontBold.setSelected(fontStyleBold);
      }
      determiningFonts = false;
    };
  };

  private ContainerListener slideObjectsListener = new ContainerAdapter() {
    public void componentAdded(ContainerEvent e) {
      if (e.getComponent()instanceof ITextObject) {
        Font f = new Font(jComboBoxFontList.getSelectedItem().toString(),
            (jButtonFontBold.isSelected()) ? Font.BOLD : Font.PLAIN,
            ( (Integer) jComboBoxFontSize.getSelectedItem()).intValue());
        ( (ITextObject) e.getComponent()).setFont(f);
      }
      stateManager.setStateArrow();
    }
  };

  private JPanel contentPane;
  private JPanel mainPanel;
  private JMenuBar jMenuBar1 = new JMenuBar();
  private JMenu jMenuFile = new JMenu();
  private JMenu jMenuHelp = new JMenu();
  private JMenu jMenuEdit = new JMenu();
  private JMenu jMenuSlide = new JMenu();

  private Icon iconFontBold = Utils.getGraphics("ActionTextFontBold.gif");
  private Icon iconTextAlignLeft = Utils.getGraphics("MenuTextAlignLeft.gif");
  private Icon iconTextAlignCenter = Utils.getGraphics(
      "MenuTextAlignCenter.gif");
  private Icon iconTextAlignRight = Utils.getGraphics("MenuTextAlignRight.gif");

  private Icon imageArrowSelect = Utils.getGraphics("ActionArrowSelect.gif");
  private Icon imageActionFgColor = Utils.getGraphics(
      "ActionForegroundColor.gif");
  private Icon imageActionBgColor = Utils.getGraphics(
      "ActionBackgroundColor.gif");

  private BorderLayout borderLayout1 = new BorderLayout();

  private JPanel jPanel2 = new JPanel();
  private JButton jButtonLessonNew = new JButton();
  private JToolBar jToolBar = new JToolBar();
  private JButton jButtonLessonSave = new JButton();
  private JButton jButtonLessonOpen = new JButton();
  private JToolBar jToolBarFont = new JToolBar();
  private JToggleButton jButtonFontBold = new JToggleButton();
  private JComboBox jComboBoxFontList;
  private JToolBar jToolBarTools = new JToolBar();
  private JToggleButton jButtonArrowSelect = new JToggleButton();
  private JMenu jMenuView = new JMenu();
  private JSplitPane jSplitPane1 = new JSplitPane();
  private JPanel jPanelSlideSelector = new JPanel();
  private SlideComboBox slideComboBox = new SlideComboBox(null);
  private JPanel jPanelDesign = new JPanel();
  private ObjectRepository objectRepository = new ObjectRepository();
  private BorderLayout borderLayout2 = new BorderLayout();
  private JLabel jLabelSlideSel = new JLabel();
  private JScrollPane jScrollPaneSlide = new JScrollPane();
  private JLabel statusBar = new JLabel();
  private JComboBox jComboBoxFontSize = new JComboBox();
  private JButton jButtonEditUndo = new JButton();
  private JButton jButtonEditRedo = new JButton();
  private JButton jButtonEditCut = new JButton();
  private JButton jButtonEditCopy = new JButton();
  private JButton jButtonEditPaste = new JButton();
  private JToolBar jToolBarEdit = new JToolBar();
  private JButton jButtonEditDelete = new JButton();
  private FlowLayout flowLayout1 = new FlowLayout();
  private JButton jButtonFgColor = new JButton();
  private JButton jButtonBgColor = new JButton();
  private JButton jButtonSlideNewSlide = new JButton();
  private JButton jButtonViewPrevSlide = new JButton();
  private JButton jButtonViewNextSlide = new JButton();

  private void addToRecentFiles(String fileName) {
    if (fileName == null) {
      return;
    }
    for (int i = RECENTFILES_COUNT - 1; i > 0; i--) {
      properties.setProperty("RecentFile" + i,
          properties.getProperty("RecentFile" + (i - 1), ""));
    }
    properties.setProperty("RecentFile0", fileName);
  }

  private String[] getRecentFiles() {
    int count = 0;
    for (int i = 0; i < RECENTFILES_COUNT; i++) {
      if (!properties.getProperty("RecentFile" + i, "").equals("")) {
        count++;
      }
    }
    String[] recent = new String[count];
    int j = 0;
    for (int i = 0; i < RECENTFILES_COUNT; i++) {
      if (!properties.getProperty("RecentFile" + i, "").equals("")) {
        recent[j++] = properties.getProperty("RecentFile" + i, "");
      }
    }

    return recent;
  }

  private AbstractAction actionFileNew = new AbstractAction("New lesson",
      Utils.getGraphics("MenuFileNew.gif")) {
    {
//      putValue(Action.MNEMONIC_KEY, new Integer(java.awt.event.KeyEvent.VK_N));
      putValue(Action.SHORT_DESCRIPTION, "Create new nesson");
      putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control N"));
      putValue(Action.LONG_DESCRIPTION, "Create new lesson");
    }

    public void actionPerformed(ActionEvent e) {
      NewLessonDialog dlg = new NewLessonDialog(getRecentFiles());
      dlg.setModal(true);
      dlg.show();

      switch (dlg.getAction()) {
        case NewLessonDialog.ACTION_TEMPLATE:
          openLesson(dlg.getTemplateLesson());
          LessonFileUtils.getLessonFileUtils().getLessonFileUtils().
              currentFilename = null;
          setTitle(WINDOW_TITLE);
          break;
        case NewLessonDialog.ACTION_EMPTY:
          LessonPropertiesDialog dlgp = new LessonPropertiesDialog(null);
          dlg.setTitle("New lesson");
          Dimension dlgSize = dlgp.getPreferredSize();
          Dimension frmSize = Toolkit.getDefaultToolkit().getScreenSize();

          dlgp.setLocation( (frmSize.width - dlgSize.width) / 2,
              (frmSize.height - dlgSize.height) / 2);
          dlgp.setModal(true);
          dlgp.pack();
          dlgp.show();
          Lesson lesson2 = dlgp.getLesson(new Lesson());
          setTitle(WINDOW_TITLE);
          if (lesson2 != null) {
            clearSlideViewPort();
            stateManager.setStateNull();
            lesson = lesson2;
            lesson.addSlideChangeListener(slideChangeListener);
            jScrollPaneSlide.updateUI();
            lesson.setDesignMode(true);
            lesson.commandManager.addUndoRedoListener(undoRedoListener);
            LessonFileUtils.getLessonFileUtils().currentFilename = null;
            jScrollPaneSlide.grabFocus();
            actionViewDesignMode.actionPerformed(e);
            setLessonDefaultValues();
            actionSlideNewSlide.actionPerformed(e);
          }
          break;
        case NewLessonDialog.ACTION_EXISTING:
          actionFileOpen.actionPerformed(e);
          break;
        case NewLessonDialog.ACTION_RECENT:
          openLesson(dlg.getRecentLesson());
          break;
      }
    }
  };

  private AbstractAction actionFileOpen = new AbstractAction("Open lesson",
      Utils.getGraphics("MenuFileOpen.gif")) {
    {
//      putValue(Action.MNEMONIC_KEY, new Integer(java.awt.event.KeyEvent.VK_O));
      putValue(Action.SHORT_DESCRIPTION, "Open existing lesson");
      putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control O"));
      putValue(Action.LONG_DESCRIPTION, "Open exisiting lesson");
    }

    public void actionPerformed(ActionEvent e) {
      openLesson(null);
    }
  };

  private AbstractAction actionFileSave = new AbstractAction("Save lesson",
      Utils.getGraphics("MenuFileSave.gif")) {
    {
//      putValue(Action.MNEMONIC_KEY, new Integer(java.awt.event.KeyEvent.VK_S));
      putValue(Action.SHORT_DESCRIPTION, "Save current lesson");
      putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control S"));
      putValue(Action.LONG_DESCRIPTION, "Save current lesson");
    }

    public void actionPerformed(ActionEvent e) {
      stateManager.setStateNull();
      LessonFileUtils.getLessonFileUtils().saveLesson(lesson, false);
      stateManager.setStateArrow();
      addToRecentFiles(LessonFileUtils.getLessonFileUtils().currentFilename);
      if (LessonFileUtils.getLessonFileUtils().currentFilename != null) {
        setTitle(WINDOW_TITLE + " - " +
            LessonFileUtils.getLessonFileUtils().currentFilename);
      }
    }
  };

  private AbstractAction actionFileSaveAs = new AbstractAction("Save lesson as",
      Utils.getGraphics("MenuFileSaveAs.gif")) {
    {
//      putValue(Action.MNEMONIC_KEY, new Integer(java.awt.event.KeyEvent.VK_A));
      putValue(Action.SHORT_DESCRIPTION, "Save current lesson as");
      putValue(Action.LONG_DESCRIPTION, "Save current lesson as");
    }

    public void actionPerformed(ActionEvent e) {
      stateManager.setStateNull();
      LessonFileUtils.getLessonFileUtils().saveLesson(lesson, true);
      stateManager.setStateArrow();
      addToRecentFiles(LessonFileUtils.getLessonFileUtils().currentFilename);
      if (LessonFileUtils.getLessonFileUtils().currentFilename != null) {
        setTitle(WINDOW_TITLE + " - " +
            LessonFileUtils.getLessonFileUtils().currentFilename);
      }
    }
  };

  private AbstractAction actionFilePublish = new AbstractAction(
      "Publish lesson to web",
      Utils.getGraphics("MenuFilePublish.gif")) {
    {
      putValue(Action.MNEMONIC_KEY, new Integer(java.awt.event.KeyEvent.VK_A));
      putValue(Action.SHORT_DESCRIPTION, "Publish lesson to web");
      putValue(Action.LONG_DESCRIPTION, "Publish lesson to web");
    }

    public void actionPerformed(ActionEvent e) {
      JFileChooser jfc = new JFileChooser();
      jfc.setName("Select file to publish to");
//      jfc.setFileSelectionMode(jfc.DIRECTORIES_ONLY);
      jfc.setFileFilter(new javax.swing.filechooser.FileFilter() {
        public boolean accept(File pathname) {
          if (pathname.isDirectory()) {
            return true;
          }
          if (pathname.getName().toLowerCase().endsWith(".html")) {
            return true;
          }
          if (pathname.getName().toLowerCase().endsWith(".htm")) {
            return true;
          }
          return false;
        }

        public String getDescription() {
          return "HTML files";
        }
      });

      if (jfc.showSaveDialog(null) == JFileChooser.APPROVE_OPTION) {
        File selected = jfc.getSelectedFile();
        if (selected.exists()) {
          if (JOptionPane.showConfirmDialog(null,
              "Published file " + selected.getName() +
              " already exists. Replace ?", "File exists",
              JOptionPane.OK_CANCEL_OPTION,
              JOptionPane.QUESTION_MESSAGE) != JOptionPane.OK_OPTION) {
            return;
          }
        }
        Utils.sprintln("Publishing lesson to " + selected.getAbsolutePath());
        LessonFileUtils.getLessonFileUtils().publishLesson(lesson,
            selected.getAbsolutePath());
      }
    }
  };

  private AbstractAction actionFileExit = new AbstractAction("Exit",
      Utils.getGraphics("MenuFileExit.gif")) {
    {
//      putValue(Action.MNEMONIC_KEY, new Integer(java.awt.event.KeyEvent.VK_X));
      putValue(Action.SHORT_DESCRIPTION, "Exit");
      putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("alt F4"));
      putValue(Action.LONG_DESCRIPTION, "Exit the designer");
    }

    public void actionPerformed(ActionEvent e) {
      if (lesson == null) {
        System.exit(0);
        return;
      }
      int result = JOptionPane.showConfirmDialog(getDesigner(),
          "Save current lesson ?", "Exit Designer",
          JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.WARNING_MESSAGE);
      switch (result) {
        case JOptionPane.CANCEL_OPTION:
          getDesigner().setVisible(true);
          return;
        case JOptionPane.YES_OPTION:
          actionFileSave.actionPerformed(e);
        case JOptionPane.NO_OPTION: {
          getDesigner().setVisible(false);
          try {
            properties.store(new FileOutputStream(PROPERTIES_FILENAME), "");
          } catch (FileNotFoundException ex) {

          } catch (IOException ex) {}
          ;
          System.exit(0);
        }
      }
    }
  };

  private AbstractAction actionEditUndo = new AbstractAction("Undo",
      Utils.getGraphics("MenuEditUndo.gif")) {
    {
//      putValue(Action.MNEMONIC_KEY, new Integer(java.awt.event.KeyEvent.VK_U));
      putValue(Action.SHORT_DESCRIPTION, "Undo");
      putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control Z"));
      putValue(Action.LONG_DESCRIPTION, "Undo last action");
    }

    public void actionPerformed(ActionEvent e) {
      if (lesson != null) {
        try {
          if (lesson.commandManager.canUndo()) {
            lesson.commandManager.undo();
          }
        } catch (CannotUndoException ex) {
          ex.printStackTrace();
        }
        ;
        stateManager.refresh();
      }
    }
  };

  private AbstractAction actionEditRedo = new AbstractAction("Redo",
      Utils.getGraphics("MenuEditRedo.gif")) {
    {
//      putValue(Action.MNEMONIC_KEY, new Integer(java.awt.event.KeyEvent.VK_R));
      putValue(Action.SHORT_DESCRIPTION, "Redo");
      putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control shift Z"));
      putValue(Action.LONG_DESCRIPTION, "Redo last undoed action");
    }

    public void actionPerformed(ActionEvent e) {
      if (lesson != null) {
        try {
          if (lesson.commandManager.canRedo()) {
            lesson.commandManager.redo();
          }
        } catch (CannotRedoException ex) {
          ex.printStackTrace();
        }
        ;
        stateManager.refresh();
      }
    }
  };

  private AbstractAction actionEditCut = new AbstractAction("Cut",
      Utils.getGraphics("MenuEditCut.gif")) {
    {
//      putValue(Action.MNEMONIC_KEY, new Integer(java.awt.event.KeyEvent.VK_T));
      putValue(Action.SHORT_DESCRIPTION, "Cut");
      putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control X"));
      putValue(Action.LONG_DESCRIPTION, "Cut");
    }

    public void actionPerformed(ActionEvent e) {
      if (lesson == null) {
        return;
      }
      if (lesson.getCurrentSlide().getSelectedObjects().size() > 0) {
        ClipboardCutCommand ccc = new ClipboardCutCommand(lesson.
            getCurrentSlide(), objectTransferHandler);
        ccc.redo();
        lesson.commandManager.addEdit(ccc);
      }
    }
  };

  private AbstractAction actionEditCopy = new AbstractAction("Copy",
      Utils.getGraphics("MenuEditCopy.gif")) {
    {
//      putValue(Action.MNEMONIC_KEY, new Integer(java.awt.event.KeyEvent.VK_C));
      putValue(Action.SHORT_DESCRIPTION, "Copy");
      putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control C"));
      putValue(Action.LONG_DESCRIPTION, "Copy");
    }

    public void actionPerformed(ActionEvent e) {
      if (lesson == null) {
        return;
      }
      if (lesson.getCurrentSlide().getSelectedObjects().size() > 0) {
        JVector objects = lesson.getCurrentSlide().getSelectedObjectsAsJVector();
        objectTransferHandler.getCopyAction().actionPerformed(new ActionEvent(
            objects, 0, "copy"));
      }
    }
  };

  private AbstractAction actionEditPaste = new AbstractAction("Paste",
      Utils.getGraphics("MenuEditPaste.gif")) {
    {
//      putValue(Action.MNEMONIC_KEY, new Integer(java.awt.event.KeyEvent.VK_P));
      putValue(Action.SHORT_DESCRIPTION, "Paste");
      putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control V"));
      putValue(Action.LONG_DESCRIPTION, "Paste");
    }

    public void actionPerformed(ActionEvent e) {
      try {
        pastingObjects = true;
        ClipboardPasteCommand cpc = new ClipboardPasteCommand(lesson.
            getCurrentSlide(), objectTransferHandler);
        cpc.redo();
        lesson.commandManager.addEdit(cpc);
      } catch (NullPointerException ex) {}
      ;
      pastingObjects = false;
    }
  };

  private AbstractAction actionEditDelete = new AbstractAction("Delete",
      Utils.getGraphics("MenuEditDelete.gif")) {
    {
//      putValue(Action.MNEMONIC_KEY, new Integer(java.awt.event.KeyEvent.VK_D));
      putValue(Action.SHORT_DESCRIPTION, "Delete");
      putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("DELETE"));
      putValue(Action.LONG_DESCRIPTION, "Delete");
    }

    public void actionPerformed(ActionEvent e) {
      if (lesson == null) {
        return;
      }
      if (lesson.getCurrentSlide().getSelectedObjects().size() > 0) {
        DeleteCommand dc = new DeleteCommand(lesson.getCurrentSlide());
        dc.redo();
        lesson.commandManager.addEdit(dc);
      }
    }
  };

  private AbstractAction actionEditLessonProperties = new AbstractAction(
      "Lesson properties", Utils.getGraphics("MenuEditLessonProperties.gif")) {
    {
//      putValue(Action.MNEMONIC_KEY, new Integer(java.awt.event.KeyEvent.VK_P));
      putValue(Action.SHORT_DESCRIPTION, "Edit lesson properties");
      putValue(Action.LONG_DESCRIPTION, "Edit lesson properties");
    }

    public void actionPerformed(ActionEvent e) {

      if (lesson == null) {
        return;
      }

      LessonPropertiesDialog dlg = new LessonPropertiesDialog(lesson);
      dlg.setTitle("Lesson properties");
      Dimension dlgSize = dlg.getPreferredSize();
      Dimension frmSize = Toolkit.getDefaultToolkit().getScreenSize();

      dlg.setLocation( (frmSize.width - dlgSize.width) / 2,
          (frmSize.height - dlgSize.height) / 2);
      dlg.setModal(true);
      dlg.pack();
      dlg.show();
      Lesson lesson2 = dlg.getLesson(lesson);
      if (lesson2 != null) {
        lesson = lesson2;
      }
    }
  };

  private AbstractAction actionEditSelectAll = new AbstractAction(
      "Select all", Utils.getGraphics("MenuEditSelectAll.gif")) {
    {
//      putValue(Action.MNEMONIC_KEY, new Integer(java.awt.event.KeyEvent.VK_P));
      putValue(Action.SHORT_DESCRIPTION, "Select all");
      putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control A"));
      putValue(Action.LONG_DESCRIPTION, "Select all");
    }

    public void actionPerformed(ActionEvent e) {
      try {
        lesson.getCurrentSlide().selectAllObjects();
      } catch (NullPointerException ex) {}
      ;
    }
  };

  private AbstractAction actionSlideNewSlide = new AbstractAction(
      "Insert slide", Utils.getGraphics("MenuSlideNewSlide.gif")) {
    {
//      putValue(Action.MNEMONIC_KEY, new Integer(java.awt.event.KeyEvent.VK_N));
      putValue(Action.SHORT_DESCRIPTION, "Insert new slide");
      putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control M"));
      putValue(Action.LONG_DESCRIPTION, "Insert new slide");
    }

    public void actionPerformed(ActionEvent e) {
      Slide s = lesson.getNewSlide();
      AddSlideCommand asc = new AddSlideCommand(lesson, s,
          lesson.getCurrentSlideNumber() + 1);
      asc.redo();
      lesson.commandManager.addEdit(asc);
      setSlide(s);
    }
  };

  private AbstractAction actionSlideRemoveSlide = new AbstractAction(
      "Remove slide", Utils.getGraphics("MenuSlideRemoveSlide.gif")) {
    {
//      putValue(Action.MNEMONIC_KEY, new Integer(java.awt.event.KeyEvent.VK_R));
      putValue(Action.SHORT_DESCRIPTION, "Remove current slide");
      putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control R"));
      putValue(Action.LONG_DESCRIPTION, "Remove current slide");
    }

    public void actionPerformed(ActionEvent e) {
      RemoveSlideCommand dsc = new RemoveSlideCommand(lesson,
          lesson.getCurrentSlide());
      lesson.commandManager.addEdit(dsc);
      dsc.redo();
    }
  };

  private AbstractAction actionSlideRenameSlide = new AbstractAction(
      "Edit slide name", Utils.getGraphics("MenuSlideSlideName.gif")) {
    {
//      putValue(Action.MNEMONIC_KEY, new Integer(java.awt.event.KeyEvent.VK_A));
      putValue(Action.SHORT_DESCRIPTION, "Rename slide");
      putValue(Action.LONG_DESCRIPTION, "Rename slide");
    }

    public void actionPerformed(ActionEvent e) {

      Object newText = JOptionPane.showInputDialog(null, "Enter slide name",
          "Slide name", JOptionPane.QUESTION_MESSAGE, null, null,
          lesson.getCurrentSlide().getName());
      if (newText != null) {
        ChangeObjectNameCommand conc = new ChangeObjectNameCommand(lesson.
            getCurrentSlide(), newText.toString());
        lesson.commandManager.addEdit(conc);
        conc.redo();
        lesson.fireSlideChange();
      }
    }
  };

  private AbstractAction actionSlideDuplicate = new AbstractAction(
      "Duplicate slide", Utils.getGraphics("MenuEditCopy.gif")) {
    {
//      putValue(Action.MNEMONIC_KEY, new Integer(java.awt.event.KeyEvent.VK_A));
      putValue(Action.SHORT_DESCRIPTION, "Duplicate slide");
      putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control D"));
      putValue(Action.LONG_DESCRIPTION, "Duplicate slide");
    }

    public void actionPerformed(ActionEvent e) {
      if (lesson==null) return;
      if (lesson.getCurrentSlide()==null) return;
      SlideDuplicateCommand cscc = new SlideDuplicateCommand(lesson,
          lesson.getCurrentSlideNumber());
      cscc.redo();
      lesson.commandManager.addEdit(cscc);
    }
  };

  private AbstractAction actionSlideArrangeSlides = new AbstractAction(
      "Arrange slides", Utils.getGraphics("MenuSlideArrangeSlides.gif")) {
    {
//      putValue(Action.MNEMONIC_KEY, new Integer(java.awt.event.KeyEvent.VK_A));
      putValue(Action.SHORT_DESCRIPTION, "Arrange slides");
      putValue(Action.LONG_DESCRIPTION, "Arrange slides");
    }

    public void actionPerformed(ActionEvent e) {
      SlideArrangeDialog d = new SlideArrangeDialog(null, "Arrange slides", true,
          lesson);
      Point loc = getLocation();
      Dimension dlgSize = d.getPreferredSize();
      Dimension frmSize = getSize();
      d.setLocation( (frmSize.width - dlgSize.width) / 2 + loc.x,
          (frmSize.height - dlgSize.height) / 2 + loc.y);

      d.show();

      setSlide(lesson.getCurrentSlide());
      lesson.fireSlideChange();
    }
  };

  private AbstractAction actionSlideChangeBackground = new AbstractAction(
      "Change slide background", Utils.getGraphics("MenuSlideBackground.gif")) {
    {
//      putValue(Action.MNEMONIC_KEY, new Integer(java.awt.event.KeyEvent.VK_A));
      putValue(Action.SHORT_DESCRIPTION, "Change slide background");
      putValue(Action.LONG_DESCRIPTION, "Change slide background");
    }

    public void actionPerformed(ActionEvent e) {
      Color newColor = JColorChooser.showDialog(lesson.getCurrentSlide(),
          "Set background color", lesson.getCurrentSlide().getBackground());
      if (newColor != null) {
        Vector objects = new Vector();
        objects.add(lesson.getCurrentSlide());
        ChangeObjectColorCommand cocc = new ChangeObjectColorCommand(objects,
            ChangeObjectColorCommand.COLOR_BACKGROUND, newColor);
        lesson.commandManager.addEdit(cocc);
        cocc.redo();
      }
    }
  };

  private AbstractAction actionSlideSetAsDefault = new AbstractAction(
      "Set slide as default", Utils.getGraphics("MenuSlideNewSlide.gif")) {
    {
//      putValue(Action.MNEMONIC_KEY, new Integer(java.awt.event.KeyEvent.VK_A));
      putValue(Action.SHORT_DESCRIPTION, "Set slide as default");
      putValue(Action.LONG_DESCRIPTION, "Set slide as default");
    }

    public void actionPerformed(ActionEvent e) {
      try {
        lesson.setDefaultSlide(lesson.getCurrentSlide());
      } catch (NullPointerException ex) {}
      ;
    }
  };

  private AbstractAction actionViewViewMode = new AbstractAction("View mode",
      Utils.getGraphics("MenuViewViewMode.gif")) {
    {
//      putValue(Action.MNEMONIC_KEY, new Integer(java.awt.event.KeyEvent.VK_V));
      putValue(Action.SHORT_DESCRIPTION, "Set view mode");
      putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("F3"));
      putValue(Action.LONG_DESCRIPTION, "Set view mode");
    }

    public void actionPerformed(ActionEvent e) {
      stateManager.setStateNull();
      lesson.setDesignMode(false);

      updateUIMode();
    }
  };

  private AbstractAction actionViewDesignMode = new AbstractAction(
      "Design mode", Utils.getGraphics("MenuViewDesignMode.gif")) {
    {
//      putValue(Action.MNEMONIC_KEY, new Integer(java.awt.event.KeyEvent.VK_D));
      putValue(Action.SHORT_DESCRIPTION, "Set design mode");
      putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("F4"));
      putValue(Action.LONG_DESCRIPTION, "Set design mode");
    }

    public void actionPerformed(ActionEvent e) {
      lesson.setDesignMode(true);
      stateManager.setStateArrow();
      updateUIMode();
    }
  };

  private AbstractAction actionViewShowGrid = new AbstractAction(
      "Hide grid", Utils.getGraphics("MenuAlignToGrid.gif")) {
    {
//      putValue(Action.MNEMONIC_KEY, new Integer(java.awt.event.KeyEvent.VK_P));
      putValue(Action.SHORT_DESCRIPTION, "Show or hide grid");
//      putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("PAGE_UP"));
      putValue(Action.LONG_DESCRIPTION, "Show or hide grid");
    }

    public void actionPerformed(ActionEvent e) {
      try {
        if (lesson.isShowGrid()) {
          lesson.setShowGrid(false);
        } else {
          lesson.setShowGrid(true);
        }
        lesson.getCurrentSlide().repaint();
        if (lesson.isShowGrid()) {
          this.putValue("Name", "Hide grid");
        } else {
          this.putValue("Name", "Show grid");
        }
      } catch (NullPointerException ex) {}
      ;
    }
  };

  private AbstractAction actionViewPrevSlide = new AbstractAction(
      "Previous slide", Utils.getGraphics("MenuViewPreviousSlide.gif")) {
    {
//      putValue(Action.MNEMONIC_KEY, new Integer(java.awt.event.KeyEvent.VK_P));
      putValue(Action.SHORT_DESCRIPTION, "Previous slide");
      putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("F7"));
      putValue(Action.LONG_DESCRIPTION, "Go to previous slide");
    }

    public void actionPerformed(ActionEvent e) {
      if (lesson == null) {
        return;
      }
      lesson.goToPrevSlide();
    }
  };

  private AbstractAction actionViewNextSlide = new AbstractAction("Next slide",
      Utils.getGraphics("MenuViewNextSlide.gif")) {
    {
//      putValue(Action.MNEMONIC_KEY, new Integer(java.awt.event.KeyEvent.VK_N));
      putValue(Action.SHORT_DESCRIPTION, "Next slide");
      putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("F8"));
      putValue(Action.LONG_DESCRIPTION, "Go to next slide");
    }

    public void actionPerformed(ActionEvent e) {
      if (lesson == null) {
        return;
      }
      lesson.goToNextSlide();
    }

  };

  private AbstractAction actionViewGoToSlide = new AbstractAction("Go to slide",
      Utils.getGraphics("MenuViewGoToSlide.gif")) {
    {
      putValue(Action.MNEMONIC_KEY, new Integer(java.awt.event.KeyEvent.VK_T));
      putValue(Action.SHORT_DESCRIPTION, "Go to slide");
      putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("F12"));
      putValue(Action.LONG_DESCRIPTION, "Go to specific slide");
    }

    public void actionPerformed(ActionEvent e) {
      if (lesson == null) {
        return;
      }
      SlideSelectDialog d = new SlideSelectDialog(null, "Select slide", true,
          lesson);

      Point loc = getLocation();
      Dimension dlgSize = d.getPreferredSize();
      Dimension frmSize = getSize();
      d.setLocation( (frmSize.width - dlgSize.width) / 2 + loc.x,
          (frmSize.height - dlgSize.height) / 2 + loc.y);

      d.show();
      if (d.option == JOptionPane.OK_OPTION) {
        lesson.goToSlide(d.number);
      }
    }
  };

  private AbstractAction actionHelpDesigner = new AbstractAction("Designer",
      Utils.getGraphics("MenuHelpDesigner.gif")) {
    {
//      putValue(Action.MNEMONIC_KEY, new Integer(java.awt.event.KeyEvent.VK_H));
      putValue(Action.SHORT_DESCRIPTION, "Help");
      putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("F1"));
      putValue(Action.LONG_DESCRIPTION, "Show help");
    }

    public void actionPerformed(ActionEvent e) {
      WebBrowser.help("designer");
    }
  };

  private AbstractAction actionHelpAbout = new AbstractAction("About project",
      Utils.getGraphics("MenuHelpDesigner.gif")) {
    {
//      putValue(Action.MNEMONIC_KEY, new Integer(java.awt.event.KeyEvent.VK_H));
      putValue(Action.SHORT_DESCRIPTION, "About project");
//      putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("F1"));
      putValue(Action.LONG_DESCRIPTION, "About project");
    }

    public void actionPerformed(ActionEvent e) {
      WebBrowser.help("index#AboutProject");
    }
  };

  //Construct the frame
  public Designer() {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  //Component initialization
  private void jbInit() throws Exception {
    try {
      properties.load(new FileInputStream(PROPERTIES_FILENAME));
    } catch (FileNotFoundException e) {}

    // create object repository
    objectRepository.library.clearObjects();
    objectRepository.library.loadFileObjects();
    stateManager = new StateManager(jButtonArrowSelect, objectRepository);
    setIconImage(Toolkit.getDefaultToolkit().createImage(Designer.class.
        getResource("ProjectIcon.gif")));
    jComboBoxFontList = new JComboBox();
    jComboBoxFontList.setRenderer(new FontNameRenderer());
    jComboBoxFontList.setModel(new DefaultComboBoxModel(
        GraphicsEnvironment.getLocalGraphicsEnvironment().getAllFonts()
        ));
    // find index of default font
    int idx = -1;
    for (int j = 0; j < jComboBoxFontList.getItemCount(); j++) {
      Font f = (Font) ( (DefaultComboBoxModel) jComboBoxFontList.getModel()).
          getElementAt(j);
      if (f.getName().toUpperCase().startsWith("DEFAULT")) {
        idx = j;
        break;
      }
    }
    if (idx >= 0) {
      jComboBoxFontList.setSelectedIndex(idx);
    } else {
      jComboBoxFontList.setSelectedIndex(1);
    }
    ;

    // initialize frame
    contentPane = (JPanel)this.getContentPane();
    contentPane.setLayout(new BorderLayout());
    mainPanel = new JPanel();
    flowLayout1.setAlignment(FlowLayout.LEFT);
    actionEditRedo.setEnabled(false);
    actionEditUndo.setEnabled(false);
    contentPane.add(mainPanel, BorderLayout.CENTER);
    mainPanel.setLayout(borderLayout1);
    this.setSize(new Dimension(750, 550));
    this.setTitle(WINDOW_TITLE);
    jMenuFile.setText("File");
    jMenuHelp.setText("Help");
    jMenuEdit.setText("Edit");
    jMenuSlide.setText("Slide");

    jButtonLessonNew.setAction(actionFileNew);
    jButtonLessonNew.setText("");
    jButtonLessonOpen.setAction(actionFileOpen);
    jButtonLessonOpen.setText("");
    jButtonLessonSave.setAction(actionFileSave);
    jButtonLessonSave.setText("");
    jButtonFontBold.setIcon(iconFontBold);
    jButtonFontBold.setPreferredSize(new Dimension(23, 23));
    jButtonFontBold.setMinimumSize(new Dimension(23, 23));
    jButtonFontBold.setMaximumSize(new Dimension(23, 23));

    jComboBoxFontList.setEditable(false);
    jButtonArrowSelect.setMaximumSize(new Dimension(23, 23));
    jButtonArrowSelect.setMinimumSize(new Dimension(23, 23));
    jButtonArrowSelect.setPreferredSize(new Dimension(23, 23));
    jButtonArrowSelect.setIcon(imageArrowSelect);
    jMenuView.setText("View");
    slideComboBox.setMinimumSize(new Dimension(75, 22));
    slideComboBox.setPreferredSize(new Dimension(120, 22));
    jPanelDesign.setLayout(borderLayout2);
    objectRepository.setFont(new java.awt.Font("Dialog", 0, 9));
    objectRepository.setPreferredSize(new Dimension(120, 400));
    objectRepository.setMinimumSize(new Dimension(120, 400));
    objectRepository.setFont(new Font("Dialog", Font.PLAIN, 9));
    jLabelSlideSel.setText(" Slide ");
    jSplitPane1.setDividerSize(5);
    jScrollPaneSlide.getViewport().setBackground(Color.gray);
    jScrollPaneSlide.setRequestFocusEnabled(false);
    statusBar.setFont(new java.awt.Font("Dialog", 1, 10));
    statusBar.setMaximumSize(new Dimension(0, 19));
    statusBar.setMinimumSize(new Dimension(0, 19));
    statusBar.setPreferredSize(new Dimension(0, 19));
    jComboBoxFontSize.setMaximumSize(new Dimension(32768, 22));
    jComboBoxFontSize.setMinimumSize(new Dimension(55, 22));
    jComboBoxFontSize.setPreferredSize(new Dimension(55, 22));
    jComboBoxFontSize.setEditable(true);

    jButtonEditUndo.setAction(actionEditUndo);
    jButtonEditUndo.setToolTipText("Undo");
    jButtonEditUndo.setText("");
    jButtonEditRedo.setAction(actionEditRedo);
    jButtonEditRedo.setToolTipText("Redo");
    jButtonEditRedo.setText("");
    jButtonEditCut.setAction(actionEditCut);
    jButtonEditCut.setToolTipText("Cut");
    jButtonEditCut.setText("");
    jButtonEditCopy.setToolTipText("Copy");
    jButtonEditCopy.setAction(actionEditCopy);
    jButtonEditCopy.setText("");
    jButtonEditPaste.setToolTipText("Paste");
    jButtonEditPaste.setAction(actionEditPaste);
    jButtonEditPaste.setText("");
    jButtonEditDelete.setToolTipText("Delete");
    jButtonEditDelete.setAction(actionEditDelete);
    jButtonEditDelete.setText("");
    jPanel2.setLayout(flowLayout1);
    jButtonFgColor.setBackground(Color.black);
    jButtonFgColor.setIcon(imageActionFgColor);
    jButtonBgColor.setIcon(imageActionBgColor);
    jButtonBgColor.setBackground(Color.white);
    jToolBarFont.add(jComboBoxFontList, null);
    jToolBarFont.add(jComboBoxFontSize, null);
    jToolBarFont.add(jButtonFontBold, null);
    jMenuHelp.add(actionHelpDesigner);
    jMenuHelp.add(actionHelpAbout);
    jMenuBar1.add(jMenuFile);
    jMenuBar1.add(jMenuEdit);
    jMenuBar1.add(jMenuSlide);
    jMenuBar1.add(jMenuView);
    jMenuBar1.add(jMenuHelp);
    this.setJMenuBar(jMenuBar1);
    mainPanel.add(jSplitPane1, BorderLayout.CENTER);
    jSplitPane1.add(jScrollPaneSlide, JSplitPane.RIGHT);
    jSplitPane1.add(jPanelDesign, JSplitPane.LEFT);
    jScrollPaneSlide.getViewport().setLayout(new CenterLayout());
    mainPanel.add(jPanel2, BorderLayout.NORTH);
    jToolBarEdit.add(jButtonEditUndo);
    jToolBarEdit.add(jButtonEditRedo);
    jToolBarEdit.addSeparator();
    jToolBarEdit.add(jButtonEditCut);
    jToolBarEdit.add(jButtonEditCopy);
    jToolBarEdit.add(jButtonEditPaste);
    jPanel2.add(jToolBar, null);
    jPanel2.add(jToolBarEdit, null);
    jToolBar.add(jButtonLessonNew);
    jToolBar.add(jButtonLessonOpen);
    jToolBar.add(jButtonLessonSave);
    jPanel2.add(jToolBarFont, null);
    jPanel2.add(jToolBarTools, null);
    mainPanel.add(statusBar, BorderLayout.SOUTH);
    jToolBarTools.add(jButtonFgColor, null);
    jToolBarTools.add(jButtonBgColor, null);
    jPanelSlideSelector.setLayout(new BorderLayout());
    jPanelSlideSelector.add(jLabelSlideSel, BorderLayout.WEST);
    jPanelSlideSelector.add(slideComboBox, BorderLayout.CENTER);
    JPanel jPanelSlideNavigation = new JPanel(new FlowLayout());
    jPanelSlideNavigation.add(jButtonArrowSelect);
    jPanelSlideNavigation.add(jButtonSlideNewSlide);
    jPanelSlideNavigation.add(jButtonViewPrevSlide);
    jPanelSlideNavigation.add(jButtonViewNextSlide);

    jMenuFile.add(actionFileNew);
    jMenuFile.add(actionFileOpen);
    jMenuFile.add(actionFileSave);
    jMenuFile.add(actionFileSaveAs);
    jMenuFile.add(actionFilePublish);
    jMenuFile.addSeparator();
    jMenuFile.add(actionFileExit);

    jMenuEdit.add(actionEditUndo);
    jMenuEdit.add(actionEditRedo);
    jMenuEdit.addSeparator();
    jMenuEdit.add(actionEditCut);
    jMenuEdit.add(actionEditCopy);
    jMenuEdit.add(actionEditPaste);
    jMenuEdit.add(actionEditDelete);
    jMenuEdit.add(actionEditSelectAll);
    jMenuEdit.addSeparator();
    jMenuEdit.add(actionEditLessonProperties);

    jMenuSlide.add(actionSlideNewSlide);
    jMenuSlide.add(actionSlideRemoveSlide);
    jMenuSlide.add(actionSlideDuplicate);
    jMenuSlide.add(actionSlideArrangeSlides);
    jMenuSlide.addSeparator();
    jMenuSlide.add(actionSlideRenameSlide);
    jMenuSlide.add(actionSlideChangeBackground);
    jMenuSlide.add(actionSlideSetAsDefault);

    jMenuView.add(actionViewViewMode);
    jMenuView.add(actionViewDesignMode);
    jMenuView.add(actionViewShowGrid);
    jMenuView.addSeparator();
    jMenuView.add(actionViewPrevSlide);
    jMenuView.add(actionViewNextSlide);
    jMenuView.add(actionViewGoToSlide);

    jButtonViewPrevSlide.setAction(actionViewPrevSlide);
    jButtonViewNextSlide.setAction(actionViewNextSlide);
    jButtonSlideNewSlide.setAction(actionSlideNewSlide);
    jButtonViewPrevSlide.setText("");
    jButtonViewNextSlide.setText("");
    jButtonSlideNewSlide.setText("");
    jButtonSlideNewSlide.setPreferredSize(new Dimension(23, 23));
    jButtonSlideNewSlide.setMinimumSize(new Dimension(23, 23));
    jButtonSlideNewSlide.setMaximumSize(new Dimension(23, 23));
    jButtonViewPrevSlide.setPreferredSize(new Dimension(23, 23));
    jButtonViewPrevSlide.setMinimumSize(new Dimension(23, 23));
    jButtonViewPrevSlide.setMaximumSize(new Dimension(23, 23));
    jButtonViewNextSlide.setPreferredSize(new Dimension(23, 23));
    jButtonViewNextSlide.setMinimumSize(new Dimension(23, 23));
    jButtonViewNextSlide.setMaximumSize(new Dimension(23, 23));

    jPanelSlideSelector.add(jPanelSlideNavigation, BorderLayout.SOUTH);
//    jPanelSlideSelector.add(jButton1, null);
//    jPanelSlideSelector.add(jLabel1, null);
//    jPanelSlideSelector.add(slideComboBox, null);
//    jPanelDesign.add(jButtonCreateFromRepository,  BorderLayout.SOUTH);
    jPanelDesign.add(objectRepository, BorderLayout.CENTER);
    jPanelDesign.add(jPanelSlideSelector, BorderLayout.NORTH);
    jToolBarEdit.add(jButtonEditDelete, null);

    jComboBoxFontSize.setModel(new DefaultComboBoxModel(
        new String[] {
        "", "8", "9", "10", "11", "12", "14", "16", "18", "24", "36", "48"}
        ));
    jComboBoxFontSize.setSelectedIndex(4);

    stateManager.addStateChangeListener(new StateChangeListener() {
      public void stateChanged(State from, State to) {
        try {
          statusBar.setText(to.toString());
        } catch (NullPointerException e) {}
      }
    });

    objectRepository.setStateManager(stateManager);

    jMenuEdit.setVisible(false);
    jMenuSlide.setVisible(false);
    jToolBarEdit.setVisible(false);
    jToolBarFont.setVisible(false);
    jToolBarTools.setVisible(false);
    mainPanel.remove(jSplitPane1);
    mainPanel.add(jScrollPaneSlide, BorderLayout.CENTER);
    mainPanel.updateUI();
    undoRedoListener.disableAllEdits();

    actionFileSave.setEnabled(false);
    actionFileSaveAs.setEnabled(false);
    actionFilePublish.setEnabled(false);
    jButtonLessonSave.setVisible(false);
    jMenuView.setVisible(false);

    // add anonymous button listeners
    jButtonFontBold.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        if ( (lesson == null) || determiningFonts) {
          return;
        }
        if (lesson.getCurrentSlide() == null) {
          return;
        }
        if (!determiningFonts) {
          Vector objects = lesson.getCurrentSlide().getSelectedObjects();
          ChangeFontCommand cfnc = new ChangeFontCommand(objects,
              jButtonFontBold.isSelected());
          lesson.commandManager.addEdit(cfnc);
          cfnc.redo();
          // set default font for object creation
          if (objects.size() == 0) {
            setLessonDefaultValues();
          }
        }
      }
    });

    jComboBoxFontList.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        if ( (lesson == null) || determiningFonts) {
          return;
        }
        if (lesson.getCurrentSlide() == null) {
          return;
        }
        if (!determiningFonts) {
          Vector objects = lesson.getCurrentSlide().getSelectedObjects();
          Font sf = (Font) jComboBoxFontList.getSelectedItem();
          ChangeFontCommand cfnc = new ChangeFontCommand(objects,
              sf.getName());
          lesson.commandManager.addEdit(cfnc);
          cfnc.redo();
          // set default font for object creation
          if (objects.size() == 0) {
            setLessonDefaultValues();
          }
        }
      }
    });

    jButtonFgColor.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        try {
          Color result = colorChooser.showDialog(null, "Set foreground color",
              jButtonFgColor.getBackground());
          if (result != null) {
            jButtonFgColor.setBackground(result);
            if (lesson != null) {
              if (lesson.getCurrentSlide() != null) {
                Vector objects = lesson.getCurrentSlide().getSelectedObjects();
                ChangeObjectColorCommand cocc = new ChangeObjectColorCommand(
                    objects,
                    ChangeObjectColorCommand.COLOR_FOREGROUND, result);
                lesson.commandManager.addEdit(cocc);
                if (objects.size() == 0) {
                  lesson.setDefaultFgColor(result);
                }
                cocc.redo();
              }
            }
          }
        } catch (NullPointerException ex) {}
        ;
      }
    });

    jButtonBgColor.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        try {
          Color result = colorChooser.showDialog(null, "Set background color",
              jButtonBgColor.getBackground());
          if (result != null) {
            jButtonBgColor.setBackground(result);
            if (lesson != null) {
              if (lesson.getCurrentSlide() != null) {
                Vector objects = lesson.getCurrentSlide().getSelectedObjects();
                ChangeObjectColorCommand cocc = new ChangeObjectColorCommand(
                    objects,
                    ChangeObjectColorCommand.COLOR_BACKGROUND, result);
                lesson.commandManager.addEdit(cocc);
                if (objects.size() == 0) {
                  lesson.setDefaultBgColor(result);
                }
                cocc.redo();
              }
            }
          }
        } catch (NullPointerException ex) {}
        ;
      }
    });

    jButtonArrowSelect.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        stateManager.setStateArrow();
      }
    });

    jComboBoxFontSize.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        if (determiningFonts || lesson == null) {
          return;
        }
        try {
          int size;
          Vector objects = lesson.getCurrentSlide().getSelectedObjects();
          try {
            size = new Float(jComboBoxFontSize.getSelectedItem().toString()).
                intValue();
            ChangeFontCommand cfsc = new ChangeFontCommand(objects, size);
            if (!determiningFonts) {
              lesson.commandManager.addEdit(cfsc);
              cfsc.redo();
              // set default font for object creation
              if (objects.size() == 0) {
                setLessonDefaultValues();
              }
            }
          } catch (NumberFormatException ex) {
          }
        } catch (Exception ex) {
          Utils.sprintln("Exception in setting font size: " +
              ex.getLocalizedMessage());
        }
      }
    });

    slideComboBox.addItemListener(new java.awt.event.ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        if (e.getStateChange() == e.SELECTED) {
          if (!slideComboBox.isRefreshing()) {
            lesson.goToSlide( ( (SlideListItem) e.getItem()).getSlideNum());
          }
        }
      }
    });
  }

  //Overridden so we can exit when window is closed
  protected void processWindowEvent(WindowEvent e) {
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      actionFileExit.actionPerformed(null);
    } else if (e.getID() == WindowEvent.WINDOW_ACTIVATED) {
      Utils.sprintln("Window activated");
      updateUIEdit();
    }
    ;
    if (e.getID() != WindowEvent.WINDOW_CLOSING) {
      super.processWindowEvent(e);
    }
  }

  protected void setSlide(Slide s) {
    clearSlideViewPort();
    if (s != null) {
      jScrollPaneSlide.getViewport().add(s, BorderLayout.CENTER);
    }
    jScrollPaneSlide.getViewport().updateUI();
  }

  protected void clearSlideViewPort() {
    jScrollPaneSlide.getViewport().removeAll();
  }

  protected void changeFontStyle(ActionEvent e, int styleConst) {
    Vector objects = lesson.getCurrentSlide().getSelectedObjects();
    Iterator i = objects.iterator();
    while (i.hasNext()) {
      JComponent o = (JComponent) i.next();
      if (o instanceof ITextObject) {
        Font oldFont = ( (ITextObject) o).getFont();
        int style = oldFont.getStyle();
        if ( ( (JToggleButton) e.getSource()).isSelected()) {
          style = style | styleConst;
        } else {
          style = style & ~styleConst;
        }
        Font newFont = new Font(oldFont.getName(), style, oldFont.getSize());
        ( (ITextObject) o).setFont(newFont);
      }
    }
  }

  protected void setLessonDefaultValues() {
    try {
      lesson.setDefaultFont(new Font( ( (Font) jComboBoxFontList.
          getSelectedItem()).getFontName(),
          (jButtonFontBold.isSelected()) ? (Font.BOLD) : (Font.PLAIN),
          new Integer(jComboBoxFontSize.getSelectedItem().toString()).
          intValue()));
      lesson.setDefaultBgColor(jButtonBgColor.getBackground());
      lesson.setDefaultFgColor(jButtonFgColor.getBackground());
    } catch (Exception e) {
    }
  }

  protected void changeTextAlignment() {
    Vector objects = lesson.getCurrentSlide().getSelectedObjects();
    Iterator i = objects.iterator();
    while (i.hasNext()) {
      JComponent o = (JComponent) i.next();
      if (o instanceof ITextObject) {
      }
    }
  }

  private void openLesson(String filename) {
    Lesson l;
    try {
      if (filename == null) {
        l = LessonFileUtils.getLessonFileUtils().openLesson();
      } else {
        l = LessonFileUtils.getLessonFileUtils().openLesson(filename);
      }
      if (l != null) {
        lesson = l;
        clearSlideViewPort();
        setSlide(lesson.getCurrentSlide());
        stateManager.setCanvas(lesson.getCurrentSlide());
        stateManager.setStateNull();
        lesson.commandManager.addUndoRedoListener(undoRedoListener);
        lesson.addSlideChangeListener(slideChangeListener);
        lesson.fireSlideChange();
        if (lesson.isDesignMode()) {
          actionViewDesignMode.actionPerformed(null);
        } else {
          actionViewViewMode.actionPerformed(null);
        }
        lesson.commandManager = new EventableUndoManager();
        addToRecentFiles(LessonFileUtils.getLessonFileUtils().currentFilename);
        setTitle(WINDOW_TITLE + " - " +
            LessonFileUtils.getLessonFileUtils().currentFilename);
        undoRedoListener.disableAllEdits();
        lesson.commandManager.addUndoRedoListener(undoRedoListener);
//          lesson.commandManager.addCommandListener(commandListener);
      }
    } catch (IOException ex) {
      Utils.sprintln(ex.getLocalizedMessage());
      JOptionPane.showMessageDialog(null, ex.getLocalizedMessage(),
          "Cannot open lesson", JOptionPane.ERROR_MESSAGE);
    }
  }

  private void updateUISlide() {
    boolean enable = false;
    try {
      if (lesson.getCurrentSlide() != null) {
        enable = true;
      }
    } catch (NullPointerException e) {}
    ;
    actionSlideRemoveSlide.setEnabled(enable);
    actionSlideChangeBackground.setEnabled(enable);
    actionSlideRenameSlide.setEnabled(enable);
    actionSlideSetAsDefault.setEnabled(enable);
    actionViewNextSlide.setEnabled(lesson.canGoToNextSlide());
    actionViewPrevSlide.setEnabled(lesson.canGoToPrevSlide());
    actionViewShowGrid.setEnabled(enable);
  }

  private void updateUIEdit() {
    boolean enable = false;
    try {
      if (lesson.getCurrentSlide().getSelectedObjects().size() > 0) {
        enable = true;
      }
    } catch (NullPointerException e) {}
    ;
    actionEditCopy.setEnabled(enable);
    actionEditCut.setEnabled(enable);
    actionEditDelete.setEnabled(enable);
  }

  private void updateUIMode() {
    boolean designMode = lesson.isDesignMode();

    // hides and disables functionality that should not used in view mode
    jMenuView.setVisible(true);
    if (designMode) {
      actionViewGoToSlide.setEnabled(true);
      actionViewPrevSlide.setEnabled(true);
      actionViewNextSlide.setEnabled(true);
    } else
    if (lesson.isEnableNavigation()) {
      actionViewGoToSlide.setEnabled(true);
      actionViewPrevSlide.setEnabled(true);
      actionViewNextSlide.setEnabled(true);
    } else {
      actionViewGoToSlide.setEnabled(false);
      actionViewPrevSlide.setEnabled(false);
      actionViewNextSlide.setEnabled(false);
    }
    statusBar.setVisible(designMode);
    actionFileSave.setEnabled(designMode);
    actionFileSaveAs.setEnabled(designMode);
    actionFileNew.setEnabled(designMode);
    actionFilePublish.setEnabled(designMode);
    actionEditUndo.setEnabled(designMode);
    actionEditRedo.setEnabled(designMode);
    actionEditCopy.setEnabled(designMode);
    actionEditCut.setEnabled(designMode);
    actionEditDelete.setEnabled(designMode);
    actionEditPaste.setEnabled(designMode);
    actionEditLessonProperties.setEnabled(designMode);
    actionSlideArrangeSlides.setEnabled(designMode);
    actionSlideRenameSlide.setEnabled(designMode);
    actionSlideNewSlide.setEnabled(designMode);
    actionSlideRemoveSlide.setEnabled(designMode);
    actionViewViewMode.setEnabled(designMode);
    actionViewDesignMode.setEnabled(!designMode);
    actionViewShowGrid.setEnabled(designMode);
    actionFileNew.setEnabled(designMode);
    actionFileSave.setEnabled(designMode);
    actionFileSaveAs.setEnabled(designMode);
    jButtonLessonNew.setVisible(designMode);
    jButtonLessonSave.setVisible(designMode);
    actionFilePublish.setEnabled(designMode);

    jMenuEdit.setVisible(designMode);
    jMenuSlide.setVisible(designMode);
    jToolBarEdit.setVisible(designMode);
    jToolBarFont.setVisible(designMode);
    jToolBarTools.setVisible(designMode);
    if (designMode) {
      mainPanel.remove(jScrollPaneSlide);
      mainPanel.add(jSplitPane1);
      jSplitPane1.add(jScrollPaneSlide, jSplitPane1.RIGHT);
      jSplitPane1.add(jPanelDesign, jSplitPane1.LEFT);
    } else {
      mainPanel.remove(jSplitPane1);
      mainPanel.add(jScrollPaneSlide, BorderLayout.CENTER);
    }
    mainPanel.updateUI();
    if (designMode) {
      updateUIEdit();
      updateUISlide();
    }
  }

  public static void main(String[] args) {
    Utils.sprintln("Starting designer ...");
    try {
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    } catch (Exception e) {
      e.printStackTrace();
    }
    Designer frame = new Designer();
    //Validate frames that have preset sizes
    //Pack frames that have useful preferred size info, e.g. from their layout
    frame.validate();
    //Center the window
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = frame.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    frame.setLocation( (screenSize.width - frameSize.width) / 2,
        (screenSize.height - frameSize.height) / 2);
    frame.setVisible(true);
  }

  public Designer getDesigner() {
    return this;
  }
}

/** Font combo box item renderer */
class FontNameRenderer extends JLabel implements ListCellRenderer {
  public FontNameRenderer() {
    setOpaque(true);
  }

  public Component getListCellRendererComponent(JList list,
      Object value,
      int index,
      boolean isSelected,
      boolean cellHasFocus) {

    if (value instanceof Font) {
      setText( ( (Font) value).getFontName());
    } else {
      setText(value.toString());
    }

    if (isSelected) {
      setBackground(list.getSelectionBackground());
      setForeground(list.getSelectionForeground());
    } else {
      setBackground(list.getBackground());
      setForeground(list.getForeground());
    }
    return this;
  }
}
