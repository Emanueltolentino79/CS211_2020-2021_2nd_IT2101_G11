/**
 * <p>Title: LQuizReport</p>
 * <p>Description: Object for displaying and posting quiz results</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

import java.util.*;
import java.net.*;
import java.io.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import sk.lomo.elearning.Utils;
import sk.lomo.elearning.core.*;
import sk.lomo.elearning.core.interfaces.*;
import sk.lomo.elearning.core.ui.*;
import sk.lomo.elearning.core.ui.dialogs.*;

/** Object for displaying and posting quiz results */

public class LQuizReport extends LAbstractButton implements IVisible,
    IAction, ITrigger {
  /** menu icon */
  private Icon iconReportProperties = Library.getGraphics(
      "LQuizReportMenuQuizReportProperties.gif");
  /** true if button is visible in view mode */
  private boolean buttonVisible = true;
  /** true if results shoud be shown automatically when entering slide */
  private boolean showResultsAutomatically = false;
  /** true if results shoud be shown when clicked */
  private boolean showResultsWhenClicked = true;
  /** true if results shoud be posted */
  private boolean shouldPostResults = false;
  /** true results post url */
  private URL resultsPostUrl;
  /** true if gained result score shoud be posted */
  private boolean shouldPostGained = true;
  /** true if maximum result score shoud be posted */
  private boolean shouldPostMax = true;
  /** true if minimum result score shoud be posted */
  private boolean shouldPostMin = true;
  /** true if question's result shoud be posted */
  private boolean shouldPostQuestions = true;
  /** name of gained score post field */
  private String postGainedName = "gained";
  /** name of maximal score post field */
  private String postMaximumName = "maximum";
  /** name of minimum score post field */
  private String postMinimumName = "minimum";
  /** name of questions post field */
  private String postQuestionsName = "questions";


  /** trigger manager for this trigger */
  private TriggerManager triggerManager = new TriggerManager();

  /** Creates object */
  public LQuizReport() {
    addActionListener(new sk.lomo.elearning.core.event.ActionAdapter() {
      public void actionPerformed(ActionEvent e) {
        action();
      }
    });
    setText("Show quiz results");
  }

  /** @return true if object should be placed in object library */
  public boolean isLibraryObject() {
    return true;
  }

  /** @return category name in object library */
  public String getDisplayCategory() {
    return "Quiz";
  }

  /** @return object name in object library */
  public String getDisplayName() {
    return "Quiz resultz";
  }

  /** @return object icon on object library and menus */
  public Icon getRepositoryIcon() {
    return objectHelper.getRepositoryIcon();
  }

  /** @return object context menu items */
  public JMenuItem[] getMenuItems() {
    JMenuItem[] itemsSuper = super.getMenuItems();
    JMenuItem[] items = new JMenuItem[itemsSuper.length + 1];
    for (int i = 0; i < itemsSuper.length; i++) {
      items[i] = itemsSuper[i];
    }
    int fidx = itemsSuper.length;
    items[fidx] = new JMenuItem("Report properties");
    items[fidx].setIcon(iconReportProperties);
    items[fidx].addActionListener(new sk.lomo.elearning.core.event.ActionAdapter() {
      public void actionPerformed(ActionEvent e) {
        QuizReportPropertiesDialog dlg = new QuizReportPropertiesDialog();
        dlg.setTitle("Report properties");
        Dimension dlgSize = dlg.getPreferredSize();
        Dimension frmSize = Toolkit.getDefaultToolkit().getScreenSize();
        dlg.setLocation( (frmSize.width - dlgSize.width) / 2,
            (frmSize.height - dlgSize.height) / 2);
        dlg.setModal(true);
        dlg.setResizable(false);
        dlg.pack();
        dlg.setButtonVisible(buttonVisible);
        dlg.setShowResultsAutomatically(showResultsAutomatically);
        dlg.setShowResultsWhenClicked(showResultsWhenClicked);
        dlg.setShouldPostResults(shouldPostResults);

        dlg.setPostUrl(resultsPostUrl);
        dlg.setPostGained(shouldPostGained);
        dlg.setPostMax(shouldPostMax);
        dlg.setPostMin(shouldPostMin);
        dlg.setPostQuestion(shouldPostQuestions);
        dlg.setPostGainedName(postGainedName);
        dlg.setPostMaxName(postMaximumName);
        dlg.setPostMinName(postMinimumName);
        dlg.setPostQuestionName(postQuestionsName);

        dlg.show();
        if (dlg.result == JOptionPane.OK_OPTION) {
          buttonVisible = dlg.isButtonVisible();
          showResultsAutomatically = dlg.showResultsAutomatically();
          showResultsWhenClicked = dlg.showResultsWhenClicked();
          resultsPostUrl = dlg.getPostUrl();
          shouldPostResults = dlg.shouldPostResults();

          shouldPostGained = dlg.isPostGained();
          shouldPostMax = dlg.isPostMax();
          shouldPostMin = dlg.isPostMin();
          shouldPostQuestions = dlg.isPostQuestion();

          postGainedName = dlg.getPostGainedName();
          postMaximumName = dlg.getPostMaxName();
          postMinimumName = dlg.getPostMinName();
          postQuestionsName = dlg.getPostQuestionName();

          triggerManager.removeAllActions();
          if (showResultsAutomatically) {

            triggerManager.putAction(new TriggerAction(getThis(),
                TriggerAction.ACTION_TRIGGER));
          }

        }
      }
    });
    return items;
  }

      /** @return current instance of this object, foolish method for inner class */
  public JComponent getThis() {
    return this;
  }

  /** overrides component's isVisible method to allow object to hide
   * itself in view mode
   * @return true if object is visible */
  public boolean isVisible() {
    if (isDesignMode()) {
      return true;
    } else {
      return buttonVisible;
    }
  }

  /** Triggers object action */
  public void action() {
    StringBuffer result = new StringBuffer();

    double maximalScore = 0.0;
    double score = 0.0;
    double minimumScore = 0.0;

    Lesson l = ( (Slide)this.getParent()).getLesson();
    for (int i = 0; i < l.getSlidesCount(); i++) {
      Slide s = l.getSlide(i);
      Iterator j = s.getQuestions().iterator();
      while (j.hasNext()) {
        IQuestion q = (IQuestion) j.next();
        Utils.sprintln("Calculating question "+q.getText());
        score = score + q.calculateScore();
        maximalScore = maximalScore + q.getHiScore();
        minimumScore = minimumScore + q.getLoScore();
        result.append(q.getText() + " " + q.calculateScore()+"\n");
      }
    }

    String postData = "";
    try {
      if (shouldPostGained)
        postData += postGainedName+"="+URLEncoder.encode(Double.toString(score), "UTF-8");
      if (shouldPostMax) {
        if (postData!="") postData += "&";
        postData += postMaximumName+"="+URLEncoder.encode(Double.toString(maximalScore), "UTF-8");
      }
      if (shouldPostMin) {
        if (postData!="") postData += "&";
        postData += postMinimumName+"="+URLEncoder.encode(Double.toString(minimumScore), "UTF-8");
      }
      if (shouldPostQuestions) {
        if (postData!="") postData += "&";
        postData += postQuestionsName+"="+URLEncoder.encode(result.toString(), "UTF-8");
      }
    } catch (IOException ex) {

    };
    if (shouldPostResults) Utils.httpPostData(resultsPostUrl, postData);

    QuizReportDialog dlg = new QuizReportDialog(score, maximalScore, minimumScore,
        result.toString());
    Dimension dlgSize = dlg.getPreferredSize();
    Dimension frmSize = Toolkit.getDefaultToolkit().getScreenSize();
    dlg.setLocation( (frmSize.width - dlgSize.width) / 2,
        (frmSize.height - dlgSize.height) / 2);
    dlg.setModal(true);
    dlg.pack();
    dlg.show();

  }

  /** Fires trigger actions */
  public void triggerActions() {
    action();
  }

  /** @return true if trigger should be fired after entering slide */
  public boolean isTriggerOnSlideEnter() {
    return showResultsAutomatically;
  }

  /** @param trigger true if trigger should be fired after entering slide */
  public void setTriggerOnSlideEnter(boolean trigger) {}

  /** Removes all TriggerActions with given action object
   * @param object object to remove TriggerActions of */
  public void removeActionObject(JComponent object) {
    triggerManager.removeActionObject(object);
  }
  /** @return trigger actions for object
   * @param object action object */
  public TriggerAction[] getTriggerActions(javax.swing.JComponent object) {
    return triggerManager.getTriggerActions(object);
  }
  /** @return all trigger actions for object */
  public TriggerAction[] getTriggerActions() {
    return triggerManager.getTriggerActions();
  }
  /** @param object action object to query
   * @return true if trigger has this action object */
  public boolean hasActionObject(JComponent object) {
    return triggerManager.hasActionObject(object);
  }
  /** removes TriggerActions on non-existent object */
  public void removeUnparentedObjectActions() {
    triggerManager.removeUnparentedObjectActions();
  }
  /** Inserts TriggerAction into list
   * @param action action to insert */
  public void putAction(TriggerAction action) {
    // we don't allow to insert anything from outside world
  }

  /** @return action specific name */
  public String getActionName() { return "Show quiz results"; }

}
