/**
 * <p>Title: LQuestion </p>
 * <p>Description: Basic question object</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.util.*;

import javax.swing.*;

import sk.lomo.elearning.core.event.*;
import sk.lomo.elearning.core.interfaces.*;

/** Basic question object */

public class LQuestion extends LText implements IVisible, ITextObject, IQuestion {
  /** Button group for single selection */
  private ButtonGroup singleChoiceGroup = new ButtonGroup();
  /** true if object is scorable */
  private boolean scorable;
  /** highest and lowest gained score for this question */
  private int hiScore = 1, loScore = 0;
  /** true if object is a single choice question */
  private boolean singleChoice;
  /** answers bound to this question */
  private Vector answers = new Vector();
  /** Creates object */
  public LQuestion() {
    super();
    setScorable(true);
  }

  /** @return object context menu items */
  public JMenuItem[] getMenuItems() {
    JMenuItem[] itemsSuper = super.getMenuItems();
    JMenuItem[] items = new JMenuItem[itemsSuper.length + 1];
    for (int i = 0; i < itemsSuper.length; i++) {
      items[i] = itemsSuper[i];
    }
    int fidx = itemsSuper.length;

    items[fidx] = new JMenuItem("Question properties");
    items[fidx].addActionListener(new QuestionPropertiesListener(this));

    return items;
  }

  /** @return this instance, foolish method for inner class */
  public IQuestion getQuestion() {
    return this;
  }

  /** @return object name in object library */
  public String getDisplayName() {
    return "Question";
  };
  /** @return category name in object library */
  public String getDisplayCategory() {
    return "Quiz";
  };
  /** @return object icon on object library and menus */
  public Icon getRepositoryIcon() {
    return objectHelper.getRepositoryIcon();
  }

  /** @return question highest score */
  public int getHiScore() {
    return this.hiScore;
  }

  /** Sets question highest score
   * @param score highest score */
  public void setHiScore(int score) {
    this.hiScore = score;
  }

  /** @return question lowest score */
  public int getLoScore() {
    return this.loScore;
  }

  /** @param score true to set question to scorable */
  public void setLoScore(int score) {
    this.loScore = score;
  }

  public boolean isScorable() {
    return this.scorable;
  }

  /** Sets the question to be scored or not
   * @param scorable true if question is scorable */
  public void setScorable(boolean scorable) {
    this.scorable = scorable;
  }

  /** @return calculates the question score */
  public float calculateScore() {
    float score = 0;
    Iterator i = answers.iterator();
    while (i.hasNext()) {
      score = score + ( (IAnswer) i.next()).calculateScore();
    }
    if (score > 100) {
      score = 100;
    }
    float ratio = (float) score / 100;
    return (ratio * (getHiScore() - getLoScore())) + getLoScore();
  }

  /** Adds an answer to this question
   * @param answer answer to be added */
  public void addAnswer(IAnswer answer) {
    if (!answers.contains(answer)) {
      answers.add(answer);
      if ((answer instanceof AbstractButton) && isSingleChoice())
        singleChoiceGroup.add((AbstractButton) answer);
    }
  }

  /** Removes an answer from this question
   * @param answer answer to be removed */
  public void removeAnswer(IAnswer answer) {
    if (answer instanceof AbstractButton)
      singleChoiceGroup.remove((AbstractButton) answer);
    answers.remove(answer);
  }

  /** @return true if answer belongs to this question
   * @param answer answer to ask about */
  public boolean hasAnswer(IAnswer answer) {
    return answers.contains(answer);
  }

  /** @return Vector of object answers */
  public Vector getAnswers() {
    return answers;
  }

  /** @return true if question is a single choice question */
  public boolean isSingleChoice() {
    return singleChoice;
  }

  /** Set question behavior to a single choice question
   * @param single true if question should be single choice question */
  public void setSingleChoice(boolean single) {
    this.singleChoice = single;
    Iterator i = answers.iterator();
    while (i.hasNext()) {
      JComponent answer = (JComponent) i.next();
      if (answer instanceof AbstractButton) {
        if (single) singleChoiceGroup.add((AbstractButton) answer);
          else singleChoiceGroup.remove((AbstractButton) answer);
      }
    }
    singleChoiceGroup.setSelected(new DefaultButtonModel(), false);
  }

  /** invoked when object is placend onto slide */
  public void objectPlacement() {
    setText("Question");
  };


}
