/**
 * <p>Title: LNavigation </p>
 * <p>Description: Common navigation button</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import javax.swing.*;

import sk.lomo.elearning.core.*;
import sk.lomo.elearning.core.event.*;

/** Common navigation button. */

public class LNavigation extends LHyperlinkButton {
  /** Creates object */
  public LNavigation() {
    setText("Navigation");
    setHyperlink(new Hyperlink(Hyperlink.HYPERLINK_FIRSTSLIDE));
    addActionListener(
        new NavigationActionListener(getHyperlink())
        );
  }

  /** @return true if object should be placet into library */
  public boolean isLibraryObject() {
    return true;
  }

  /** @return icon representing this object */
  public Icon getRepositoryIcon() {
    return objectHelper.getRepositoryIcon();
  }

  /** @return name to display in library */
  public String getDisplayName() {
    return "Common navigation";
  }

  /** @return category to display in library */
  public String getDisplayCategory() {
    return "Nav";
  }
}
