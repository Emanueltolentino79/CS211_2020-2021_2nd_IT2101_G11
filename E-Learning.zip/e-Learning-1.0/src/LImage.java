/**
 * <p>Title: LImage</p>
 * <p>Description: Object for displaying images</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.io.*;

import java.net.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.filechooser.FileFilter;

import sk.lomo.elearning.Utils;
import sk.lomo.elearning.core.*;
import sk.lomo.elearning.core.interfaces.*;

/** Object for displaying images. */

class ImageFilenameFilter extends FileFilter {
  public boolean accept(File pathname) {
    if (pathname.isDirectory()) {
      return true;
    }
    if (pathname.getName().toLowerCase().endsWith(".jpg")) {
      return true;
    }
    if (pathname.getName().toLowerCase().endsWith(".jpeg")) {
      return true;
    }
    if (pathname.getName().toLowerCase().endsWith(".gif")) {
      return true;
    }
    if (pathname.getName().toLowerCase().endsWith(".png")) {
      return true;
    }
    return false;
  }

  public String getDescription() {
    return "Image files";
  }
}

/** Object for displaying images */

public class LImage extends LObject implements IVisible {
  /** icon to display in context menu */
  private Icon iconImageOpen = Library.getGraphics("LImageImageOpen.gif");
  /** icon to display in context menu */
  private Icon iconImageClear = Library.getGraphics("LImageImageClear.gif");
  /** image to display */
  private transient ImageIcon image;
  /** image data */
  private byte[] imageData;
  /** Crates object */
  public LImage() {
    this.setFocusable(false);
  }

  /** @return default size for this object */
  public Dimension getDefaultSize() {
    return new Dimension(100, 100);
  }

  /** @return name to display in library */
  public String getDisplayName() {
    return "Image";
  };
  /** @return category to display in library */
  public String getDisplayCategory() {
    return "Basic";
  };
  /** loads image from imageData
   * @param setSize true if size has to be set */
  public void loadImageData(boolean setSize) {
    image = new ImageIcon(imageData);
    int iw = image.getIconWidth();
    int ih = image.getIconHeight();
    int iar = iw / ih;

    if (setSize)  {
      if ( (getWidth() / getHeight()) > 1) {
        setSize( (int) (getHeight() * iar), getHeight());
      } else {
        setSize(getWidth(), (int) (getWidth() / iar));
      }
    }

  }

  /** loads image from disk */
  protected void loadImage() {
    JFileChooser jfc = new JFileChooser();
    ImageFilenameFilter iff = new ImageFilenameFilter();
    jfc.setFileFilter(iff);
    if (jfc.showOpenDialog(this) == jfc.APPROVE_OPTION) {
      try {
        URL url = new URL("file:" + jfc.getSelectedFile().getAbsoluteFile());

        Utils.sprintln("Opening image " + url.toString());
        Utils.sprintln("Opening connection");
        imageData = new byte[(int) jfc.getSelectedFile().length()];
        url.openConnection();
        Utils.sprintln("Opening stream");
        BufferedInputStream bis = new BufferedInputStream(url.openStream());
        int readed = bis.read(imageData);
        loadImageData(true);
      } catch (MalformedURLException ex) {
        Utils.sprintln("Malformed URL");
      } catch (IOException ex) {
        Utils.sprintln(ex.getLocalizedMessage());
      }
    }
  }

  /** @return true if object should be placet into library */
  public boolean isLibraryObject() {
    return true;
  };
  /** overriden to paint image
   * @param g Graphics to paint to   */
  public void paint(Graphics g) {
    try {
      if (image==null) loadImageData(false);

        g.drawImage(image.getImage(), 0,
            0, getWidth(), getHeight(), Color.white, null);
    } catch (Exception e) {
      g.setColor(Color.red);
      g.drawLine(0, 0, getWidth(), getHeight());
      g.drawLine(0, getHeight(), getWidth(), 0);
    };
    if (isDesignMode()) {
      if (isObjectSelected()) {
        objectHelper.getResizeBorder().paintBorder(this, g, 0, 0, getWidth(),
            getHeight());
      }
    }
  }

  /** @return context menu for this object */
  public JMenuItem[] getMenuItems() {
    JMenuItem[] items = new JMenuItem[2];
    items[0] = new JMenuItem("Load Image");
    items[0].setIcon(iconImageOpen);
    items[0].addActionListener(new sk.lomo.elearning.core.event.ActionAdapter() {
      public void actionPerformed(ActionEvent e) {
        loadImage();
        repaint();
      }
    });
    items[1] = new JMenuItem("Clear Image");
    items[1].setIcon(iconImageClear);
    items[1].addActionListener(new sk.lomo.elearning.core.event.ActionAdapter() {
      public void actionPerformed(ActionEvent e) {
        image = null;
        repaint();
      }
    });
    return items;
  }

  /** Load image after dropping object onto slide */
  public void objectPlacement() {
    loadImage();
  };
}
