
/**
 * <p>Title: LMultipleChoiceAnswer</p>
 * <p>Description: A checkbox answer type</p>
 * <p>Author: Julius Loman</p>
 * @version 1.0
 */


import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;
import javax.swing.*;

import sk.lomo.elearning.core.*;
import sk.lomo.elearning.core.event.*;
import sk.lomo.elearning.core.interfaces.*;
import sk.lomo.elearning.core.ui.*;

/** A checkbox answer type */

public class LChoiceAnswer extends JCheckBox implements ITextObject, IAnswer {
  /** Embedded object to implement basic IObject functionality */
  private ObjectUtils objectUtils = new ObjectUtils(this);
  /** icon for context menu */
  private Icon iconText = Library.getGraphics("LChoiceAnswerMenuText.gif");
  /** icon for context menu */
  private Icon iconMenuAnswerWeight = sk.lomo.elearning.Utils.getGraphics(
      "MenuAnswerWeight.gif");
  /** answer weight */
  private int weight;
  /** old button model */
  private ButtonModel oldModel;
  /** true if object is already initiated and placed */
  private boolean initiated = false;

  public LChoiceAnswer() {
    setCursor(Cursor.getDefaultCursor());
    setText("Answer");
    setOpaque(false);
    setDoubleBuffered(true);
//    setRequestFocusEnabled(false);
    oldModel = getModel();
  }
  /** @return default size for this object */
  public Dimension getDefaultSize() {
    return new Dimension(120,20);
  }

  /** @return object border used for resizing and object selection */
  public ResizeBorder getResizeBorder() { return objectUtils.getResizeBorder(); }

  /** @return default object cursor */
  public Cursor getObjectCursor() {
    return Cursor.getDefaultCursor();
  }

  /** @return object context menu items */
  public JMenuItem[] getMenuItems() {
    JMenuItem[] items = new JMenuItem[3];

    items[0] = new AnswerToQuestionMenu(this);

    items[1]= new JMenuItem("Answer weight");
    items[1].setIcon(iconMenuAnswerWeight);
    items[1].addActionListener(new AnswerWeightListener(this));

    items[2] = new JMenuItem("Set text");
    items[2].setIcon(iconText);
    items[2].addActionListener(new sk.lomo.elearning.core.event.ActionAdapter() {
          public void actionPerformed(ActionEvent e) {
            String newText = JOptionPane.showInputDialog("Answer text", getText());
            if (newText != null) {
              setText(newText);
            }
          }
        });
    return items;
  }

  /** Sets the object selection behavior
   * @param selected true if object should be selected */
  public void setObjectSelected(boolean selected) {
    objectUtils.setSelected(selected);
  }

  /** @return true if object has selected behavior */
  public boolean isObjectSelected() {
      return objectUtils.isSelected();
  };

  public boolean isLibraryObject() {
    return true;
  }

  public void paint(Graphics g) {
    super.paint(g);
    if (isDesignMode()) {
      if (isObjectSelected()) objectUtils.getResizeBorder().paintBorder(this,g,0,0,getWidth(),getHeight());
    }
  }
  /** @return category to display in library */
  public String getDisplayCategory() { return "Quiz"; }
  /** @return name to display in library */
  public String getDisplayName() { return "Choice answer"; }
  /** @return object icon on object library and menus */
  public Icon getRepositoryIcon() { return objectUtils.getRepositoryIcon(); }
  /** Set object behavior into design mode
   * @param designMode selects design or view mode */
  public void setDesignMode(boolean designMode) {
    if (designMode!=isDesignMode()) {
      objectUtils.setDesignMode(designMode);
      if (designMode) {
        setFocusable(false);
        DefaultButtonModel bm = new LButtonModel(this);
        bm.setGroup(((DefaultButtonModel) getModel()).getGroup());
        setModel(bm);
      } else {
        setFocusable(true);
        oldModel.setGroup(((DefaultButtonModel) getModel()).getGroup());
        setModel(oldModel);
      }
    }
  }
  /** @return true if object is in design mode */
  public boolean isDesignMode() { return objectUtils.isDesignMode(); }
  /** @return Answer weight (percentage). */
  public int getWeight() { return weight; }
  /** Sets the answer weight (percentage).
   * @param weight answer weight */
  public void setWeight(int weight) { this.weight = weight; }
  /** Calculates score
   * @return score in percentage */
  public float calculateScore() {
      if (isSelected()) return weight;
      else return 0;
  }
  /** Method to be called after object is placed on a slide */
  public void objectPlacement() {
    initiated = true;
  };
  /** overriden for set preferred size */
  public void setText(String text) {
    super.setText(text);
    setSize(getPreferredSize());
  }

  /** overriden for set preferred size */
  public void setFont(Font font) {
    super.setFont(font);
    if (initiated) {
      try {
        setSize(getPreferredSize());
      } catch (Exception ignored) {}
      ;
    }
  }
}
