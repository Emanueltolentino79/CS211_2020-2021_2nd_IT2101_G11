/**
 * <p>Title: LHyperlinkButton</p>
 * <p>Description: Abstract Button implementing hyperlink</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import sk.lomo.elearning.core.*;
import sk.lomo.elearning.core.interfaces.*;
import sk.lomo.elearning.core.ui.*;
import sk.lomo.elearning.core.ui.dialogs.*;

/** Abstract Button implementing hyperlink. */

public abstract class LHyperlinkButton extends LAbstractButton implements
    IHyperlink {
  /** embedded hyperlink */
  private Hyperlink hyperlink = new Hyperlink(Hyperlink.HYPERLINK_NONE);
  /** Menu icon to display in context menu*/
  private Icon iconHyperLink = sk.lomo.elearning.Utils.getGraphics(
      "MenuHyperlink.gif");
  /** @return embedded hyperlink */
  public Hyperlink getHyperlink() {
    return this.hyperlink;
  }

  /** sets embedded hyperlink
   * @param hyperlink new hyperlink */
  public void setHyperlink(Hyperlink hyperlink) {
    this.hyperlink = hyperlink;
  }

  /** @return context menu for this object */
  public JMenuItem[] getMenuItems() {
    JMenuItem[] itemsSuper = super.getMenuItems();
    JMenuItem[] items = new JMenuItem[itemsSuper.length + 1];
    for (int i = 0; i < itemsSuper.length; i++) {
      items[i] = itemsSuper[i];
    }
    int fidx = itemsSuper.length;
    items[fidx] = new JMenuItem("Hyperlink");
    items[fidx].setIcon(iconHyperLink);
    items[fidx].addActionListener(new sk.lomo.elearning.core.event.ActionAdapter() {
      public void actionPerformed(ActionEvent e) {
        if (! (getParent()instanceof Slide)) {
          return;
        }
        HyperlinkDialog hld = new HyperlinkDialog(getHyperlink(),
            ( (Slide) getParent()).getLesson());
        Dimension dlgSize = hld.getPreferredSize();
        Dimension frmSize = Toolkit.getDefaultToolkit().getScreenSize();
        hld.setLocation( (frmSize.width - dlgSize.width) / 2,
            (frmSize.height - dlgSize.height) / 2);
        hld.setModal(true);
        hld.pack();
        hld.show();
        setHyperlink(hld.getHyperlink());
      }
    });
    return items;
  }
}
