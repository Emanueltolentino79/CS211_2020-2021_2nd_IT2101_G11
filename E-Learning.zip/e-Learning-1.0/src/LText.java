/**
 * <p>Title: LText</p>
 * <p>Description: Object for displaying text in lesson</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import sk.lomo.elearning.core.*;
import sk.lomo.elearning.core.commands.TextEditCommand;
import sk.lomo.elearning.core.interfaces.*;
import sk.lomo.elearning.core.ui.*;
import sk.lomo.elearning.core.event.*;
import sk.lomo.elearning.core.ui.dialogs.*;

/** Object for displaying text in lesson. */

public class LText extends JComponent implements IVisible, ITextObject {
  /** object utils */
  protected ObjectUtils objectHelper = new ObjectUtils(this);
  /** context menu icon */
  private Icon iconEdit = Library.getGraphics("LTextMenuEdit.gif");
  /** text to display */
  private String text = "";
  /** true if text was edited already */
  private boolean edited = false;
  /** helper to draw text and resize to pref. size */
  private transient JTextArea jta;

  /** Creates object */
  public LText() {
    super();
    setFocusable(false);
    setCursor(Cursor.getDefaultCursor());
    setOpaque(false);
    setDoubleBuffered(true);
//    setText("Right click to edit text");
    setSize(getPreferredSize());
    addMouseListener(new SMouseAdapter() {
      public void mousePressed(MouseEvent e) {
        if (isDesignMode() && (e.getClickCount()==2)) editText();
      }
    });
  }

  /** Create JTextArea used to display text. */
  private void createJTA() {
    if (jta==null) jta = new JTextArea();
    jta.setLineWrap(true);
    jta.setSize(getSize());
    jta.setFont(getFont());
    jta.setText(getText());
    jta.setForeground(getForeground());
    jta.setOpaque(false);
    jta.setWrapStyleWord(true);
  }

  /** show edit dialog and edit text */
  public void editText() {
    String tte;
    if (edited)
      tte = getText();
    else
      tte = "";
    TextEditDialog ted = new TextEditDialog(tte, getFont());
    Dimension dlgSize = ted.getPreferredSize();
    Dimension frmSize = Toolkit.getDefaultToolkit().getScreenSize();
    ted.setLocation( (frmSize.width - dlgSize.width) / 2,
        (frmSize.height - dlgSize.height) / 2);
    ted.setModal(true);
    ted.pack();
    ted.show();

    if (ted.getResult() == JOptionPane.OK_OPTION) {
      TextEditCommand tec = new TextEditCommand(getThis(), getText(),
          ted.getEditedText(), getFont(), ted.getEditedFont());
      edited = true;
      tec.redo();
      setSize(getPreferredSize());
      if (getParent()instanceof Slide) {
        ( (Slide) getParent()).fireSlideSelectionChange();
        ( (Slide) getParent()).getLesson().commandManager.addEdit(tec);
      }
    }
  }

  /** @return default size for this object */
  public Dimension getDefaultSize() {
    return getPreferredSize();
  }

  /** @return preferred size for object */
  public Dimension getPreferredSize() {
    createJTA();
    try {
      Dimension ps = jta.getPreferredSize();
      if (ps.getWidth()<8) ps.setSize(8,ps.getHeight());
      if (ps.getHeight()<8) ps.setSize(ps.getWidth(), 8);
      return ps;
    } catch (Exception e) {
      return getSize();
    }
  }

  /** @return name to display in library */
  public String getDisplayName() {
    return "Text";
  }

  /** @return category to display in library */
  public String getDisplayCategory() {
    return "Basic";
  }

  /** @return icon representing this object */
  public Icon getRepositoryIcon() {
    return objectHelper.getRepositoryIcon();
  }

  /** @param designMode true if object should be set to design mode */
  public void setDesignMode(boolean designMode) {
    objectHelper.setDesignMode(designMode);
  }

  /** @return true if object is in design mode */
  public boolean isDesignMode() {
    return objectHelper.isDesignMode();
  }

  /** @param selected true if object should be selected */
  public void setObjectSelected(boolean selected) {
    objectHelper.setSelected(selected);
  }

  /** @return border user for resizing and moving object */
  public ResizeBorder getResizeBorder() {
    return objectHelper.getResizeBorder();
  }

  /** @return true if object is selected  */
  public boolean isObjectSelected() {
    return objectHelper.isSelected();
  };
  /** @return true if object is a library object */
  public boolean isLibraryObject() {
    return true;
  };

  /** paint object
   * @param g graphics to paint to */
  public void paint(Graphics g) {
    super.paint(g);

    createJTA();
    jta.paint(g);

    if (isDesignMode()) {
      if (isObjectSelected()) {
        objectHelper.getResizeBorder().paintBorder(this, g, 0, 0, getWidth(),
            getHeight());
      }
    }
  }

  /** @return context menu items for this object */
  public JMenuItem[] getMenuItems() {
    JMenuItem[] items = new JMenuItem[1];
    items[0] = new JMenuItem("Edit text");
    items[0].setIcon(iconEdit);
    items[0].addActionListener(new sk.lomo.elearning.core.event.ActionAdapter() {
      public void actionPerformed(ActionEvent e) {
        editText();
      }
    });

    return items;
  }

  /** @return default object cursor */
  public Cursor getObjectCursor() {
    return new Cursor(Cursor.TEXT_CURSOR);
  }

  /** invoked when object is placend onto slide */
  public void objectPlacement() {
    setText("Insert text");
  };

  /** overriden because of bad deserialization
   * @param value thrown away anyway */
  public void setOpaque(boolean value) {
  }

  /** overridden because of bad deserialization
   * @return tooltip text */
  public String getToolTipText() {
    if (objectHelper != null) {
      if (isDesignMode()) {
        return super.getToolTipText();
      }
    }
    return "";
  }

  /** overriden to allow resize when changing font
   * @param font font to set */
  public void setFont(Font font) {
    super.setFont(font);
    createJTA();
    setSize(getPreferredSize());
    repaint();
  }

  /** fool method for inner class
   * @return this instance */
  public LText getThis() { return this; }

  /** @return text displayed */
  public String getText() { return text; }

  /** Sets text to display
   * @param t text to be displayed */
  public void setText(String t) {
    if (!text.equals(t)) {
      text = t;
      setSize(getPreferredSize());
      repaint();
    }
  }
}
