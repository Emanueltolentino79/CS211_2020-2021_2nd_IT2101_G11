/**
 * <p>Title: LButtonTrigger</p>
 * <p>Description: Class adding ITrigger functionality to a LAbstractButton.</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import sk.lomo.elearning.core.interfaces.*;
import sk.lomo.elearning.core.ui.*;
import sk.lomo.elearning.core.*;
import sk.lomo.elearning.core.ui.dialogs.*;

/** Class adding ITrigger functionality to a LAbstractButton.*/

public class LButtonTrigger extends LAbstractButton implements ITrigger {
  /** trigger parameters */
  private boolean triggerWhenClicked = true;
  /** Trigger manager for this trigger object */
  private TriggerManager triggerManager = new TriggerManager();
  /** icon to display in menu */
  private Icon iconTrigger = sk.lomo.elearning.Utils.getGraphics(
      "MenuTrigger.gif");
  /** Creates object */
  public LButtonTrigger() {
    setText("Trigger");
    triggerManager.setTriggerOnSlideEnter(false);
    addActionListener(new sk.lomo.elearning.core.event.ActionAdapter() {
      public void actionPerformed(java.awt.event.ActionEvent e) {
        triggerActions();
      }
    });
  }

  /* @return true if object should be placed in object repository */
  public boolean isLibraryObject() {
    return true;
  }

  /** @return name to display in library */
  public String getDisplayName() {
    return "Action trigger";
  }

  /** @return category to display in library */
  public String getDisplayCategory() {
    return "Basic";
  };
  /** @return context menu for this object */
  public JMenuItem[] getMenuItems() {
    JMenuItem[] itemsSuper = super.getMenuItems();
    JMenuItem[] items = new JMenuItem[itemsSuper.length + 1];

      for (int i = 0; i < itemsSuper.length; i++) {
      items[i] = itemsSuper[i];
    }
    int fidx = itemsSuper.length;
    items[fidx] = new JMenuItem("Trigger properties");
    items[fidx].setIcon(iconTrigger);
    items[fidx].addActionListener(new sk.lomo.elearning.core.event.ActionAdapter(){


        public void actionPerformed(ActionEvent e) {
      JCheckBox optionTriggerWhenClicked = new JCheckBox("Trigger when clicked",
          isTriggerWhenClicked());

      TriggerDialog dlg = new TriggerDialog(getThis());
      Dimension dlgSize = dlg.getPreferredSize();
      Dimension frmSize = Toolkit.getDefaultToolkit().getScreenSize();

      dlg.setLocation( (frmSize.width - dlgSize.width) / 2,
          (frmSize.height - dlgSize.height) / 2);
      dlg.setModal(true);

      dlg.setTriggerActions(getAllActions());

      dlg.getOptionPanel().add(optionTriggerWhenClicked);
      dlg.pack();
      dlg.show();

      if (dlg.getOption() == JOptionPane.OK_OPTION) {
        setTriggerOnSlideEnter(dlg.jCheckBoxTriggerSlideEnter.isSelected());
        setTriggerWhenClicked(optionTriggerWhenClicked.isSelected());
        setAllActions(dlg.getTriggerActions());
      }
    }

    });
    return items;
  }
  /** @return this instance for inner classes */
  public ITrigger getThis() {
    return this;
  }

  /** Fires trigger actions */
  public void triggerActions() {
    if (!isDesignMode()) {
      triggerManager.doActions();
    }
  }

  /** @return all trigger actions */
  public TriggerAction[] getAllActions() {
    return triggerManager.getTriggerActions();
  }

  /** Sets trigger actions
   * @param ta trigger actions to set */
  public void setAllActions(TriggerAction[] ta) {
    triggerManager.setAllActions(ta);
  }

  /** @param object action object to remove (was probably removed from project) */
  public void removeActionObject(javax.swing.JComponent object) {
    triggerManager.removeActionObject(object);
  }

  /** @return true if trigger should be fired after entering slide */
  public boolean isTriggerOnSlideEnter() {
    return triggerManager.isTriggerOnSlideEnter();
  }

  /** @param trigger true if trigger should be fired after entering slide */
  public void setTriggerOnSlideEnter(boolean trigger) {
    triggerManager.setTriggerOnSlideEnter(trigger);
  }
  /** @return true if trigger should be fired after clicking */
  public boolean isTriggerWhenClicked() {
    return triggerWhenClicked;
  }
  /** @param trigger true if trigger should be fired after clicking */
  public void setTriggerWhenClicked(boolean trigger) {
    triggerWhenClicked = trigger;
  }
  /** @return true if trigger has this action object
   * @param object object to test */
  public boolean hasActionObject(JComponent object) {
    return triggerManager.hasActionObject(object);
  }
  /** @return trigger actions for object
   * @param object action object */
  public TriggerAction[] getTriggerActions(javax.swing.JComponent object) {
    return triggerManager.getTriggerActions(object);
  }
  /** @return all trigger actions for object */
  public TriggerAction[] getTriggerActions() {
    return triggerManager.getTriggerActions();
  }
  /** removes TriggerActions on non-existent object */
  public void removeUnparentedObjectActions() {
    triggerManager.removeUnparentedObjectActions();
  }
  /** Inserts TriggerAction into list
   * @param action action to insert */
  public void putAction(TriggerAction action) {
    triggerManager.putAction(action);
  }
}
