/**
 * <p>Title: LPrevSlideNavigation </p>
 * <p>Description: Navigation button to previous slide</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import javax.swing.*;

import sk.lomo.elearning.core.*;
import sk.lomo.elearning.core.event.*;

/** Navigation button to previous slide */
public class LPrevSlideNavigation extends LHyperlinkButton {
  /** Creates object */
  public LPrevSlideNavigation() {
    setText("<<");
    setHyperlink(new Hyperlink(Hyperlink.HYPERLINK_PREVSLIDE));
    this.addActionListener(
        new NavigationActionListener(getHyperlink())
        );
  }

  /** @return true if object should be placet into library */
  public boolean isLibraryObject() {
    return true;
  }

  /** @return icon representing this object */
  public Icon getRepositoryIcon() {
    return objectHelper.getRepositoryIcon();
  }

  /** @return name to display in library */
  public String getDisplayName() {
    return "Previous slide";
  }

  /** @return category to display in library */
  public String getDisplayCategory() {
    return "Nav";
  }
}
