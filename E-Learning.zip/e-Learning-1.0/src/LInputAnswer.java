/**
 * <p>Title: LInputAnswer </p>
 * <p>Description: IAnwer implementation to represent a type in answer</p>
 * <p>Author: Julius Loman</p>
 * @author Julius Loman
 * @version 1.0
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import sk.lomo.elearning.core.*;
import sk.lomo.elearning.core.event.*;
import sk.lomo.elearning.core.interfaces.*;
import sk.lomo.elearning.core.ui.*;

/** IAnwer implementation to represent a type in answer */
public class LInputAnswer extends JTextField implements IVisible, ITextObject,
    IAnswer {
  /** icon to display in menu */
  private Icon iconMenuQuestion = sk.lomo.elearning.Utils.getGraphics(
      "MenuQuestion.gif");
  /** icon to display in menu */
  private Icon iconMenuAnswerWeight = sk.lomo.elearning.Utils.getGraphics(
      "MenuAnswerWeight.gif");
  /** icon to display in menu */
  private Icon iconMenuCorrectAnswer = Library.getGraphics(
      "LInputAnswerMenuCorrectAnswer.gif");
  /** Embedded object to implement basic IObject functionality */
  private ObjectUtils objectUtils = new ObjectUtils(this);
  /** answer weight */
  private int weight;
  /** correct answer */
  private String correctAnswer = "";
  /** Creates object */
  public LInputAnswer() {
    setCursor(Cursor.getDefaultCursor());
    setText("Answer");
    setOpaque(false);
    setDoubleBuffered(true);
    setFocusable(false);
    setRequestFocusEnabled(false);
  }

  /** @return default size for this object */
  public Dimension getDefaultSize() {
    return new Dimension(120, 24);
  }

  /** @return border user for resizing and moving object */
  public ResizeBorder getResizeBorder() {
    return objectUtils.getResizeBorder();
  }

  /** @return cursor that is currently active for this object */
  public Cursor getObjectCursor() {
    return objectUtils.getObjectCursor();
  }

  /** @return context menu items for this object */
  public JMenuItem[] getMenuItems() {
    JMenuItem[] items = new JMenuItem[3];

    items[0] = new AnswerToQuestionMenu(this);

    items[1] = new JMenuItem("Answer weight");
    items[1].setIcon(iconMenuAnswerWeight);
    items[1].addActionListener(new AnswerWeightListener(this));

    items[2] = new JMenuItem("Correct answer");
    items[2].setIcon(iconMenuCorrectAnswer);
    items[2].addActionListener(new sk.lomo.elearning.core.event.ActionAdapter() {
      public void actionPerformed(ActionEvent e) {
        setCorrectAnswer(JOptionPane.showInputDialog("Correct answer",
            getCorrectAnswer()));
      }
    });

    return items;
  }

  /** @param selected true if object should be selected */
  public void setObjectSelected(boolean selected) {
    objectUtils.setSelected(selected);
  }

  /** @return true if object is selected  */
  public boolean isObjectSelected() {
    return objectUtils.isSelected();
  };

  /** @return true if object is a library object */
  public boolean isLibraryObject() {
    return true;
  }

  /** paint object
   * @param g graphics to paint to */
  public void paint(Graphics g) {
    super.paint(g);
    if (isDesignMode()) {
      if (isObjectSelected()) {
        objectUtils.getResizeBorder().paintBorder(this, g, 0, 0, getWidth(),
            getHeight());
      }
    }
  }

  /** @return category to display in library */
  public String getDisplayCategory() {
    return "Quiz";
  }

  /** @return name to display in library */
  public String getDisplayName() {
    return "Input choice answer";
  }

  /** @return icon representing this object */
  public Icon getRepositoryIcon() {
    return objectUtils.getRepositoryIcon();
  }

  /** @param designMode true if object should be set to design mode */
  public void setDesignMode(boolean designMode) {
    objectUtils.setDesignMode(designMode);
    setFocusable(!designMode);
    setRequestFocusEnabled(!designMode);
    if (designMode) {
      transferFocus();
    }
  }

  /** @return true if object is in design mode */
  public boolean isDesignMode() {
    return objectUtils.isDesignMode();
  }

  /** @return Answer weight (percentage). */
  public int getWeight() {
    return weight;
  }

  /** Sets the answer weight (percentage).
   * @param weight answer weight */
  public void setWeight(int weight) {
    this.weight = weight;
  }

  /** Calculates answer score
   * @return score in percentage according to given weight */
  public float calculateScore() {
    if (getText().equals(getCorrectAnswer())) {
      return getWeight();
    }
    return 0;
  }

  /** @return correct answer */
  public String getCorrectAnswer() {
    return correctAnswer;
  }

  /** sets correct answer
   * @param correctAnswer new correct answer   */
  public void setCorrectAnswer(String correctAnswer) {
    this.correctAnswer = correctAnswer;
  }

  /** invoked when object is placend onto slide */
  public void objectPlacement() {};
}
